/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Modules",url:"modules.html"},
{text:"Classes",url:"annotated.html",children:[
{text:"Class List",url:"annotated.html"},
{text:"Class Index",url:"classes.html"},
{text:"Class Members",url:"functions.html",children:[
{text:"All",url:"functions.html",children:[
{text:"c",url:"functions.html#index_c"},
{text:"d",url:"functions.html#index_d"},
{text:"l",url:"functions.html#index_l"}]},
{text:"Variables",url:"functions_vars.html",children:[
{text:"c",url:"functions_vars.html#index_c"},
{text:"d",url:"functions_vars.html#index_d"},
{text:"l",url:"functions_vars.html#index_l"}]}]}]},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"},
{text:"File Members",url:"globals.html",children:[
{text:"All",url:"globals.html",children:[
{text:"a",url:"globals.html#index_a"},
{text:"b",url:"globals_b.html#index_b"},
{text:"c",url:"globals_c.html#index_c"},
{text:"d",url:"globals_d.html#index_d"},
{text:"e",url:"globals_e.html#index_e"},
{text:"f",url:"globals_f.html#index_f"},
{text:"g",url:"globals_g.html#index_g"},
{text:"h",url:"globals_h.html#index_h"},
{text:"i",url:"globals_i.html#index_i"},
{text:"l",url:"globals_l.html#index_l"},
{text:"m",url:"globals_m.html#index_m"},
{text:"n",url:"globals_n.html#index_n"},
{text:"o",url:"globals_o.html#index_o"},
{text:"p",url:"globals_p.html#index_p"},
{text:"r",url:"globals_r.html#index_r"},
{text:"s",url:"globals_s.html#index_s"},
{text:"t",url:"globals_t.html#index_t"},
{text:"u",url:"globals_u.html#index_u"},
{text:"v",url:"globals_v.html#index_v"},
{text:"w",url:"globals_w.html#index_w"}]},
{text:"Functions",url:"globals_func.html",children:[
{text:"a",url:"globals_func.html#index_a"},
{text:"b",url:"globals_func_b.html#index_b"},
{text:"c",url:"globals_func_c.html#index_c"},
{text:"d",url:"globals_func_d.html#index_d"},
{text:"e",url:"globals_func_e.html#index_e"},
{text:"f",url:"globals_func_f.html#index_f"},
{text:"i",url:"globals_func_i.html#index_i"},
{text:"l",url:"globals_func_l.html#index_l"},
{text:"o",url:"globals_func_o.html#index_o"},
{text:"r",url:"globals_func_r.html#index_r"},
{text:"s",url:"globals_func_s.html#index_s"},
{text:"t",url:"globals_func_t.html#index_t"},
{text:"v",url:"globals_func_v.html#index_v"},
{text:"w",url:"globals_func_w.html#index_w"}]},
{text:"Variables",url:"globals_vars.html",children:[
{text:"a",url:"globals_vars.html#index_a"},
{text:"b",url:"globals_vars.html#index_b"},
{text:"c",url:"globals_vars.html#index_c"},
{text:"d",url:"globals_vars.html#index_d"},
{text:"f",url:"globals_vars.html#index_f"},
{text:"i",url:"globals_vars.html#index_i"},
{text:"l",url:"globals_vars.html#index_l"},
{text:"r",url:"globals_vars.html#index_r"},
{text:"t",url:"globals_vars.html#index_t"},
{text:"u",url:"globals_vars.html#index_u"},
{text:"w",url:"globals_vars.html#index_w"}]},
{text:"Enumerations",url:"globals_enum.html",children:[
{text:"b",url:"globals_enum.html#index_b"},
{text:"c",url:"globals_enum.html#index_c"},
{text:"d",url:"globals_enum.html#index_d"},
{text:"e",url:"globals_enum.html#index_e"},
{text:"t",url:"globals_enum.html#index_t"}]},
{text:"Enumerator",url:"globals_eval.html",children:[
{text:"a",url:"globals_eval.html#index_a"},
{text:"b",url:"globals_eval_b.html#index_b"},
{text:"c",url:"globals_eval_c.html#index_c"},
{text:"d",url:"globals_eval_d.html#index_d"},
{text:"e",url:"globals_eval_e.html#index_e"},
{text:"f",url:"globals_eval_f.html#index_f"},
{text:"g",url:"globals_eval_g.html#index_g"},
{text:"h",url:"globals_eval_h.html#index_h"},
{text:"i",url:"globals_eval_i.html#index_i"},
{text:"m",url:"globals_eval_m.html#index_m"},
{text:"n",url:"globals_eval_n.html#index_n"},
{text:"o",url:"globals_eval_o.html#index_o"},
{text:"p",url:"globals_eval_p.html#index_p"},
{text:"r",url:"globals_eval_r.html#index_r"},
{text:"s",url:"globals_eval_s.html#index_s"},
{text:"t",url:"globals_eval_t.html#index_t"},
{text:"u",url:"globals_eval_u.html#index_u"},
{text:"w",url:"globals_eval_w.html#index_w"}]}]}]}]}
