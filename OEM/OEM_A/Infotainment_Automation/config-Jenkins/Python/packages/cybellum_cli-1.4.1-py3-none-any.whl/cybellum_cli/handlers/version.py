import importlib.metadata
import logging
import sys

from ..exceptions import APIException, CLIVersionError, ServerVersionError, VersionError
from .shared import Command


class VersionCommand(Command):
    def versions_info(self):
        try:
            current_cli_version = self.get_cli_package_version()
        except CLIVersionError as e:
            print(e.version)
        else:
            print(current_cli_version)

        if self.client:
            try:
                current_server_version = self._get_server_version()
            except ServerVersionError as e:
                print(e.version)
                raise APIException() from e
            else:
                print(current_server_version)

            try:
                database_versions = self._get_database_versions()
            except ServerVersionError as e:
                print(e.version)
                raise APIException() from e
            else:
                print(database_versions)

    def get_cli_package_version(self):
        try:
            current_cli_version = importlib.metadata.version("cybellum_cli")
        except importlib.metadata.PackageNotFoundError:
            current_cli_version = "CLI: Unknown"
            raise CLIVersionError(current_cli_version)
        return f"CLI: {current_cli_version}"

    def _get_server_version(self):
        try:
            version_info = self.client.get_system_version()
        except Exception as e:
            logging.exception(e)
            version = "Server: FAILED"
            raise ServerVersionError(version) from e
        else:
            version = f"Server: {version_info['version']}, released at {version_info['date']}"
        return version

    def _get_database_version(self, name, method):
        try:
            version = method()
        except Exception as e:
            logging.exception(e)
            raise ServerVersionError(f"  {name}: FAIL {e}") from e
        else:
            return f"  {name}: {version}"

    def _get_database_versions(self):
        databases = (
            ("Intelligence", self.client.get_intelligence_db_version),
            ("Global packages", self.client.get_global_packages_db_version),
            ("Policies", self.client.get_policies_db_version),
            ("Vulnerabilities", self.client.get_vulnerabilities_db_version),
        )
        db_version_strings = ["Databases:"]
        for name, method in databases:
            db_version_strings.append(self._get_database_version(name, method))

        return "\n".join(db_version_strings)
