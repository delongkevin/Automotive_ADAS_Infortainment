import datetime
import logging
import sys
import time
from functools import wraps

from cli_use_client.models import ScanState, ScanSubState
from cybellum_cli.exceptions import HandledException
from cybellum_cli.handlers.shared import Command


class AssessmentsManager:
    def __init__(self, args, client):
        self.args = args
        self.client = client
        self.vulnerability_handler = KnownVulnerabilitiesAssessmentCommand(self.args, self.client)
        self.zero_days_handler = ZeroDaysAssessmentCommand(self.args, self.client)
        self.policy_handler = PolicyAssessmentCommand(self.args, self.client)
        if hasattr(self.args, "policies") and self.args.policies:
            self.policy_handler.load_and_check_policy_objects()

    def create_assessments(self, dt_id: str, dt_version_id: str):
        vulnerability_assessment_id = self.vulnerability_handler.create_assessment(dt_id, dt_version_id)
        zero_days_assessment_id = self.zero_days_handler.create_assessment(dt_id, dt_version_id)
        self.policy_handler.create_assessments(dt_id, vulnerability_assessment_id, zero_days_assessment_id, dt_version_id)

    def check_for_running_assessments(self, dt_id: str):
        self.vulnerability_handler.check_if_previous_assessment_still_running(dt_id)
        self.zero_days_handler.check_if_previous_assessment_still_running(dt_id)
        self.policy_handler.check_if_previous_assessments_still_running(dt_id)

    def wait_for_assessments_completion(self, start_time: float, timeout: int):
        while start_time + timeout > time.time():
            if all(
                [
                    self.vulnerability_handler.is_active_assessment_finished(),
                    self.zero_days_handler.is_active_assessment_finished(),
                    self.policy_handler.is_active_assessments_finished(),
                ]
            ):
                break

            time.sleep(self.args.status_interval)
        else:
            raise TimeoutError()


def is_assessment_running(assessment) -> bool:
    return assessment["dt_version_assessment_version"]["latest_scan"]["state"] != ScanState.COMPLETED


def is_assessment_succeed(assessment) -> bool:
    return (
        assessment["dt_version_assessment_version"]["latest_scan"]["state"] == ScanState.COMPLETED.value
        and assessment["dt_version_assessment_version"]["latest_scan"]["sub_state"] != ScanSubState.FAILURE.value
    )


def is_assessment_failed(assessment) -> bool:
    return assessment["dt_version_assessment_version"]["latest_scan"]["sub_state"] == ScanSubState.FAILURE.value


def cache_finished(method):
    @wraps(method)
    def wrapper(self, *args, **kwargs):
        if self.is_finished:
            return True
        self.is_finished = method(self, *args, **kwargs)
        return self.is_finished

    return wrapper


class KnownVulnerabilitiesAssessmentCommand(Command):
    def __init__(self, *args, **kwargs):
        super(KnownVulnerabilitiesAssessmentCommand, self).__init__(*args, **kwargs)
        self.assessment_id = None
        self.is_finished = False

    def check_if_previous_assessment_still_running(self, dt_id):
        assessments = self.client.get_vulnerabilities_assessments(dt_id)
        for assessment in assessments:
            scan_state = assessment["dt_version_assessment_version"]["latest_scan"]["state"]
            logging.debug(f"scan_state: {scan_state}")
            if is_assessment_running(assessment):
                raise HandledException("Known vulnerabilities assessment is still running")

    def create_assessment(self, dt_id, dt_version_id):
        if self.args.workflow_id or not self.args.vulnerabilities:
            # don't create new assessment if workflow is assigned
            return

        logging.info("Creating known assessment...")
        assessment = self.client.create_vulnerabilities_assessment(
            dt_id=dt_id,
            dt_version_id=dt_version_id,
            name=f"{self.args.name}",
            description=f"Assessment for {self.args.name}",
            start_date=datetime.datetime.utcnow(),
            end_date=datetime.datetime.utcnow(),
            va_profile_name=self.args.va_profile,
            va_auto_start=self.args.va_autostart,
        )

        self.assessment_id = assessment["id"]
        logging.info(f"Successfully created known vulnerabilities assessment with id: {self.assessment_id}")
        return self.assessment_id

    @cache_finished
    def is_active_assessment_finished(self):
        if self.assessment_id:
            assessments = self.client.get_active_vulnerabilities_assessments(self.assessment_id)
            for assessment in assessments:
                if is_assessment_running(assessment):
                    return False
        logging.info(f"Successfully finished known assessment with id: {self.assessment_id}")
        return True


class ZeroDaysAssessmentCommand(Command):
    def __init__(self, *args, **kwargs):
        super(ZeroDaysAssessmentCommand, self).__init__(*args, **kwargs)
        self.assessment_id = None
        self.is_finished = False

    def check_if_previous_assessment_still_running(self, dt_id: str):
        assessments = self.client.get_zero_days_assessments(dt_id)
        if assessments and is_assessment_running(assessments[0]):
            raise HandledException("Zero days assessment is still running")

    def create_assessment(self, dt_id: str, dt_version_id: str):
        if self.args.workflow_id or not self.args.zero_days:
            return

        logging.info("Creating zero day assessment...")
        self.assessment_id = self.client.create_zero_days_assessment(
            dt_id=dt_id,
            dt_version_id=dt_version_id,
            name=f"{self.args.name}",
            description=f"Assessment for {self.args.name}",
            start_date=datetime.datetime.utcnow(),
            end_date=datetime.datetime.utcnow(),
        )["id"]
        logging.info(f"Successfully created zero days assessment with id: {self.assessment_id}")
        return self.assessment_id

    @cache_finished
    def is_active_assessment_finished(self):
        if self.assessment_id:
            assessment = self.client.get_active_zero_days_assessment(self.assessment_id)
            if is_assessment_running(assessment):
                return False
            else:
                logging.info(f"Successfully finished zero days assessment with id: {self.assessment_id}")
        return True


class PolicyAssessmentCommand(Command):
    def __init__(self, *args, **kwargs):
        super(PolicyAssessmentCommand, self).__init__(*args, **kwargs)
        self.assessments_ids = []
        self.desired_policies = []
        self.is_finished = False

    def get_policies_map(self):
        policies_map = {}
        for policy in self.client.get_policies():
            policies_map[f"name:{policy['name']}"] = policy
            policies_map[f"id:{policy['id']}"] = policy
        return policies_map

    def load_and_check_policy_objects(self):
        policies_map = self.get_policies_map()
        errors = []
        for policy_name in self.args.policies:
            policy = policies_map.get(f"id:{policy_name}", policies_map.get(f"name:{policy_name}"))
            if policy is None:
                errors.append(f"Unknown policy ID or name {policy_name}")
            self.desired_policies.append(policy)
        if errors:
            for error in errors:
                logging.error(error)
            sys.exit(1)

    def check_if_previous_assessments_still_running(self, dt_id):
        current_policy_assessments = self.client.get_policies_assessments(dt_id)
        if current_policy_assessments:
            for policy_assessment in current_policy_assessments:
                if is_assessment_running(policy_assessment):
                    raise HandledException("Policy assessment is still running")

    def create_assessments(self, dt_id, vulnerability_assessment_id, zero_days_assessment_id, dt_version_id):
        if self.args.workflow_id or not self.args.policies:
            return

        policies_to_create = {}
        for policy in self.desired_policies:
            policies_to_create[policy["id"]] = policy["name"]

        for policy_id, policy_name in policies_to_create.items():
            logging.info("Creating assessment for policy %s", policy_name)
            kwargs = {}
            if vulnerability_assessment_id:
                kwargs["known_assessment_id"] = vulnerability_assessment_id
            if zero_days_assessment_id:
                kwargs["unknown_assessment_id"] = zero_days_assessment_id

            policy_assessment_id = self.client.create_policies_assessment(
                dt_id=dt_id,
                dt_version_id=dt_version_id,
                policy_id=policy_id,
                name=f"Policy {policy_name} for {self.args.name}, version: {self.args.version}",
                start_date=datetime.datetime.utcnow(),
                end_date=datetime.datetime.utcnow(),
            )["id"]
            self.assessments_ids.append(policy_assessment_id)
            logging.info(f"Successfully created policy assessment for the policy name <{policy_name}> with id: {policy_assessment_id}")

    @cache_finished
    def is_active_assessments_finished(self):
        assessments_finished = True

        if self.assessments_ids:
            for assessment in self.client.get_active_policies_assessment(self.assessments_ids):
                if is_assessment_running(assessment):
                    assessments_finished = False
                else:
                    self.assessments_ids.remove(assessment["id"])
                    logging.info(f"Successfully finished policy assessment with id: {assessment['id']}")

        return assessments_finished
