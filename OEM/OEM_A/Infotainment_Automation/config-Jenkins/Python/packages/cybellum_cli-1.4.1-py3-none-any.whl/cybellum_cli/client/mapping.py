def _map_dt_version(dt_version):
    return {
        "id": dt_version["id"],
        "name": dt_version["name"],
        "status": dt_version.get("status"),
        "scan.state": dt_version.get("scan", {}).get("state", None),
    }


def _map_dt(dt):
    return {
        "id": dt["id"],
        "name": dt["name"],
        "workflow_id": dt.get("workflow_id", None),
        "dt_versions": [_map_dt_version(v) for v in dt["dt_versions"]],
    }


def _map_assessment_version_scan(scan):
    return {
        "state": scan["state"],
        "sub_state": scan["sub_state"],
    }


def _map_assessment_version(assessment_version):
    return {
        "latest_scan": _map_assessment_version_scan(assessment_version["latest_scan"]),
    }


def _map_assessment(assessment):
    return {
        "id": assessment["id"],
        "dt_version_assessment_version": _map_assessment_version(assessment["dt_version_assessment_version"]),
    }


def _map_policy_assessment(assessment):
    return {
        "id": assessment["id"],
        "policy": _map_policy(assessment["policy"]),
        "dt_version_assessment_version": _map_assessment_version(assessment["dt_version_assessment_version"]),
    }


def _map_policy(policy):
    return {
        "id": policy["id"],
        "name": policy["name"],
    }


def _map_product_version(product_version):
    return {
        "id": product_version["id"],
        "name": product_version["name"],
        "status": product_version["status"],
    }


def _map_product(product):
    return {
        "id": product["id"],
        "name": product["name"],
        "level": product["level"],
        "versions": [_map_product_version(v) for v in product["versions"]],
    }


def _map_product_architecture_attached_element_object(element):
    return {
        "id": element.get("id", None),
        "name": element.get("name", None),
    }


def _map_product_architecture_attached_element(element):
    return {
        "type": element["type"],
        "product_version": _map_product_architecture_attached_element_object(element.get("product_version", {})),
        "dt_version": _map_product_architecture_attached_element_object(element.get("dt_version", {})),
    }


def _map_product_architecture(product_architecture):
    return {
        "id": product_architecture["id"],
        "attached_elements": [_map_product_architecture_attached_element(element) for element in product_architecture["attached_elements"]],
    }


def _map_workflow(workflow):
    return {
        "id": workflow["id"],
        "name": workflow["name"],
    }


def _map_valid_lifecycle_phases(field_custom_values):
    field_custom_values = field_custom_values or []
    return {item["value"].lower(): item["value"] for item in sorted(field_custom_values, key=lambda x: x["value"])}


def _map_valid_component_types(field_custom_values):
    field_custom_values = field_custom_values or []
    return {item["value"].lower(): item["value"] for item in sorted(field_custom_values, key=lambda x: x["value"])}
