from cybellum_cli.exceptions import ValidationException
from cybellum_cli.handlers.report import ReportCommand
from cybellum_cli.parsers.common import add_common_arguments


def add_report_command(top_level_commands):
    report_parser = top_level_commands.add_parser("report", help="Generate reports for component version")
    report_command = report_parser.add_subparsers()

    _add_cyclone_dx_report(report_command)


def _add_common_report_arguments(cyclone_dx_parser):
    # Component identification
    component_group = cyclone_dx_parser.add_argument_group("Component")
    component_group.add_argument("--name", help="Name of the component (required)", required=True, metavar="NAME")
    component_group.add_argument("--version", help="Component version (required)", required=True, metavar="VERSION")

    report_output_group = cyclone_dx_parser.add_argument_group("Report Output")
    report_output_group.add_argument(
        "-o", "--output", help="Path to store the report. If omitted output will be to stdout", required=False, metavar="PATH", type=str
    )
    report_output_group.add_argument(
        "--chunk-size",
        help="Size of report chunk in bytes to process in memory",
        type=int,
        default=8192,
    )


def _add_cyclone_dx_report(report_command):
    cyclone_dx_parser = report_command.add_parser("cyclone-dx", help="Generate CycloneDX report for component version")

    cyclone_dx_parser.set_defaults(
        command_class=ReportCommand,
        method="download_report",
        validators=[_validate_report_options],
        parser=cyclone_dx_parser,
    )

    add_common_arguments(cyclone_dx_parser)

    _add_common_report_arguments(cyclone_dx_parser)

    report_group = cyclone_dx_parser.add_argument_group("Report Options")

    report_group.add_argument("--exclude-tags", help="Tags to exclude from the report", nargs="+", metavar="TAG", default=[])
    report_group.add_argument("--with-vulnerabilities", action="store_true", help="Include vulnerabilities in the report", default=False)
    report_group.add_argument("--with-packages", action="store_true", help="Include packages in the report", default=False)


def _validate_report_options(parser, args):
    if not any([args.with_vulnerabilities, args.with_packages]):
        raise ValidationException("At least one of --with-vulnerabilities or --with-packages must be specified")
