import argparse

from cybellum_cli.parsers.component import add_component_command
from cybellum_cli.parsers.system import add_system_command
from cybellum_cli.parsers.version import add_version_command


def create_parser():
    parser = argparse.ArgumentParser("cybellumcli")
    parser.set_defaults(
        command_class=None,
        validators=[],
        parser=parser,
        workflow_id=None,
    )
    top_level_commands = parser.add_subparsers()

    add_component_command(top_level_commands)
    add_version_command(top_level_commands)
    add_system_command(top_level_commands)

    return parser
