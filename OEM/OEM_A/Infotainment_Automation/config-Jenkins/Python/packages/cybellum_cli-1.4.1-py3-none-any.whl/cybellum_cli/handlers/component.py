import logging
import os
import tempfile
import time
import zipfile
from pathlib import Path
from shutil import rmtree

from cli_use_client.models import PrivateConfigurations, ScanState
from cli_use_client.models.dt_creation_types import DtCreationTypes
from cli_use_client.models.resumable_upload_session_type import ResumableUploadSessionType
from cli_use_client.types import File

from ..constants import WORKFLOW_INCOMPATIBLE_ARGUMENTS, UploadZippingPolicy
from ..exceptions import HandledException, ValidationException
from ..libs.resumable import Resumable
from ..libs.resumable.core import MiB
from .assessments import AssessmentsManager
from .shared import Command


class ComponentCommand(Command):
    def __init__(self, *args, **kwargs):
        super(ComponentCommand, self).__init__(*args, **kwargs)
        self.start_time = time.time()
        self.assessments_manager = AssessmentsManager(self.args, self.client)
        self.temp_folder = None
        if self.args.skip_resumable_upload:
            self.files = []
        else:
            self.resumable_session = self._create_resumable_session()
            self.resumable_files_from_path = []
            self.resumable_identifiers = []

    def _create_resumable_session(self):
        session_type, auto_complete = self._find_session_params_for_creation_type(self.args.creation_type)
        logging.debug(f"Creating resumable_session session_type: {session_type}, auto_complete: {auto_complete}")
        try:
            resumable_upload_session = self.client.create_session({"data": {"type": session_type, "auto_complete": auto_complete}})
        except Exception as e:
            logging.exception(f"Failed to create resumable session: {e}")
            raise HandledException("Failed to create resumable session")

        file_chunk_size = int(self.args.file_chunk_size)
        concurrent_uploads = int(self.args.concurrent_uploads)
        logging.debug(f"Resumable Uploads settings: file chunk size {file_chunk_size} MiB, simultaneous uploads {concurrent_uploads}")
        session = Resumable(
            client=self.client,
            session_id=resumable_upload_session.parsed["data"]["session_id"],
            chunk_size=file_chunk_size * MiB,
            simultaneous_uploads=concurrent_uploads,
            max_chunk_retries=10000,
            # We currently define ANY errors as permanent
            # Few exceptions could be 502 or 429
            permanent_errors=[400, 401, 403, 404, 415, 419, 500, 501],
        )
        return session

    def _find_session_params_for_creation_type(self, creation_type):
        creation_type = DtCreationTypes.from_val(creation_type)
        if creation_type in [
            DtCreationTypes.CREATE_FROM_FIRMWARE,
            DtCreationTypes.CREATE_FROM_SOURCE_CODE,
        ]:
            return ResumableUploadSessionType.CREATE_BINARY_SOURCE, False

        if creation_type in [
            DtCreationTypes.IMPORT_FROM_CPES_LIST,
            DtCreationTypes.IMPORT_FROM_CYCLONEDX,
            DtCreationTypes.IMPORT_FROM_SPDX,
            DtCreationTypes.IMPORT_FROM_SBOM_FILE,
        ]:
            return ResumableUploadSessionType.CREATE_SBOM_SOURCE, False

        return ResumableUploadSessionType.ADD_RESOURCE, True

    def _validate_life_cycle_phase(self, lifecycle_phase):
        valid_lifecycle_phases = self.client.get_valid_lifecycle_phases()
        if not (db_lifecycle_phase := valid_lifecycle_phases.get(lifecycle_phase.lower())):
            lifecycles_to_show = "\n".join(valid_lifecycle_phases)
            raise ValidationException(f"Invalid lifecycle phase {lifecycle_phase}. Valid values are: {lifecycles_to_show}\n------------")
        return db_lifecycle_phase

    def _prepare_source(self):
        kwargs = {}
        if getattr(self.args, "lifecycle_phase", None):
            kwargs["production_phase"] = self._validate_life_cycle_phase(self.args.lifecycle_phase)

        if getattr(self.args, "component_type", None):
            kwargs["component_category"] = self.validate_component_category(self.args.component_type)

        if getattr(self.args, "creation_type", None):
            kwargs["creation_type"] = self.args.creation_type

        if getattr(self.args, "auto_fix_import_issues", None):
            kwargs["auto_fix_import_issues"] = self.args.auto_fix_import_issues

        if self.args.from_path:
            if self.args.skip_resumable_upload:
                logging.info("Uploading files from local paths - bypass resumable upload ...")
                kwargs["files"] = self._upload_files_from_local_paths()
                if not kwargs["files"]:
                    filtration_msg = f" with filtration {self.args.black_list}" if self.args.black_list else ""
                    raise ValidationException(f"No files to upload from {self.args.from_path}{filtration_msg}")
            else:
                self.resumable_files_from_path.extend(self._upload_files_from_local_paths())
                if not self.resumable_files_from_path:
                    filtration_msg = f" with filtration {self.args.black_list}" if self.args.black_list else ""
                    raise ValidationException(f"No files were uploaded from {self.args.from_path}{filtration_msg}")

        if self.args.from_urls:
            logging.info("Processing URLs for upload: %s", self.args.from_urls)
            if self.args.skip_resumable_upload:
                kwargs["urls"] = self.args.from_urls
            else:
                self.resumable_identifiers.extend(self._upload_files_from_urls(self.args.from_urls))

        if self.args.commit_log:
            if self.args.skip_resumable_upload:
                file_name = self.args.commit_log.split("/")[-1].split("\\")[-1]
                with open(self.args.commit_log, "rb") as file:  # Use context manager to ensure the file is closed
                    kwargs["gitlog_archive_file"] = File(payload=file, file_name=file_name)
            else:
                kwargs["resumable_gitlog_identifier"] = self.resumable_session.add_file(self.args.commit_log)

        if not self.args.skip_resumable_upload:
            if self.resumable_identifiers or self.args.from_path or self.args.commit_log:
                logging.info("Waiting for files to be uploaded...")
                try:
                    self.resumable_session.join()
                    logging.info("Done")
                except Exception as e:
                    logging.exception(f"Failed to upload files: {e}")

                for resumable_file in self.resumable_files_from_path:
                    self.resumable_identifiers.append(resumable_file.file_id)

                kwargs["resumable_identifiers"] = self.resumable_identifiers
                kwargs["resumable_session_id"] = self.resumable_session.config.session_id

                if kwargs.get("resumable_gitlog_identifier"):
                    kwargs["resumable_gitlog_identifier"] = kwargs.get("resumable_gitlog_identifier").file_id

        return kwargs

    def _validate_dt_version_name(self, dt):
        for dt_version in dt["dt_versions"]:
            if dt_version["name"] == self.args.version:
                raise ValidationException(f"Component version with version name {self.args.version} already exists")

    def get_from_version_id(self, dt):
        version_exists = next((v for v in dt["dt_versions"] if v["name"] == self.args.from_version), None)
        if not version_exists:
            raise ValidationException(f"Component version with version name {self.args.from_version} doesn't exist")

        return version_exists["id"]

    def validate_workflow_option(self):
        if self.args.workflow_id:
            invalid_params = ["--" + param for param in WORKFLOW_INCOMPATIBLE_ARGUMENTS if getattr(self.args, param)]

            if invalid_params:
                raise ValidationException(
                    f"A workflow was set for the component. The following parameters: \n{', '.join(invalid_params)}\nare not allowed"
                )

    def validate_component_category(self, component_type):
        if not component_type:
            return None
        valid_component_types = self.client.get_valid_component_types()
        if not (db_component_type := valid_component_types.get(component_type.lower())):
            types_to_show = "\n".join(valid_component_types)
            raise ValidationException(
                f"Wrong component type: {component_type}. The following types are only allowed: \n{types_to_show}\n------------"
            )
        return db_component_type

    def create_dt_version(self):
        dt_list = self.client.get_all_dts()
        dt = self._find_dt(dt_list, self.args.name)

        private_configurations = PrivateConfigurations.from_dict(
            {
                "scan_config": {
                    "advanced_autosar_identification": True if self.args.autosar else False,
                },
            }
        )

        if not dt:
            if self.args.create_component == "never":
                raise ValidationException(
                    f"No component found with the name <{self.args.name}>. Add --create-component always or --create-component when-not-exists to explicitly to create a new component"
                )

            if not self.args.no_workflow:
                self.args.workflow_id = self.client.get_workflow_id(self.args.workflow)
                self.validate_workflow_option()

            kwargs = self._prepare_source()

            dt = self.client.create_digital_twin(
                name=self.args.name,
                version=self.args.version,
                micro_controller=self.args.micro_controller,
                private_configurations=private_configurations,
                workflow_id=self.args.workflow_id,
                business_unit=self.args.business_unit,
                **kwargs,
            )
            dt_version = dt["dt_versions"][0]
            logging.info(
                f"New component created ({self.args.name}, {self.args.version}) "
                f"with the component id <{dt['id']}> and version id <{dt_version['id']}>"
            )
            self._clear_temp_folder()
        else:
            if self.args.create_component == "always":
                raise ValidationException(
                    f"Component found with the name <{self.args.name}>. It is not possible to create a new component with the same name. Remove --create-component to avoid creating a new component"
                )

            self._validate_dt_version_name(dt)

            if self._is_any_scan_running(self.client.get_digital_twin(dt["id"])):
                raise HandledException("Scan of specified component is still in progress")
            self.assessments_manager.check_for_running_assessments(dt["id"])

            self.args.workflow_id = dt["workflow_id"]
            self.validate_workflow_option()

            kwargs = self._prepare_source()

            if self.args.root_version:
                kwargs["is_root"] = True

            if self.args.from_version:
                kwargs["parent_id"] = self.get_from_version_id(dt)

            if self.args.make_default_version:
                kwargs["make_default"] = True
            else:
                kwargs["make_default"] = False

            dt_version = self.client.create_dt_version(
                dt_id=dt["id"],
                name=self.args.version,
                **kwargs,
            )
            logging.info(
                f"New component version created ({self.args.name}, {self.args.version}) "
                f"with the component id <{dt['id']}> and version id <{dt_version['id']}>"
            )

        self.assessments_manager.create_assessments(dt["id"], dt_version["id"])
        if self.args.wait_for_completion:
            logging.info("Waiting for the process to be completed...")
            self._wait_for_dt_scan_finished(dt["id"], dt_version["id"], self.start_time, self.args.timeout_seconds)
            self.assessments_manager.wait_for_assessments_completion(self.start_time, self.args.timeout_seconds)
            logging.info("Done")

        return dt_version

    def _find_dt(self, dt_list, dt_name):
        for dt in dt_list:
            if dt["name"] == dt_name:
                return dt
        return None

    def _get_file_paths(self):
        if os.path.isdir(self.args.from_path):
            for root, dirs, files in os.walk(self.args.from_path):
                for file in files:
                    if self._is_black_listed(os.path.join(self.args.from_path, file)):
                        continue

                    full_path = os.path.join(root, file)
                    yield full_path
        else:
            if not self._is_black_listed(self.args.from_path):
                yield self.args.from_path

    def _get_file_path_lists_info(self):
        file_paths = list(self._get_file_paths())
        empty_file = not file_paths
        multiple_files = len(file_paths) > 1
        return file_paths, empty_file, multiple_files

    def _upload_files_from_local_paths(self):
        """
        Upload files from local paths based on the specified zipping policy.

        Returns:
            list: A list of resumable files uploaded.
        """
        _files = []

        temp_dir = tempfile.mkdtemp()
        zip_name = Path(self.args.from_path).name
        zip_path = Path(temp_dir) / zip_name
        zip_policy = self.args.upload_zipping_policy
        files_path_list, empty_file, multiple_files = self._get_file_path_lists_info()

        logging.info(f"Starting upload from local paths: {self.args.from_path}")
        logging.debug(f"Zip policy: {zip_policy}, Empty file: {empty_file}, Multiple files: {multiple_files}")

        if empty_file:
            logging.warning("No files to upload, returning empty list.")
            return _files

        if zip_policy == UploadZippingPolicy.ALWAYS.value or (
            zip_policy == UploadZippingPolicy.ZIP_MULTIPLE_FILES.value and multiple_files
        ):
            self.temp_folder = temp_dir
            self._zip_files(files_path_list, zip_path)

            if self.args.skip_resumable_upload:
                logging.info(f"Bypassing resumable upload, opening zip file: {zip_path}")
                file = open(zip_path, "rb")  # Keep file open until after the upload is complete
                _files.append(File(payload=file, file_name=zip_name))
            else:
                logging.info(f"Adding zip file to resumable session: {zip_path}")
                _file = self.resumable_session.add_file(zip_path)
                _files.append(_file)
        else:
            for file_path in files_path_list:
                if self.args.skip_resumable_upload:
                    file_name = file_path.split("/")[-1].split("\\")[-1]
                    logging.info(f"Bypassing resumable upload for file: {file_path}")
                    file = open(file_path, "rb")
                    _files.append(File(payload=file, file_name=file_name))
                else:
                    logging.debug(f"Uploading file - {file_path}")
                    _file = self.resumable_session.add_file(file_path)
                    _files.append(_file)

        logging.info(f"Uploaded {len(_files)} files from local paths.")
        return _files

    def _upload_files_from_urls(self, urls):
        identifiers = []
        for url in urls:
            logging.debug(f"Uploading file from url {url}")
            resumable_file = self.client.upload_from_url(session_id=self.resumable_session.config.session_id, url=url)
            identifiers.append(resumable_file.parsed["data"]["file_id"])
        return identifiers

    def _is_black_listed(self, filename):
        if self.args.black_list:
            for pattern in self.args.black_list:
                if Path(filename).match(pattern):
                    logging.debug(f"File {filename} is blacklisted by pattern: {pattern}")
                    return True
        return False

    def _wait_for_dt_scan_finished(self, dt_id, dt_version_id, start_time, timeout):
        while start_time + timeout > time.time():
            if not self._is_any_scan_running(self.client.get_digital_twin(dt_id), dt_version_id):
                break
            time.sleep(self.args.status_interval)
        else:
            raise HandledException("Component scan timeout exceeded")

    def _is_any_scan_running(self, dt, dt_version_id=None):
        for version in dt["dt_versions"]:
            if (dt_version_id and version["id"] == dt_version_id or dt_version_id is None) and version["scan.state"] != ScanState.COMPLETED:
                return True

        return False

    def add_source_to_version(self):
        dt_list = self.client.get_all_dts()
        dt = self._find_dt(dt_list, self.args.name)

        if not dt:
            raise ValidationException(f"No component found with the name <{self.args.name}>")

        dt_version = self._find_dt_version(dt, self.args.version)
        if not dt_version:
            raise ValidationException(f"No version found with the name <{self.args.version}> for component <{self.args.name}>")

        kwargs = self._prepare_source()
        # Add the source to the version
        kwargs.update({"dt_version_id": dt_version["id"], "creation_type": self.args.creation_type})
        new_source = self.client.import_sbom_source_to_dt_version(**kwargs)
        logging.info(f"New source imported to component <{self.args.name}> version <{self.args.version}>")
        self._clear_temp_folder()

        # TODO: Handle propagation as part of CPD-12540
        return new_source

    def _find_dt_version(self, dt, version_name):
        for version in dt["dt_versions"]:
            if version["name"] == version_name:
                return version
        return None

    def _zip_files(self, files_path_list, zip_path):
        logging.info(f"Zipping {len(files_path_list)} files to {zip_path}")
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zip_file:
            for file_path in files_path_list:
                logging.debug(f"Adding file to zip file - {file_path}")
                zip_file.write(file_path)

    def _clear_temp_folder(self):
        if self.temp_folder:
            logging.info(f"Removing temp folder - {self.temp_folder}")
            rmtree(self.temp_folder)
