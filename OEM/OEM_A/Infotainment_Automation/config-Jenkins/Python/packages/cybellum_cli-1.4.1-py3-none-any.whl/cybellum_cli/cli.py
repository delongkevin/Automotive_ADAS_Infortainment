import logging
import os
import signal
import sys

from cli_use_client.errors import FailedStatus, UnexpectedStatus
from cybellum_cli.client.api import APIClient
from cybellum_cli.exceptions import APIException, AuthenticationException, HandledException, ProductNameAmbiguousError, ValidationException
from cybellum_cli.parsers.parser import create_parser


class CLI:
    def __init__(self):
        self.parser = None
        self.args = None
        self.client = None

    def parse_args(self, input_args=None):
        self.parser = create_parser()
        self.args = self.parser.parse_args(input_args)

        for validator in self.args.validators:
            validator(self.parser, self.args)

    def run(self):
        args = self.args

        if not args.command_class:
            args.parser.print_help()
            self.parser.exit()

        if self.args.base_url:
            self.client = APIClient.client_from_api_key(args.base_url, args.api_key, args.insecure, args.cacert, args.proxy)

        if self.client:
            logging.debug("Verifying SSL is set to %s", self.client.client.verify_ssl)
            if self.client.client.cert:
                logging.debug("Using SSL certificate %s", self.client.client.cert)

        command = self.args.command_class(self.args, self.client)

        method = getattr(command, self.args.method)
        assert method
        try:
            method()
        except ValidationException as e:
            logging.error(str(e))
            sys.exit(1)
        except HandledException as e:
            logging.error(str(e))
            sys.exit(2)
        except TimeoutError:
            logging.error("Timeout exceeded")
            sys.exit(3)
        except AuthenticationException as e:
            logging.error("Authentication failed: %s", str(e))
            sys.exit(4)
        except APIException as e:
            if logging.getLogger().isEnabledFor(logging.DEBUG):
                logging.exception("Unhandled Exception")
            else:
                logging.error(e.__cause__)
            sys.exit(5)
        except FileNotFoundError:
            logging.error("No such file or directory")
            sys.exit(6)
        except UnexpectedStatus as e:
            logging.error(str(e))
            sys.exit(7)
        except FailedStatus as e:
            error_code = e.response.get("error", {}).get("error_code") if e.response else ""
            logging.error(f"API call error: {e.status_code}, {error_code}")
            logging.debug(e.response)
            sys.exit(8)
        except ProductNameAmbiguousError as e:
            logging.error(str(e))
            sys.exit(10)
        except Exception as e:
            if logging.getLogger().isEnabledFor(logging.DEBUG):
                logging.exception("Unhandled Exception")
            else:
                logging.error(f"Unhandled Exception: {repr(e)}")
            sys.exit(9)


def sigterm_handler(sig, frame):
    print("Interrupted")
    sys.exit(10)


def init_logs():
    log_level = logging.DEBUG if os.environ.get("CLI_DEBUG") else logging.INFO
    logger = logging.getLogger()
    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    ch.setLevel(log_level)
    logger.setLevel(log_level)
    logger.addHandler(ch)


def main():
    init_logs()
    signal.signal(signal.SIGTERM, sigterm_handler)
    cli = CLI()
    try:
        cli.parse_args()
    except ValidationException as e:
        logging.error(str(e))
        sys.exit(1)
    cli.run()


if __name__ == "__main__":
    main()
