from ..client.api import APIClient


class Command:
    def __init__(self, args, client):
        self.args = args
        self.client: APIClient = client
