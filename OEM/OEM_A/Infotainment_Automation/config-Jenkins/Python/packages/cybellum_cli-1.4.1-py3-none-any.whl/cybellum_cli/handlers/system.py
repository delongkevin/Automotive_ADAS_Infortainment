import logging
from typing import List, Optional, Tuple

from cli_use_client.models import ElementType

from ..exceptions import ValidationException
from .shared import Command


class SystemCommand(Command):
    PRODUCT_TYPE = "product"
    COMPONENT_TYPE = "component"

    TO_ELEMENT_TYPE = {
        PRODUCT_TYPE: ElementType.PRODUCT_VERSION.value,
        COMPONENT_TYPE: ElementType.DT_VERSION.value,
    }

    def __init__(self, *args, **kwargs):
        super(SystemCommand, self).__init__(*args, **kwargs)
        self.parent_id: Optional[str] = None
        self.entity_to_attach: Optional[str] = None

        self.entity = self.args.component or self.args.product
        self.entity_version = self.args.component_version or self.args.product_version
        self.entity_type = self.COMPONENT_TYPE if self.args.component else self.PRODUCT_TYPE

    def attach(self):
        self._validate_and_map_input()
        if not self.entity_to_attach:
            logging.error(f"{self.entity_type.capitalize()} {self.entity} not found")
            return

        self.client.attach_to_product(
            self.parent_id,
            self.entity_to_attach,
            self.TO_ELEMENT_TYPE[self.entity_type],
        )
        logging.info(
            "Successfully attached %s %s to %s",
            self.entity_type,
            self.entity,
            self.args.parent,
        )

    def _validate_and_map_input(self):
        self.parent_id = self._get_parent()
        self.entity_to_attach = self._get_entity_to_attach()
        if not self.entity_to_attach:
            return

        self._validate_already_attached()

    def _get_parent(self):
        parent = self.args.parent
        parent_version = self.args.parent_version
        parent_id = self.client.find_product_version_id(parent, parent_version)
        if not parent_id:
            raise ValidationException(f"Parent with id/name <{parent}> not found")
        return parent_id

    def _get_entity_to_attach(self):
        if self.entity_type == self.PRODUCT_TYPE:
            return self.client.find_product_version_id(self.entity, self.entity_version)
        elif self.entity_type == self.COMPONENT_TYPE:
            return self.client.find_component(self.entity, self.entity_version)
        else:
            raise ValidationException(f"{self.entity_type} {self.entity} not found")

    def _get_already_attached(self):
        product_architecture = self.client.get_parent_architecture(self.parent_id)
        type_map = {
            ElementType.PRODUCT_VERSION: self.PRODUCT_TYPE,
            ElementType.DT_VERSION: self.COMPONENT_TYPE,
        }
        id_map = {
            ElementType.PRODUCT_VERSION.value: lambda el: el["product_version"]["id"],
            ElementType.DT_VERSION.value: lambda el: el["dt_version"]["id"],
        }
        return [id_map[el["type"]](el) for el in product_architecture["attached_elements"] if type_map.get(el["type"]) == self.entity_type]

    def _validate_already_attached(self):
        already_attached = self._get_already_attached()

        if self.entity_to_attach in already_attached:
            raise ValidationException(f"{self.entity_type.capitalize()} {self.entity} is already attached to {self.args.parent}")
