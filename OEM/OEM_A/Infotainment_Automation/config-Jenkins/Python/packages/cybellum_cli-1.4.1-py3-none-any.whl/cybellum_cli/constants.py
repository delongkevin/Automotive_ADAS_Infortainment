from enum import Enum

WORKFLOW_INCOMPATIBLE_ARGUMENTS = [
    "vulnerabilities",
    "zero_days",
    "policies",
    "wait_for_completion",
    "delete_files",
    "va_autostart",
    "va_profile",
]


class UploadZippingPolicy(Enum):
    NEVER = "never"
    ALWAYS = "always"
    ZIP_MULTIPLE_FILES = "zip_multiple_files"
