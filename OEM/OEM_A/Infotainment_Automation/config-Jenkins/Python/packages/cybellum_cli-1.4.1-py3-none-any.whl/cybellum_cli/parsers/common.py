from argparse import SUPPRESS

from cybellum_cli.exceptions import ValidationException


def add_common_arguments(command, required=True):
    target_group = command.add_argument_group(
        "Target environment", description="The Cybellum PSA installation to perform the operations with"
    )
    target_exclusive_group = target_group.add_mutually_exclusive_group(required=required)
    target_exclusive_group.add_argument("--host", help=SUPPRESS, metavar="<IP address or DNS name>")
    target_exclusive_group.add_argument("--base-url", "--base_url", help="Full url. Ex. 'https://example.com'", metavar="URL")
    target_group.add_argument("--port", type=int, help=SUPPRESS, metavar="NUM")

    connectivity_group = command.add_argument_group("Connectivity", description="Network connectivity options")
    connectivity_group.add_argument("--api-key", "--api_key", help="API key", metavar="KEY", required=required)
    connectivity_group.add_argument("--cacert", help="Path to trusted CA certificate", metavar="PATH")
    connectivity_group.add_argument(
        "--insecure", action="store_true", default=False, help="Allow to make requests without certificate verification"
    )
    connectivity_group.add_argument(
        "--proxy",
        help="Url to http(s) proxy to utilize (e.g. http://10.0.1.2:8089)",
        metavar="URL",
    )

    validators = command.get_default("validators")
    validators.extend([_clean_target])


def _clean_target(parser, args):
    if args.host:
        port_spec = f":{args.port}" if args.port else ""
        args.base_url = f"https://{args.host}{port_spec}/api"
    elif args.base_url:
        args.base_url = args.base_url.rstrip("/") + "/api"

    if args.base_url and not args.api_key:
        raise ValidationException("You should provide authentication credentials. Specify api key")
