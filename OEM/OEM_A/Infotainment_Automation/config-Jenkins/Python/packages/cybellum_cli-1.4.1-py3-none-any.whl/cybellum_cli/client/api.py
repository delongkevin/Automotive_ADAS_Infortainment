from __future__ import annotations

from contextlib import contextmanager
from functools import lru_cache
from typing import Optional

from cli_use_client import AuthenticatedClient
from cli_use_client.api.digital_twin_management.create_digital_twin import sync as create_digital_twin
from cli_use_client.api.digital_twin_management.create_digital_twin_version import sync as create_digital_twin_version
from cli_use_client.api.digital_twin_management.get_digital_twins import sync as get_digital_twins
from cli_use_client.api.digital_twin_results.export_digital_twin_cyclonedx import sync_detailed as export_digital_twin_cyclonedx
from cli_use_client.api.digital_twin_results.export_vex_report import sync_detailed as export_vex_report
from cli_use_client.api.digital_twin_results.import_sbom_source import sync as import_sbom_source
from cli_use_client.api.fields_custom_values.retrieve_field_custom_values import sync as retrieve_field_custom_values
from cli_use_client.api.intelligence_database.get_intelligence_database_version import sync as get_intelligence_database_version
from cli_use_client.api.package_management.get_global_packages_database_version import sync as get_global_packages_database_version
from cli_use_client.api.policies_assessments.create_policies_assessment import sync as create_policies_assessment
from cli_use_client.api.policies_assessments.get_policies_assessments import sync as get_policies_assessments
from cli_use_client.api.policies_assessments.upgrade_policies_assessment import sync as upgrade_policies_assessment
from cli_use_client.api.policies_management.get_policies import sync as get_policies
from cli_use_client.api.policies_management.get_policies_database_version import sync as get_policies_database_version
from cli_use_client.api.products_management.attach_element_to_product_version import sync as attach_element_to_product_version
from cli_use_client.api.products_management.get_product_version_architecture import sync as get_product_version_architecture
from cli_use_client.api.products_management.get_products import sync as get_products
from cli_use_client.api.resumable_uploads.create_session import sync_detailed as create_session
from cli_use_client.api.resumable_uploads.get_file_upload_status import sync_detailed as get_file_upload_status
from cli_use_client.api.resumable_uploads.get_resumable_upload_status import sync_detailed as get_resumable_upload_status
from cli_use_client.api.resumable_uploads.upload_file_chunk import sync_detailed as upload_file_chunk
from cli_use_client.api.resumable_uploads.upload_from_url import sync_detailed as upload_from_url
from cli_use_client.api.tenant_management.get_system_information import sync as get_system_information
from cli_use_client.api.vulnerabilities_assessments.create_vulnerabilities_assessment import sync as create_vulnerabilities_assessment
from cli_use_client.api.vulnerabilities_assessments.get_vulnerabilities_assessments import sync as get_vulnerabilities_assessments
from cli_use_client.api.vulnerabilities_database.get_vulnerabilities_database_version import sync as get_vulnerabilities_database_version
from cli_use_client.api.workflows.get_workflows import sync as get_workflows
from cli_use_client.api.zero_days_assessments.create_zero_days_assessment import sync as create_zero_days_assessment
from cli_use_client.api.zero_days_assessments.get_zero_days_assessments import sync as get_zero_days_assessments
from cli_use_client.api.zero_days_assessments.upgrade_zero_days_assessment import sync as upgrade_zero_days_assessment
from cli_use_client.client import ParseResponseBehavior
from cli_use_client.errors import FailedStatus
from cli_use_client.models import (
    AttachElementToProductVersionJsonBody,
    CreateDigitalTwinVersionMultipartData,
    CreatePoliciesAssessmentJsonBody,
    CreateSessionJsonBody,
    CreateVulnerabilitiesAssessmentJsonBody,
    CreateVulnerabilitiesAssessmentJsonBodyVirtualAnalystProfile,
    CreateZeroDaysAssessmentJsonBody,
    DigitalTwinCreationPayload,
    DigitalTwinVersionCreationBase,
    DigitalTwinVersionStatus,
    ImportSbomSourceMultipartData,
    UpgradePoliciesAssessmentJsonBody,
    UpgradeZeroDaysAssessmentJsonBody,
    UploadFileChunkMultipartData,
    UploadFromUrlJsonBody,
)
from cli_use_client.types import UNSET, File
from cybellum_cli.exceptions import HandledException, ProductNameAmbiguousError, ValidationException
from httpx import HTTPTransport, Proxy

from .mapping import (
    _map_assessment,
    _map_dt,
    _map_dt_version,
    _map_policy,
    _map_policy_assessment,
    _map_product,
    _map_product_architecture,
    _map_valid_component_types,
    _map_valid_lifecycle_phases,
    _map_workflow,
)


class APIClient:
    def __init__(self, client: AuthenticatedClient):
        self.client = client
        self._response_behavior_stack = []

    def get_token(self):
        self.client.get_authentication_status_sync()
        return self.client.token

    @classmethod
    def client_from_api_key(cls, api_url: str, api_key: str, insecure: bool, cacert: str, proxy: str) -> APIClient:
        if proxy:
            transport = HTTPTransport(proxy=Proxy(proxy))
            mounts = {
                "all://": transport,
            }
        else:
            mounts = None

        client = AuthenticatedClient.for_api_key(
            api_key=api_key,
            base_url=api_url,
            verify_ssl=not insecure,
            cert=cacert,
            parse_response_behavior=ParseResponseBehavior.JSON_PARSING,
            mounts=mounts,
        )
        return cls(client)

    def get_workflow_id(self, input_workflow):
        """
        Check and return specified workflow id if it exists or id of the default workflow
        """
        if input_workflow is None:
            kwargs = {"is_default": True}
            workflows = get_workflows(client=self.client, **kwargs)["data"]["workflows"]
            if workflows:
                return _map_workflow(workflows[0])["id"]
        else:
            workflows = get_workflows(client=self.client)["data"]["workflows"]
            workflows = [_map_workflow(workflow) for workflow in workflows]
            for workflow in workflows:
                if workflow["name"] == input_workflow or workflow["id"] == input_workflow:
                    return workflow["id"]
            raise ValidationException(f"No workflow found with id or name <{input_workflow}>. Please check the value.")

    @lru_cache()
    def get_all_dts(self) -> list:
        dts = get_digital_twins(client=self.client)["data"]["dts"]
        return [_map_dt(dt) for dt in dts]

    def create_digital_twin(self, **kwargs):
        kwargs["version_info"] = DigitalTwinVersionCreationBase(
            name=kwargs.pop("version"),
            production_phase=kwargs.pop("production_phase", UNSET),
        )
        return _map_dt(create_digital_twin(client=self.client, multipart_data=DigitalTwinCreationPayload(**kwargs))["data"]["dt"])

    def create_dt_version(self, **kwargs):
        kwargs.pop("component_category", None)  # This is only needed to create component
        try:
            return _map_dt_version(
                create_digital_twin_version(
                    client=self.client,
                    multipart_data=CreateDigitalTwinVersionMultipartData(**kwargs),
                )[
                    "data"
                ]["dt_version"]
            )
        except FailedStatus as e:
            raise HandledException(str(e.response["error"]["message"]))

    def import_sbom_source_to_dt_version(self, **kwargs):
        kwargs["file_ids"] = kwargs.pop("resumable_identifiers")
        kwargs.pop("resumable_session_id", None)

        # These fields are only needed to create component or component version
        kwargs.pop("production_phase", None)
        kwargs.pop("component_category", None)

        return import_sbom_source(
            client=self.client,
            multipart_data=ImportSbomSourceMultipartData(**kwargs),
        )

    def get_digital_twin(self, dt_id: str):
        dts = get_digital_twins(client=self.client, dt_ids=[dt_id])["data"]["dts"]
        if dts:
            return _map_dt(dts[0])

    def get_vulnerabilities_assessments(self, dt_id: str):
        res = get_vulnerabilities_assessments(client=self.client, dt_ids=[dt_id])
        return [_map_assessment(ass) for ass in res["data"]["assessments"]]

    def create_vulnerabilities_assessment(self, **kwargs):
        va_profile_name = kwargs.pop("va_profile_name")
        auto_start = kwargs.pop("va_auto_start")
        if va_profile_name:
            kwargs["virtual_analyst_profile"] = CreateVulnerabilitiesAssessmentJsonBodyVirtualAnalystProfile(
                name=va_profile_name,
                auto_start=auto_start,
            )

        return _map_assessment(
            create_vulnerabilities_assessment(
                client=self.client,
                json_body=CreateVulnerabilitiesAssessmentJsonBody(**kwargs),
            )[
                "data"
            ]["assessment"]
        )

    def get_active_vulnerabilities_assessments(self, assessment_id: str):
        assessments = get_vulnerabilities_assessments(client=self.client, assessments_ids=[assessment_id])["data"]["assessments"]
        return [_map_assessment(ass) for ass in assessments]

    def get_zero_days_assessments(self, dt_id: str):
        assessments = get_zero_days_assessments(client=self.client, dt_ids=[dt_id])["data"]["assessments"]
        return [_map_assessment(ass) for ass in assessments]

    def create_zero_days_assessment(self, **kwargs):
        return _map_assessment(
            create_zero_days_assessment(client=self.client, json_body=CreateZeroDaysAssessmentJsonBody(**kwargs))["data"]["assessment"]
        )

    def upgrade_zero_days_assessment(self, assessment_id: str):
        return _map_assessment(
            upgrade_zero_days_assessment(
                client=self.client,
                json_body=UpgradeZeroDaysAssessmentJsonBody(assessment_id=assessment_id),
            )[
                "data"
            ]["assessment"]
        )

    def get_active_zero_days_assessment(self, assessment_id: str):
        assessments = get_zero_days_assessments(client=self.client, assessments_ids=[assessment_id])["data"]["assessments"]
        if assessments:
            return _map_assessment(assessments[0])

    def get_policies_assessments(self, dt_id: str):
        assessments = get_policies_assessments(client=self.client, dt_ids=[dt_id])["data"]["assessments"]

        return [_map_policy_assessment(ass) for ass in assessments]

    def create_policies_assessment(self, **kwargs):
        return _map_policy_assessment(
            create_policies_assessment(client=self.client, json_body=CreatePoliciesAssessmentJsonBody(**kwargs))["data"]["assessment"]
        )

    def upgrade_policies_assessment(self, assessment_id: str):
        return _map_policy_assessment(
            upgrade_policies_assessment(
                client=self.client,
                json_body=UpgradePoliciesAssessmentJsonBody(assessment_id=assessment_id),
            )[
                "data"
            ]["assessment"]
        )

    def get_active_policies_assessment(self, assessments_ids: list[str]):
        assessments = get_policies_assessments(client=self.client, assessments_ids=assessments_ids)["data"]["assessments"]

        return [_map_policy_assessment(ass) for ass in assessments]

    def get_policies(self):
        policies = get_policies(client=self.client, requirements=False)["data"]["policies"]
        return [_map_policy(policy) for policy in policies]

    def get_system_version(self):
        return get_system_information(client=self.client)["data"]["system_version"]

    def get_intelligence_db_version(self):
        return get_intelligence_database_version(client=self.client)["data"]["db_version"]["version"]

    def get_global_packages_db_version(self):
        return get_global_packages_database_version(client=self.client)["data"]["db_version"]["version"]

    def get_policies_db_version(self):
        return get_policies_database_version(client=self.client)["data"]["db_version"]["version"]

    def get_vulnerabilities_db_version(self):
        vulns_version = get_vulnerabilities_database_version(client=self.client)["data"]["db_version"]
        parts = []

        # Version information
        if "code_version" in vulns_version and vulns_version["code_version"]:
            parts.append(f"Version {vulns_version['code_version']}")

        # Commit information (shortened for readability)
        if "code_commit_ref" in vulns_version and vulns_version["code_commit_ref"]:
            short_commit = vulns_version["code_commit_ref"][:7]
            parts.append(f"Commit {short_commit}")

        # Timestamps
        if "code_timestamp" in vulns_version and vulns_version["code_timestamp"]:
            code_time = vulns_version["code_timestamp"].split("T")[0]  # Just get the date part
            parts.append(f"Code from {code_time}")

        if "data_timestamp" in vulns_version and vulns_version["data_timestamp"]:
            data_time = vulns_version["data_timestamp"].split("T")[0]
            parts.append(f"Data from {data_time}")

        if "private_data_timestamp" in vulns_version and vulns_version["private_data_timestamp"]:
            private_time = vulns_version["private_data_timestamp"].split("T")[0]
            parts.append(f"Private data from {private_time}")

        # Schema version
        if "schema_version" in vulns_version and vulns_version["schema_version"]:
            parts.append(f"Schema v{vulns_version['schema_version']}")

        if not parts and "version" in vulns_version:
            return vulns_version["version"]

        return " | ".join(parts)

    def get_resumable_upload_status(self, session_id, resumable_identifier, resumable_chunk_number):
        return get_resumable_upload_status(
            client=self.client,
            session_id=session_id,
            resumable_identifier=resumable_identifier,
            resumable_chunk_number=resumable_chunk_number,
        )

    def create_session(self, data):
        return create_session(client=self.client, json_body=CreateSessionJsonBody.from_dict(data))

    def upload_file_chunk(self, data):
        multipart_data = UploadFileChunkMultipartData(file=File(**data.pop("file")), **data)
        with self.with_parse_response_behavior(ParseResponseBehavior.RAW_RESPONSE):
            return upload_file_chunk(client=self.client, multipart_data=multipart_data)

    def export_digital_twin_cyclonedx(self, dt_version_id, exclude_packages_with_tags=None, include_vulnerabilities_data=False):
        with self.with_parse_response_behavior(ParseResponseBehavior.RAW_RESPONSE):
            return export_digital_twin_cyclonedx(
                client=self.client,
                dt_version_id=dt_version_id,
                exclude_packages_with_tags=exclude_packages_with_tags,
                include_vulnerabilities_data=include_vulnerabilities_data,
            )

    def export_vex_report(self, dt_version_id, exclude_packages_with_tags):
        with self.with_parse_response_behavior(ParseResponseBehavior.RAW_RESPONSE):
            return export_vex_report(client=self.client, dt_version_id=dt_version_id, exclude_packages_with_tags=exclude_packages_with_tags)

    def upload_from_url(self, session_id, url):
        return upload_from_url(client=self.client, json_body=UploadFromUrlJsonBody(session_id=session_id, url=url))

    def get_file_upload_status(self, session_id=None, file_ids=None):
        return get_file_upload_status(client=self.client, session_id=session_id, file_ids=file_ids)

    @lru_cache()
    def _cached_products(self):
        products = get_products(client=self.client)["data"]["products"]
        return [_map_product(product) for product in products]

    def find_product_version_id(self, id_or_name: str, version: Optional[str]) -> Optional[str]:
        normalized_value = id_or_name.lower()

        found_products = []
        data = self._cached_products()

        for product in data:
            if product["id"].lower() == normalized_value or product["name"].lower() == normalized_value:
                found_products.append(product)

        if len(found_products) > 1:
            raise ProductNameAmbiguousError(
                f"Ambiguous name for product ({id_or_name}).\n"
                f"Found records with following ids: {[p['id'] for p in found_products]}.\n"
                f"Please specify id instead of name."
            )

        if not found_products:
            return None

        if version:
            normalized_version = version.lower().strip()
            for v in found_products[0]["versions"]:
                if v["name"].strip().lower() == normalized_version or v["id"].strip().lower() == normalized_version:
                    return v["id"]
        else:
            for v in found_products[0]["versions"]:
                if v["status"] == "default":
                    return v["id"]

        return None

    def find_component(self, id_or_name: str, version: Optional[str]) -> Optional[str]:
        normalized_value = id_or_name.lower()
        for component in self.get_all_dts():
            if component["id"].lower() == normalized_value or component["name"].lower() == normalized_value:
                if version:
                    normalized_version = version.lower().strip()
                    return next(
                        (
                            version["id"]
                            for version in component["dt_versions"]
                            if version["id"] == normalized_version or version["name"].lower().strip() == normalized_version
                        ),
                        None,
                    )
                else:
                    return next(
                        (version["id"] for version in component["dt_versions"] if version["status"] == DigitalTwinVersionStatus.ACTIVE),
                        None,
                    )

    def get_parent_architecture(self, product_id):
        return _map_product_architecture(
            get_product_version_architecture(client=self.client, product_version_id=product_id)["data"]["product_architecture"]
        )

    def attach_to_product(self, parent_id, element_id, element_type):
        attach_element_to_product_version(
            client=self.client,
            json_body=AttachElementToProductVersionJsonBody(
                product_version_id=parent_id,
                element_id=element_id,
                element_type=element_type,
            ),
        )

    def get_valid_lifecycle_phases(self):
        entity = "asset_version"
        field = "production_phase"
        return _map_valid_lifecycle_phases(
            retrieve_field_custom_values(client=self.client, entity=entity, field=field)["data"]["field_custom_values"]
        )

    def get_valid_component_types(self):
        entity = "asset"
        field = "component_category"
        return _map_valid_component_types(
            retrieve_field_custom_values(client=self.client, entity=entity, field=field)["data"]["field_custom_values"]
        )

    @contextmanager
    def timeout(self, value):
        _saved_value = self.client.timeout
        self.client.timeout = value
        yield
        self.client.timeout = _saved_value

    @contextmanager
    def with_parse_response_behavior(self, parse_response_behavior: ParseResponseBehavior):
        """
        Temporarily disables response parsing in the client and returns to default (ParseResponseBehavior.JSON_PARSING).
        """
        self._response_behavior_stack.append(self.client.parse_response_behavior)
        try:
            self.client.parse_response_behavior = parse_response_behavior
            yield
        except Exception as e:
            raise HandledException(f"Error in with_parse_response_behavior context - {str(e)}")
        finally:
            self.client.parse_response_behavior = self._response_behavior_stack.pop()
