import re
from argparse import SUPPRESS

from cli_use_client.models.dt_creation_types import DtCreationTypes
from cybellum_cli.exceptions import ValidationException
from cybellum_cli.handlers.component import ComponentCommand
from cybellum_cli.parsers.common import add_common_arguments
from cybellum_cli.parsers.report import add_report_command

from ..constants import WORKFLOW_INCOMPATIBLE_ARGUMENTS, UploadZippingPolicy


def add_component_command(top_level_commands):
    dt_parser = top_level_commands.add_parser("component", help="Group of commands to operate a component")
    dt_parser.set_defaults(command_class=None, validators=[], parser=dt_parser)

    component_commands = dt_parser.add_subparsers()

    # Create a subparser for "version"
    version_parser = component_commands.add_parser("version", help="Commands related to component versions")
    version_commands = version_parser.add_subparsers()

    # Add commands
    _component_create_version(component_commands)
    _component_version_add_source(version_commands)


def _add_source_arguments(command):
    # Source
    source_group = command.add_argument_group("Source")
    source_group.add_argument(
        "--from-urls",
        "--from_urls",
        help="Load files from the network by URL. Can be many",
        nargs="*",
        metavar="URL",
    )
    source_group.add_argument(
        "--from-path",
        "--from_path",
        help="Load files from the local filesystem. Can be file or folder",
        metavar="PATH",
    )
    source_group.add_argument("--commit-log", "--commit_log", help="Git log file", metavar="PATH")
    source_group.add_argument(
        "--black-list",
        "--black_list",
        nargs="*",
        help='The list of file extension masks to exclude. Example: "*.dll *.json"',
        metavar="NAME",
    )

    source_group.add_argument(
        "--creation_type",
        help="Creation type",
        choices=[creation_type.value for creation_type in DtCreationTypes],
        default=DtCreationTypes.CREATE_FROM_FIRMWARE.value,
        metavar="TYPE",
    )

    source_group.add_argument(
        "--skip-resumable-upload",
        "--skip_resumable_upload",
        help="Whether to skip the resumable upload api that handle connectivity issues",
        action="store_true",
    )

    source_group.add_argument(
        "--upload-zipping-policy",
        "--upload_zipping_policy",
        metavar="POLICY",
        choices=[policy.value for policy in UploadZippingPolicy],
        default=UploadZippingPolicy.ZIP_MULTIPLE_FILES.value,
        help=(
            "Strategy for zipping files uploaded: "
            "'never' disables zipping, "
            "'always' enables zipping, "
            "'zip_multiple_files' (default) zips only when multiple files are uploaded."
        ),
    )

    source_group.add_argument(
        "--concurrent-uploads",
        "--concurrent_uploads",
        help="Number of concurrent chunks for resumable upload (default=10)",
        default=10,
    )

    source_group.add_argument(
        "--file-chunk-size",
        "--file_chunk_size",
        help="Size of file chunks for resumable upload (default=5Mb)",
        default=5,
    )


def _component_version_add_source(digital_twin_commands):
    add_report_command(digital_twin_commands)

    add_source_parser = digital_twin_commands.add_parser("add-source", help="Adds a new source to an existing component version")
    add_source_parser.set_defaults(
        command_class=ComponentCommand,
        method="add_source_to_version",
        validators=[_check_source_parameters],
        parser=add_source_parser,
    )

    # Target + Authentication + Connectivity
    add_common_arguments(add_source_parser)

    # Component identification
    component_group = add_source_parser.add_argument_group("Component Version")
    component_group.add_argument("--name", help="Name of the component (required)", required=True, metavar="NAME")

    component_group.add_argument("--version", help="Component version (required)", required=True, metavar="VERSION")

    # Source
    _add_source_arguments(add_source_parser)


def _component_create_version(digital_twin_commands):
    create_dt_version_parser = digital_twin_commands.add_parser("create-version", help="Creates a new component or it's version")
    create_dt_version_parser.set_defaults(
        command_class=ComponentCommand,
        method="create_dt_version",
        validators=[
            _default_behavior,
            _clean_timeout,
            _check_microcontroller_parameters,
            _check_va_parameters,
            _check_workflow_incompatibility,
            _check_parent_version_argument,
            _check_source_parameters,
        ],
        parser=create_dt_version_parser,
    )

    # Target + Authentication + Connectivity
    add_common_arguments(create_dt_version_parser)

    # Component
    component_group = create_dt_version_parser.add_argument_group("Component")
    component_group.add_argument("--name", help="Name of the component (required)", required=True, metavar="NAME")

    component_create_group = component_group.add_mutually_exclusive_group(required=False)
    component_create_group.add_argument(
        "--auto-create-component",
        "--auto-create",
        help=SUPPRESS,
        action="store_true",
        default=False,
    )
    component_create_group.add_argument(
        "--create-component",
        help="Whether to create a new component or not",
        default="never",
        choices=[
            "never",
            "always",
            "when-not-exists",
        ],
    )

    component_group.add_argument(
        "--component-type",
        "--component_type",
        help="Category or type of the component",
        metavar="NAME",
    )
    component_group.add_argument(
        "--micro-controller",
        "--micro_controller",
        help="Set if its a micro controller ",
        action="store_true",
        default=False,
    )
    component_group.add_argument(
        "--autosar",
        help="Set if its an AUTOSAR firmware ",
        action="store_true",
        default=False,
    )
    component_group.add_argument(
        "--business-unit",
        "--business_unit",
        help="Connect the component version to the specified business unit",
        metavar="NAME",
    )

    component_group.add_argument(
        "--auto-fix-import-issues",
        "--auto_fix_import_issues",
        help="Auto fix SBOM import errors (default=False)",
        action="store_true",
        default=False,
    )

    # Version
    dt_version_group = create_dt_version_parser.add_argument_group("Version")
    dt_version_group.add_argument("--version", help="Component version (required)", required=True, metavar="VERSION")

    version_position_group = dt_version_group.add_mutually_exclusive_group(required=False)
    version_position_group.add_argument(
        "--from-version",
        help="Parent version to create the new version from",
        required=False,
        metavar="VERSION",
    )
    version_position_group.add_argument(
        "--root-version",
        help="If set, newly generated version will be root",
        action="store_true",
        default=False,
        required=False,
    )
    version_position_group.add_argument(
        "--from-default-version",
        help="If set, newly generated version will be created from the default version",
        action="store_true",
        default=False,
        required=False,
    )

    default_version_group = dt_version_group.add_mutually_exclusive_group(required=False)
    default_version_group.add_argument(
        "--make-default-version",
        help="If set, newly generated version will be marked as default even if parent version is not the default one",
        action="store_true",
        default=False,
        required=False,
    )
    default_version_group.add_argument(
        "--retain-default-version",
        help="If set, the previously default version will retain its default status",
        action="store_true",
        default=False,
        required=False,
    )

    dt_version_group.add_argument(
        "--lifecycle-phase",
        "--lifecycle_phase",
        help="Set the component lifecycle phase",
        metavar="PHASE",
    )

    # Source
    _add_source_arguments(create_dt_version_parser)

    # Workflow
    main_workflow_group = create_dt_version_parser.add_argument_group("Assessments workflow")
    workflow_group = main_workflow_group.add_mutually_exclusive_group()
    workflow_group.add_argument(
        "--workflow",
        "--workflow",
        help="Workflow ID (or name) to start after creation of component version",
        metavar="WORKFLOW",
    )
    workflow_group.add_argument(
        "--no-workflow",
        "--no_workflow",
        help="Do not use workflow",
        action="store_true",
        default=False,
    )

    # Flow options
    flow_args = create_dt_version_parser.add_argument_group("Flow options")
    flow_args.add_argument(
        "--wait-for-completion",
        "--wait_for_completion",
        help="Wait until all command actions are completed",
        action="store_true",
    )
    flow_args.add_argument(
        "--timeout",
        help="timeout (Default: 24H). Use a number with a following symbol of time (H-hour, M-minutes, S-seconds, ex. 30M, 60S, 12H)",
        default="24H",
        metavar="VALUE",
    )
    flow_args.add_argument(
        "--status-interval",
        "--status_interval",
        type=int,
        help="Status request interval in seconds (Default: 5)",
        default=5,
        metavar="VALUE",
    )

    flow_args.add_argument(
        "--delete-files",
        "--delete_files",
        help="Wait till the end and delete extracted files",
        action="store_true",
    )

    define_assessment_parser(create_dt_version_parser)


def define_assessment_parser(parser):
    va_group = parser.add_argument_group("Known vulnerabilities assessment")
    va_group.add_argument(
        "--vulnerabilities",
        help="Create a new vulnerability assessment",
        action="store_true",
    )
    va_group.add_argument(
        "--va-autostart",
        "--va_autostart",
        help="Run newly created assessment",
        action="store_true",
    )
    va_group.add_argument(
        "--va-profile",
        "--va_profile",
        help="Profile name for the assessment",
        metavar="NAME",
    )

    zd_group = parser.add_argument_group("Zero days assessment")
    zd_group.add_argument(
        "--zero-days",
        "--zero_days",
        help="Create and run zero days assessment",
        action="store_true",
    )

    policy_group = parser.add_argument_group("Policy assessment")
    policy_group.add_argument(
        "--policies",
        help="List of policy ids (or names). Start policy assessment if any specified",
        nargs="*",
        metavar="POLICY_ID",
    )


def _default_behavior(_, args):
    if args.auto_create_component:
        args.create_component = "when-not-exists"

    if not args.retain_default_version and not args.make_default_version:
        args.make_default_version = True

    if not args.root_version and not args.from_version and not args.from_default_version:
        args.from_default_version = True


def _clean_timeout(_, args):
    multipliers = {
        "H": 60 * 60,
        "M": 60,
        "S": 1,
    }
    m = re.match(r"(?P<num>\d+)(?P<symbol>[HMS])", args.timeout)
    if m:
        multiplier = multipliers[m.groupdict()["symbol"]]
        args.timeout_seconds = int(m.groupdict()["num"]) * multiplier
    else:
        raise ValidationException(
            "Wrong format for the timeout. Use a number with a following symbol of time (H-hour, M-minutes, S-seconds, ex. 30M, 60S, 12H)"
        )


def _check_microcontroller_parameters(_, args):
    if args.autosar and not args.micro_controller:
        raise ValidationException("--autosar may be set only alongside --micro-controller option")


def _check_va_parameters(_, args):
    if (args.va_profile or args.va_autostart) and not args.vulnerabilities:
        raise ValidationException("--va-profile and --va-autostart may be set only alongside --vulnerabilities option")


def _check_source_parameters(_, args):
    if not args.from_path and not args.from_urls:
        raise ValidationException("--from-urls/--from-path is required")


def _check_workflow_incompatibility(_, args):
    if not args.no_workflow:
        assessment_args = ["--" + arg for arg in WORKFLOW_INCOMPATIBLE_ARGUMENTS if getattr(args, arg)]
        if assessment_args:
            raise ValidationException(
                f"You added the following assessment options: {', '.join(assessment_args)}. Also add --no-workflow explicitly"
            )


def _check_parent_version_argument(_, args):
    if args.retain_default_version and args.create_component != "never":
        raise ValidationException(
            "'--retain-default-version' conflicts with '--create-component always' or '--create-component auto'. "
            "Replace '--retain-default-version' with '--make-default-version' flag if you are going to create a new component"
        )

    if args.from_version and args.create_component != "never":
        raise ValidationException(
            "'--from-version' conflicts with '--create-component always' or '--create-component auto'. "
            "Use '--create-component never' flag if you are going to provide parent version"
        )
