"""A brute-copy of this library - , for ease of maintenance -"""

from .core import Resumable
