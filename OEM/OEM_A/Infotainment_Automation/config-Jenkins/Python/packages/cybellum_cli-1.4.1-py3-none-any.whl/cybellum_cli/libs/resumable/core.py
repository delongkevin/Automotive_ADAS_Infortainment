import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import partial

from cli_use_client.models import ResumableUploadFileInfoState
from cybellum_cli.exceptions import HandledException
from cybellum_cli.libs.resumable.chunk import resolve_chunk
from cybellum_cli.libs.resumable.file import ResumableFile
from cybellum_cli.libs.resumable.util import CallbackDispatcher, Config

MiB = 1024 * 1024
MAX_FILE_UPLOAD_PROGRESS_RETRIES = 1800
RETRY_INTERVAL = 2


class Resumable(object):
    """A resumable.py upload client.
    Parameters
    ----------
    client : AuthenticatedClient
        The client object
    session_id : str
        An identifier of resumable session
    test_chunks : bool
    chunk_size : int, optional
        The size, in bytes, of file chunks to be uploaded
    simultaneous_uploads : int, optional
        The number of file chunk uploads to attempt at once
        Flag indicating if the client should check with the server if a chunk
        already exists with a GET request prior to attempting to upload the
        chunk with a POST
    max_chunk_retries : int, optional
        The number of times to retry uploading a chunk
    permanent_errors : collection of int, optional
        HTTP status codes that indicate the upload of a chunk has failed and
        should not be retried
    """

    def __init__(
        self,
        client,
        session_id,
        chunk_size=MiB,
        simultaneous_uploads=3,
        headers=None,
        test_chunks=True,
        max_chunk_retries=100,
        permanent_errors=(400, 404, 415, 500, 501),
    ):
        self.config = Config(
            client=client,
            session_id=session_id,
            chunk_size=chunk_size,
            simultaneous_uploads=simultaneous_uploads,
            headers=headers,
            test_chunks=test_chunks,
            max_chunk_retries=max_chunk_retries,
            permanent_errors=permanent_errors,
        )

        self.files = []

        self.executor = ThreadPoolExecutor(simultaneous_uploads)
        self.futures = []

        self.file_added = CallbackDispatcher()
        self.file_completed = CallbackDispatcher()
        self.chunk_completed = CallbackDispatcher()

    def add_file(self, path):
        """Add a file to be uploaded.
        Parameters
        ----------
        path : str
            The file of the path to be uploaded
        Returns
        -------
        resumable.file.ResumableFile
        """

        file = ResumableFile(path, self.config.chunk_size)
        self.files.append(file)

        self.file_added.trigger(file)
        file.completed.register(partial(self.file_completed.trigger, file))
        file.chunk_completed.register(partial(self.chunk_completed.trigger, file))

        try:
            for chunk in file.chunks:
                future = self.executor.submit(resolve_chunk, self.config, file, chunk)
                self.futures.append(future)
        except Exception as e:
            logging.error(f"Error adding file chunks: {e}")
            raise

        return file

    def _wait(self):
        """Wait until all current uploads are completed."""
        for future in as_completed(self.futures):
            try:
                future.result()  # Will raise any exceptions that occurred during upload
            except Exception as e:
                logging.error(f"Upload chunk failed: {e}")
                raise

    def _wait_for_session_complete(self):
        for _ in range(MAX_FILE_UPLOAD_PROGRESS_RETRIES):
            try:
                session_files = self.config.client.get_file_upload_status(session_id=self.config.session_id).parsed["data"]["files"]

                if not self._is_any_file_processing_running(session_files):
                    break

                time.sleep(RETRY_INTERVAL)
            except Exception as e:
                logging.error(f"Error checking file upload status: {e}")
                raise
        else:
            raise HandledException("Get file upload status timeout exceeded")

    def _is_any_file_processing_running(self, session_files):
        for session_file in session_files:
            logging.info(f"Current file upload state: {session_file['state']}, file_id: {session_file['id']}")
            if session_file["state"] != ResumableUploadFileInfoState.COMPLETED:
                return True

        return False

    def _cancel_remaining_futures(self):
        for future in self.futures:
            if not future.done():
                future.cancel()

    def join(self):
        """Block until all uploads are complete, or an error occurs."""
        try:
            self._wait()
            self._wait_for_session_complete()
        except Exception:
            self._cancel_remaining_futures()
            raise
        finally:
            self.executor.shutdown()
            for file in self.files:
                file.close()

    def __enter__(self):
        return self

    def __exit__(self, *args, **kwargs):
        self.join()
