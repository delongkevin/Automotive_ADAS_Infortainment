import json
import logging
import sys
from http import HTTPStatus

from ..exceptions import ValidationException
from .shared import Command


class ReportCommand(Command):

    def __init__(self, *args, **kwargs):
        super(ReportCommand, self).__init__(*args, **kwargs)

        self.component_name = self.args.name
        self.component_version = self.args.version

    def download_report(self):
        dt_version_id = self.client.find_component(self.component_name, self.component_version)
        if not dt_version_id:
            raise ValidationException(f"Failed to find component {self.component_name} with version {self.component_version}")

        report_func = None

        # Determine the report data based on the report type and arguments
        if self.args.with_vulnerabilities and not self.args.with_packages:

            def export_vex_report():
                return self.client.export_vex_report(
                    dt_version_id,
                    exclude_packages_with_tags=self.args.exclude_tags,
                )

            logging.debug("Selecting export_vex_report")
            report_func = export_vex_report
        else:

            def export_digital_twin_cyclonedx():
                return self.client.export_digital_twin_cyclonedx(
                    dt_version_id,
                    exclude_packages_with_tags=self.args.exclude_tags,
                    include_vulnerabilities_data=self.args.with_vulnerabilities,
                )

            logging.debug("Selecting export_digital_twin_cyclonedx")
            report_func = export_digital_twin_cyclonedx

        if not report_func:
            raise ValidationException(f"Failed to find report function for {self.args.report_type}")

        with open(self.args.output, "wb") if self.args.output else open(sys.stdout.fileno(), "wb", closefd=False) as output_stream:

            result = report_func()

            if result.status_code != HTTPStatus.OK:
                logging.error("Error response for the report")
                exit(1)

            if result.is_stream_consumed:
                output_stream.write(result.content)
            else:
                for chunk in result.iter_raw(self.args.chunk_size):
                    output_stream.write(chunk)

            output_stream.flush()
