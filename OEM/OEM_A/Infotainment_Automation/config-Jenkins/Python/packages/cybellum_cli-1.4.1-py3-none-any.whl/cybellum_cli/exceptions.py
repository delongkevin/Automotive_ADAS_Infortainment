class HandledException(Exception):
    pass


class ValidationException(Exception):
    pass


class APIException(Exception):
    pass


class AuthenticationException(Exception):
    pass


class VersionError(Exception):
    def __init__(self, version):
        self.version = version


class ServerVersionError(VersionError):
    pass


class CLIVersionError(VersionError):
    pass


class ProductNameAmbiguousError(Exception):
    pass
