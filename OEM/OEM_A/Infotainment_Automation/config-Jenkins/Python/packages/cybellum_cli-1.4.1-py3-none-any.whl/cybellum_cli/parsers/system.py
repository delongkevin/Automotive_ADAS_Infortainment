from cybellum_cli.exceptions import ValidationException
from cybellum_cli.handlers.system import SystemCommand
from cybellum_cli.parsers.common import add_common_arguments


def add_system_command(top_level_commands):
    system_parser = top_level_commands.add_parser("system", help="Group of commands to operate systems")
    system_parser.set_defaults(command_class=None, validators=[], parser=system_parser)

    system_commands = system_parser.add_subparsers()

    _system_commands_add_attach(system_commands)


def _system_commands_add_attach(system_commands):
    attach_component_parser = system_commands.add_parser("attach", help="Attach a component to the specified product or system")
    attach_component_parser.set_defaults(
        command_class=SystemCommand,
        method="attach",
        validators=[_clean_product_or_component],
        parser=attach_component_parser,
    )

    # Target + Authentication + Connectivity
    add_common_arguments(attach_component_parser)

    parent_group = attach_component_parser.add_argument_group("Parent (required)")
    parent_group.add_argument(
        "--parent",
        required=True,
        help="Either id or name of the product/system to attach the component to",
        metavar="ID/NAME",
    )
    parent_group.add_argument(
        "--parent-version",
        help="Specific version of the parent product/system to attach component to",
        metavar="VERSION",
    )
    parent_group.add_argument(
        "--parent-default-version",
        action="store_true",
        help="Component will be attached to the default version of product/version",
    )
    product_group = attach_component_parser.add_argument_group("Child Product")
    product_group.add_argument("--product", dest="product", help="Product to be attached", metavar="ID/NAME")
    product_group.add_argument(
        "--product-version",
        dest="product_version",
        help="Product version to be attached",
        metavar="VERSION",
    )
    product_group.add_argument(
        "--product-default-version",
        action="store_true",
        dest="product_default_version",
        help="Default version of the product will be attached",
    )
    component_group = attach_component_parser.add_argument_group("Child Component")
    component_group.add_argument(
        "--component",
        dest="component",
        help="Component to be attached",
        metavar="ID/NAME",
    )
    component_group.add_argument(
        "--component-version",
        dest="component_version",
        help="Component version to be attached",
        metavar="VERSION",
    )
    component_group.add_argument(
        "--component-default-version",
        action="store_true",
        dest="component_default_version",
        help="Default version of the component will be attached",
    )


def _clean_product_or_component(parser, args):
    if not (args.product or args.component):
        raise ValidationException("At least one product or component should be specified")

    if bool(args.parent_version) + bool(args.parent_default_version) != 1:
        raise ValidationException("One of 'parent-version' or 'parent-default-version' should be specified")

    if args.product and args.component:
        raise ValidationException("Only one product or component should be specified")

    if args.product and (args.component_version or args.component_default_version):
        raise ValidationException("'component-version' or 'component-default-version' can be specified only with 'component' argument")

    if args.component and (args.product_version or args.product_default_version):
        raise ValidationException("'product-version' or 'product-default-version' can be specified only with 'product' argument")

    if args.component and bool(args.component_version) + bool(args.component_default_version) != 1:
        raise ValidationException("One of 'component-version' or 'component-default-version' should be specified")

    if args.product and bool(args.product_version) + bool(args.product_default_version) != 1:
        raise ValidationException("One of 'product-version' or 'product-default-version' should be specified")
