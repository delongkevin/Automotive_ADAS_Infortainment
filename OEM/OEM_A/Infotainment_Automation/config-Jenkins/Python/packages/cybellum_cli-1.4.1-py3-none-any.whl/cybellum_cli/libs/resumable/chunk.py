import json
import logging
import mimetypes
import os


class ResumableError(Exception):
    pass


def resolve_chunk(config, file, chunk):
    """Make sure a chunk is uploaded to the server and mark it as completed.
    Parameters
    ----------
    config : resumable.util.Config
        The configuration of the resumable session
    file : resumable.file.ResumableFile
        The parent file of the chunk to be resolved
    chunk : resumable.file.FileChunk
        The chunk to be resolved
    """

    exists_on_server = False
    if config.test_chunks:
        exists_on_server = _test_chunk(config, file, chunk)

    if not exists_on_server:
        tries = 0
        while not _send_chunk(config, file, chunk):
            tries += 1
            if tries >= config.max_chunk_retries:
                raise ResumableError("max retries exceeded")

    file.mark_chunk_completed(chunk)


def _test_chunk(config, file, chunk):
    """Check if the chunk exists on the server.
    Returns
    -------
    bool
        True if the chunk exists on the server
    """
    response = config.client.get_resumable_upload_status(
        session_id=config.session_id, resumable_identifier=str(file.unique_identifier), resumable_chunk_number=chunk.index + 1
    )
    return response.status_code == 200


def _send_chunk(config, file, chunk):
    """Upload the chunk to the server.
    Returns
    -------
    bool
        True if the upload was successful
    Raises
    ------
    ResumableError
        If the server responded with an error code indicating permanent failure
    """
    with config.client.timeout(120):
        response = config.client.upload_file_chunk(_build_post_query(file, chunk, config.session_id))
    if response.status_code in config.permanent_errors:
        raise ResumableError(f"permanent error {response.status_code}")
    if response.status_code not in [200, 201]:
        return False
    try:
        chunk.file_id = json.loads(response.content)["data"]["file_id"]
    except json.JSONDecodeError as e:
        logging.warning(f"Failed to decode JSON response: {e}")
        logging.debug(f"Response content: {response.content}")
        chunk.file_id = None
        return False

    return True


def _build_get_query(session_id, file, chunk):
    """Build the query parameters for a chunk test or upload."""
    return dict(
        session_id=session_id,
        resumable_identifier=str(file.unique_identifier),
        resumable_chunk_number=chunk.index + 1,
    )


def _build_post_query(file, chunk, session_id):
    """Build the query parameters for a chunk test or upload."""
    return dict(
        file=dict(
            payload=chunk.read(),
            file_name=f"{os.path.basename(file.path)}_chunk{chunk.index}",
            mime_type="application/octet-stream",
        ),
        resumable_identifier=str(file.unique_identifier),
        resumable_file_name=os.path.basename(file.path),
        resumable_total_chunks=len(file.chunks),
        resumable_chunk_number=chunk.index + 1,
        resumable_current_chunk_size=chunk.size,
        resumable_total_size=os.path.getsize(file.path),
        session_id=session_id,
    )


def _file_type(path):
    """Mimic the type parameter of a JS File object.
    Resumable.js uses the File object's type attribute to guess mime type,
    which is guessed from file extention accoring to
    https://developer.mozilla.org/en-US/docs/Web/API/File/type.
    Parameters
    ----------
    path : str
        The path to guess the mime type of
    Returns
    -------
    str
        The inferred mime type, or '' if none could be inferred
    """
    type_, _ = mimetypes.guess_type(path)
    # When no type can be inferred, File.type returns an empty string
    return "" if type_ is None else type_
