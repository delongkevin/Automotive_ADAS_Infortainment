from cybellum_cli.handlers.version import VersionCommand
from cybellum_cli.parsers.common import add_common_arguments


def add_version_command(top_level_commands):
    version_command = top_level_commands.add_parser(
        "version", help="Displays the current version of the CLI and the remote service and it's databases"
    )
    version_command.set_defaults(command_class=VersionCommand, method="versions_info", validators=[], parser=version_command)
    add_common_arguments(version_command, required=False)
