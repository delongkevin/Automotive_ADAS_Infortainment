from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.imported_sbom_data_components_item import ImportedSBOMDataComponentsItem
    from ..models.imported_sbom_data_dependencies_item import ImportedSBOMDataDependenciesItem
    from ..models.imported_sbom_data_license_text_item import ImportedSBOMDataLicenseTextItem
    from ..models.imported_sbom_data_metadata import ImportedSBOMDataMetadata
    from ..models.imported_sbom_data_primary_component import ImportedSBOMDataPrimaryComponent


T = TypeVar("T", bound="ImportedSBOMData")


@attr.s(auto_attribs=True)
class ImportedSBOMData:
    """An IntermediateSBOMResponse dict containing the normalized data for an imported CycloneDX or SPDX doc

    Attributes:
        components (Union[Unset, List['ImportedSBOMDataComponentsItem']]): Optional[conlist(ComponentData)]
        dependencies (Union[Unset, List['ImportedSBOMDataDependenciesItem']]): Optional[conlist(ComponentDependency)]
        license_text (Union[Unset, List['ImportedSBOMDataLicenseTextItem']]): Optional[conlist(LicenseText)]
        metadata (Union[Unset, ImportedSBOMDataMetadata]): SBOMMetaData
        primary_component (Union[Unset, ImportedSBOMDataPrimaryComponent]): Optional[ComponentData]
    """

    components: Union[Unset, List["ImportedSBOMDataComponentsItem"]] = UNSET
    dependencies: Union[Unset, List["ImportedSBOMDataDependenciesItem"]] = UNSET
    license_text: Union[Unset, List["ImportedSBOMDataLicenseTextItem"]] = UNSET
    metadata: Union[Unset, "ImportedSBOMDataMetadata"] = UNSET
    primary_component: Union[Unset, "ImportedSBOMDataPrimaryComponent"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        components: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.components, Unset):
            components = []
            for components_item_data in self.components:
                components_item = components_item_data.to_dict()

                components.append(components_item)

        dependencies: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.dependencies, Unset):
            dependencies = []
            for dependencies_item_data in self.dependencies:
                dependencies_item = dependencies_item_data.to_dict()

                dependencies.append(dependencies_item)

        license_text: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.license_text, Unset):
            license_text = []
            for license_text_item_data in self.license_text:
                license_text_item = license_text_item_data.to_dict()

                license_text.append(license_text_item)

        metadata: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        primary_component: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.primary_component, Unset):
            primary_component = self.primary_component.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if components is not UNSET:
            field_dict["components"] = components
        if dependencies is not UNSET:
            field_dict["dependencies"] = dependencies
        if license_text is not UNSET:
            field_dict["license_text"] = license_text
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if primary_component is not UNSET:
            field_dict["primary_component"] = primary_component

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.imported_sbom_data_components_item import ImportedSBOMDataComponentsItem
        from ..models.imported_sbom_data_dependencies_item import ImportedSBOMDataDependenciesItem
        from ..models.imported_sbom_data_license_text_item import ImportedSBOMDataLicenseTextItem
        from ..models.imported_sbom_data_metadata import ImportedSBOMDataMetadata
        from ..models.imported_sbom_data_primary_component import ImportedSBOMDataPrimaryComponent

        d = src_dict.copy()
        _components = d.pop("components", UNSET)
        if (_components) is UNSET:
            components = UNSET
        else:
            if _components:
                components = []
                for components_item_data in _components:
                    components_item = ImportedSBOMDataComponentsItem.from_dict(components_item_data)

                    components.append(components_item)
            else:
                components = []

        _dependencies = d.pop("dependencies", UNSET)
        if (_dependencies) is UNSET:
            dependencies = UNSET
        else:
            if _dependencies:
                dependencies = []
                for dependencies_item_data in _dependencies:
                    dependencies_item = ImportedSBOMDataDependenciesItem.from_dict(dependencies_item_data)

                    dependencies.append(dependencies_item)
            else:
                dependencies = []

        _license_text = d.pop("license_text", UNSET)
        if (_license_text) is UNSET:
            license_text = UNSET
        else:
            if _license_text:
                license_text = []
                for license_text_item_data in _license_text:
                    license_text_item = ImportedSBOMDataLicenseTextItem.from_dict(license_text_item_data)

                    license_text.append(license_text_item)
            else:
                license_text = []

        _metadata = d.pop("metadata", UNSET)
        metadata: Union[Unset, ImportedSBOMDataMetadata]
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = ImportedSBOMDataMetadata.from_dict(_metadata)

        _primary_component = d.pop("primary_component", UNSET)
        primary_component: Union[Unset, ImportedSBOMDataPrimaryComponent]
        if isinstance(_primary_component, Unset):
            primary_component = UNSET
        else:
            primary_component = ImportedSBOMDataPrimaryComponent.from_dict(_primary_component)

        imported_sbom_data = cls(
            components=components,
            dependencies=dependencies,
            license_text=license_text,
            metadata=metadata,
            primary_component=primary_component,
        )

        imported_sbom_data.additional_properties = d
        return imported_sbom_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
