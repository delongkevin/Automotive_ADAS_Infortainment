from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.imported_sbom_data_metadata_authors_item import ImportedSBOMDataMetadataAuthorsItem
    from ..models.imported_sbom_data_metadata_manufacturer import ImportedSBOMDataMetadataManufacturer
    from ..models.imported_sbom_data_metadata_properties_item import ImportedSBOMDataMetadataPropertiesItem
    from ..models.imported_sbom_data_metadata_supplier import ImportedSBOMDataMetadataSupplier
    from ..models.imported_sbom_data_metadata_tools import ImportedSBOMDataMetadataTools


T = TypeVar("T", bound="ImportedSBOMDataMetadata")


@attr.s(auto_attribs=True)
class ImportedSBOMDataMetadata:
    """SBOMMetaData

    Attributes:
        authors (Union[Unset, List['ImportedSBOMDataMetadataAuthorsItem']]):
        bom_ref (Union[Unset, str]):
        document_ref (Union[Unset, str]):
        manufacturer (Union[Unset, ImportedSBOMDataMetadataManufacturer]):
        name (Union[Unset, str]):
        namespace (Union[Unset, str]):
        properties (Union[Unset, List['ImportedSBOMDataMetadataPropertiesItem']]):
        serial_number (Union[Unset, str]):
        supplier (Union[Unset, ImportedSBOMDataMetadataSupplier]):
        timestamp (Union[Unset, str]):
        tools (Union[Unset, ImportedSBOMDataMetadataTools]):
        type (Union[Unset, str]): Allowed values: "application", "framework", "library", "container", "platform",
            "operating-system", "device", "device-driver", "firmware", "machine-learning-model", "data", "file", "hardware",
            "kernel", "source", "archive", "install", "other"
        version (Union[Unset, str]):
    """

    authors: Union[Unset, List["ImportedSBOMDataMetadataAuthorsItem"]] = UNSET
    bom_ref: Union[Unset, str] = UNSET
    document_ref: Union[Unset, str] = UNSET
    manufacturer: Union[Unset, "ImportedSBOMDataMetadataManufacturer"] = UNSET
    name: Union[Unset, str] = UNSET
    namespace: Union[Unset, str] = UNSET
    properties: Union[Unset, List["ImportedSBOMDataMetadataPropertiesItem"]] = UNSET
    serial_number: Union[Unset, str] = UNSET
    supplier: Union[Unset, "ImportedSBOMDataMetadataSupplier"] = UNSET
    timestamp: Union[Unset, str] = UNSET
    tools: Union[Unset, "ImportedSBOMDataMetadataTools"] = UNSET
    type: Union[Unset, str] = UNSET
    version: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        authors: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.authors, Unset):
            authors = []
            for authors_item_data in self.authors:
                authors_item = authors_item_data.to_dict()

                authors.append(authors_item)

        bom_ref = self.bom_ref
        document_ref = self.document_ref
        manufacturer: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.manufacturer, Unset):
            manufacturer = self.manufacturer.to_dict()

        name = self.name
        namespace = self.namespace
        properties: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.properties, Unset):
            properties = []
            for properties_item_data in self.properties:
                properties_item = properties_item_data.to_dict()

                properties.append(properties_item)

        serial_number = self.serial_number
        supplier: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.supplier, Unset):
            supplier = self.supplier.to_dict()

        timestamp = self.timestamp
        tools: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.tools, Unset):
            tools = self.tools.to_dict()

        type = self.type
        version = self.version

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if authors is not UNSET:
            field_dict["authors"] = authors
        if bom_ref is not UNSET:
            field_dict["bom_ref"] = bom_ref
        if document_ref is not UNSET:
            field_dict["document_ref"] = document_ref
        if manufacturer is not UNSET:
            field_dict["manufacturer"] = manufacturer
        if name is not UNSET:
            field_dict["name"] = name
        if namespace is not UNSET:
            field_dict["namespace"] = namespace
        if properties is not UNSET:
            field_dict["properties"] = properties
        if serial_number is not UNSET:
            field_dict["serial_number"] = serial_number
        if supplier is not UNSET:
            field_dict["supplier"] = supplier
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if tools is not UNSET:
            field_dict["tools"] = tools
        if type is not UNSET:
            field_dict["type"] = type
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.imported_sbom_data_metadata_authors_item import ImportedSBOMDataMetadataAuthorsItem
        from ..models.imported_sbom_data_metadata_manufacturer import ImportedSBOMDataMetadataManufacturer
        from ..models.imported_sbom_data_metadata_properties_item import ImportedSBOMDataMetadataPropertiesItem
        from ..models.imported_sbom_data_metadata_supplier import ImportedSBOMDataMetadataSupplier
        from ..models.imported_sbom_data_metadata_tools import ImportedSBOMDataMetadataTools

        d = src_dict.copy()
        _authors = d.pop("authors", UNSET)
        if (_authors) is UNSET:
            authors = UNSET
        else:
            if _authors:
                authors = []
                for authors_item_data in _authors:
                    authors_item = ImportedSBOMDataMetadataAuthorsItem.from_dict(authors_item_data)

                    authors.append(authors_item)
            else:
                authors = []

        bom_ref = d.pop("bom_ref", UNSET)

        document_ref = d.pop("document_ref", UNSET)

        _manufacturer = d.pop("manufacturer", UNSET)
        manufacturer: Union[Unset, ImportedSBOMDataMetadataManufacturer]
        if isinstance(_manufacturer, Unset):
            manufacturer = UNSET
        else:
            manufacturer = ImportedSBOMDataMetadataManufacturer.from_dict(_manufacturer)

        name = d.pop("name", UNSET)

        namespace = d.pop("namespace", UNSET)

        _properties = d.pop("properties", UNSET)
        if (_properties) is UNSET:
            properties = UNSET
        else:
            if _properties:
                properties = []
                for properties_item_data in _properties:
                    properties_item = ImportedSBOMDataMetadataPropertiesItem.from_dict(properties_item_data)

                    properties.append(properties_item)
            else:
                properties = []

        serial_number = d.pop("serial_number", UNSET)

        _supplier = d.pop("supplier", UNSET)
        supplier: Union[Unset, ImportedSBOMDataMetadataSupplier]
        if isinstance(_supplier, Unset):
            supplier = UNSET
        else:
            supplier = ImportedSBOMDataMetadataSupplier.from_dict(_supplier)

        timestamp = d.pop("timestamp", UNSET)

        _tools = d.pop("tools", UNSET)
        tools: Union[Unset, ImportedSBOMDataMetadataTools]
        if isinstance(_tools, Unset):
            tools = UNSET
        else:
            tools = ImportedSBOMDataMetadataTools.from_dict(_tools)

        type = d.pop("type", UNSET)

        version = d.pop("version", UNSET)

        imported_sbom_data_metadata = cls(
            authors=authors,
            bom_ref=bom_ref,
            document_ref=document_ref,
            manufacturer=manufacturer,
            name=name,
            namespace=namespace,
            properties=properties,
            serial_number=serial_number,
            supplier=supplier,
            timestamp=timestamp,
            tools=tools,
            type=type,
            version=version,
        )

        imported_sbom_data_metadata.additional_properties = d
        return imported_sbom_data_metadata

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
