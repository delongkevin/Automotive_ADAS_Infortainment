from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar(
    "T",
    bound="StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResultUnrecoverableErrorsItem",
)


@attr.s(auto_attribs=True)
class StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResultUnrecoverableErrorsItem:
    """
    Attributes:
        column_number (Union[Unset, int]):
        error_message (Union[Unset, str]):
        error_type (Union[Unset, str]):
        line_number (Union[Unset, int]):
        position (Union[Unset, int]):
    """

    column_number: Union[Unset, int] = UNSET
    error_message: Union[Unset, str] = UNSET
    error_type: Union[Unset, str] = UNSET
    line_number: Union[Unset, int] = UNSET
    position: Union[Unset, int] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        column_number = self.column_number
        error_message = self.error_message
        error_type = self.error_type
        line_number = self.line_number
        position = self.position

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if column_number is not UNSET:
            field_dict["column_number"] = column_number
        if error_message is not UNSET:
            field_dict["error_message"] = error_message
        if error_type is not UNSET:
            field_dict["error_type"] = error_type
        if line_number is not UNSET:
            field_dict["line_number"] = line_number
        if position is not UNSET:
            field_dict["position"] = position

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        column_number = d.pop("column_number", UNSET)

        error_message = d.pop("error_message", UNSET)

        error_type = d.pop("error_type", UNSET)

        line_number = d.pop("line_number", UNSET)

        position = d.pop("position", UNSET)

        status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_file_classification_result_unrecoverable_errors_item = cls(
            column_number=column_number,
            error_message=error_message,
            error_type=error_type,
            line_number=line_number,
            position=position,
        )

        status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_file_classification_result_unrecoverable_errors_item.additional_properties = (
            d
        )
        return status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_file_classification_result_unrecoverable_errors_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
