import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="CreatePoliciesAssessmentJsonBody")


@attr.s(auto_attribs=True)
class CreatePoliciesAssessmentJsonBody:
    """
    Attributes:
        dt_id (str): ID
        dt_version_id (str): ID
        name (str): Assessment name
        policy_id (str): Related policy id
        call_worker (Union[Unset, bool]): Indicator if start worker directly
        description (Union[Unset, str]): Assessment description
        detached (Union[Unset, bool]): Is assessment detached from previous assessments
        end_date (Union[Unset, datetime.datetime]): Assessment end date
        known_assessment_id (Union[Unset, str]): ID
        start_date (Union[Unset, datetime.datetime]): Assessment start date
        unknown_assessment_id (Union[Unset, str]): ID
    """

    dt_id: str
    dt_version_id: str
    name: str
    policy_id: str
    call_worker: Union[Unset, bool] = UNSET
    description: Union[Unset, str] = UNSET
    detached: Union[Unset, bool] = False
    end_date: Union[Unset, datetime.datetime] = UNSET
    known_assessment_id: Union[Unset, str] = UNSET
    start_date: Union[Unset, datetime.datetime] = UNSET
    unknown_assessment_id: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        dt_id = self.dt_id
        dt_version_id = self.dt_version_id
        name = self.name
        policy_id = self.policy_id
        call_worker = self.call_worker
        description = self.description
        detached = self.detached
        end_date: Union[Unset, str] = UNSET
        if not isinstance(self.end_date, Unset):
            end_date = self.end_date.isoformat()

        known_assessment_id = self.known_assessment_id
        start_date: Union[Unset, str] = UNSET
        if not isinstance(self.start_date, Unset):
            start_date = self.start_date.isoformat()

        unknown_assessment_id = self.unknown_assessment_id

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "dt_id": dt_id,
                "dt_version_id": dt_version_id,
                "name": name,
                "policy_id": policy_id,
            }
        )
        if call_worker is not UNSET:
            field_dict["call_worker"] = call_worker
        if description is not UNSET:
            field_dict["description"] = description
        if detached is not UNSET:
            field_dict["detached"] = detached
        if end_date is not UNSET:
            field_dict["end_date"] = end_date
        if known_assessment_id is not UNSET:
            field_dict["known_assessment_id"] = known_assessment_id
        if start_date is not UNSET:
            field_dict["start_date"] = start_date
        if unknown_assessment_id is not UNSET:
            field_dict["unknown_assessment_id"] = unknown_assessment_id

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        dt_id = d.pop("dt_id")

        dt_version_id = d.pop("dt_version_id")

        name = d.pop("name")

        policy_id = d.pop("policy_id")

        call_worker = d.pop("call_worker", UNSET)

        description = d.pop("description", UNSET)

        detached = d.pop("detached", UNSET)

        _end_date = d.pop("end_date", UNSET)
        end_date: Union[Unset, datetime.datetime]
        if isinstance(_end_date, Unset):
            end_date = UNSET
        else:
            end_date = isoparse(_end_date)

        known_assessment_id = d.pop("known_assessment_id", UNSET)

        _start_date = d.pop("start_date", UNSET)
        start_date: Union[Unset, datetime.datetime]
        if isinstance(_start_date, Unset):
            start_date = UNSET
        else:
            start_date = isoparse(_start_date)

        unknown_assessment_id = d.pop("unknown_assessment_id", UNSET)

        create_policies_assessment_json_body = cls(
            dt_id=dt_id,
            dt_version_id=dt_version_id,
            name=name,
            policy_id=policy_id,
            call_worker=call_worker,
            description=description,
            detached=detached,
            end_date=end_date,
            known_assessment_id=known_assessment_id,
            start_date=start_date,
            unknown_assessment_id=unknown_assessment_id,
        )

        create_policies_assessment_json_body.additional_properties = d
        return create_policies_assessment_json_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
