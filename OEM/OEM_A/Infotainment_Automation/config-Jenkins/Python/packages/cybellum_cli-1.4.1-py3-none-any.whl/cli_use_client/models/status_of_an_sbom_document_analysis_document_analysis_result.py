from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item import (
        StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItem,
    )
    from ..models.status_of_an_sbom_document_analysis_document_analysis_result_score import (
        StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScore,
    )


T = TypeVar("T", bound="StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResult")


@attr.s(auto_attribs=True)
class StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResult:
    """
    Attributes:
        file_path (Union[Unset, str]): File path for uploaded file
        invalid_objects (Union[Unset, List['StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItem']]):
        not_imported_sections (Union[Unset, List[str]]):
        score (Union[Unset, StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScore]): SBOMScore
    """

    file_path: Union[Unset, str] = UNSET
    invalid_objects: Union[Unset, List["StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItem"]] = (
        UNSET
    )
    not_imported_sections: Union[Unset, List[str]] = UNSET
    score: Union[Unset, "StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScore"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        file_path = self.file_path
        invalid_objects: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.invalid_objects, Unset):
            invalid_objects = []
            for invalid_objects_item_data in self.invalid_objects:
                invalid_objects_item = invalid_objects_item_data.to_dict()

                invalid_objects.append(invalid_objects_item)

        not_imported_sections: Union[Unset, List[str]] = UNSET
        if not isinstance(self.not_imported_sections, Unset):
            not_imported_sections = self.not_imported_sections

        score: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.score, Unset):
            score = self.score.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if file_path is not UNSET:
            field_dict["file_path"] = file_path
        if invalid_objects is not UNSET:
            field_dict["invalid_objects"] = invalid_objects
        if not_imported_sections is not UNSET:
            field_dict["not_imported_sections"] = not_imported_sections
        if score is not UNSET:
            field_dict["score"] = score

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item import (
            StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItem,
        )
        from ..models.status_of_an_sbom_document_analysis_document_analysis_result_score import (
            StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScore,
        )

        d = src_dict.copy()
        file_path = d.pop("file_path", UNSET)

        _invalid_objects = d.pop("invalid_objects", UNSET)
        if (_invalid_objects) is UNSET:
            invalid_objects = UNSET
        else:
            if _invalid_objects:
                invalid_objects = []
                for invalid_objects_item_data in _invalid_objects:
                    invalid_objects_item = (
                        StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItem.from_dict(
                            invalid_objects_item_data
                        )
                    )

                    invalid_objects.append(invalid_objects_item)
            else:
                invalid_objects = []

        not_imported_sections = cast(List[str], d.pop("not_imported_sections", UNSET))

        _score = d.pop("score", UNSET)
        score: Union[Unset, StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScore]
        if isinstance(_score, Unset):
            score = UNSET
        else:
            score = StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScore.from_dict(_score)

        status_of_an_sbom_document_analysis_document_analysis_result = cls(
            file_path=file_path,
            invalid_objects=invalid_objects,
            not_imported_sections=not_imported_sections,
            score=score,
        )

        status_of_an_sbom_document_analysis_document_analysis_result.additional_properties = d
        return status_of_an_sbom_document_analysis_document_analysis_result

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
