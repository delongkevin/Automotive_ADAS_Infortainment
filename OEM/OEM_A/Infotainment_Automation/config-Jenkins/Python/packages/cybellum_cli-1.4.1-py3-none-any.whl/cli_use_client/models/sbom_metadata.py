from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.sbom_metadata_authors_item import SbomMetadataAuthorsItem


T = TypeVar("T", bound="SbomMetadata")


@attr.s(auto_attribs=True)
class SbomMetadata:
    """sbom metadata from intermediate sbom

    Attributes:
        authors (Union[Unset, List['SbomMetadataAuthorsItem']]):
        name (Union[Unset, str]):
        timestamp (Union[Unset, str]):
        type (Union[Unset, str]):
        version (Union[Unset, str]):
    """

    authors: Union[Unset, List["SbomMetadataAuthorsItem"]] = UNSET
    name: Union[Unset, str] = UNSET
    timestamp: Union[Unset, str] = UNSET
    type: Union[Unset, str] = UNSET
    version: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        authors: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.authors, Unset):
            authors = []
            for authors_item_data in self.authors:
                authors_item = authors_item_data.to_dict()

                authors.append(authors_item)

        name = self.name
        timestamp = self.timestamp
        type = self.type
        version = self.version

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if authors is not UNSET:
            field_dict["authors"] = authors
        if name is not UNSET:
            field_dict["name"] = name
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if type is not UNSET:
            field_dict["type"] = type
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.sbom_metadata_authors_item import SbomMetadataAuthorsItem

        d = src_dict.copy()
        _authors = d.pop("authors", UNSET)
        if (_authors) is UNSET:
            authors = UNSET
        else:
            if _authors:
                authors = []
                for authors_item_data in _authors:
                    authors_item = SbomMetadataAuthorsItem.from_dict(authors_item_data)

                    authors.append(authors_item)
            else:
                authors = []

        name = d.pop("name", UNSET)

        timestamp = d.pop("timestamp", UNSET)

        type = d.pop("type", UNSET)

        version = d.pop("version", UNSET)

        sbom_metadata = cls(
            authors=authors,
            name=name,
            timestamp=timestamp,
            type=type,
            version=version,
        )

        sbom_metadata.additional_properties = d
        return sbom_metadata

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
