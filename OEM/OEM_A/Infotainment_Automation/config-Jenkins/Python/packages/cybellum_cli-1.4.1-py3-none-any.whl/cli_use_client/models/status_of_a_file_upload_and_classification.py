from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.status_of_a_file_upload_and_classification_file_classification_progress import (
        StatusOfAFileUploadAndClassificationFileClassificationProgress,
    )


T = TypeVar("T", bound="StatusOfAFileUploadAndClassification")


@attr.s(auto_attribs=True)
class StatusOfAFileUploadAndClassification:
    """The status (and eventually result) for a file upload and classification

    Attributes:
        file_classification_progress (Union[Unset, StatusOfAFileUploadAndClassificationFileClassificationProgress]):
        file_path (Union[Unset, str]):
    """

    file_classification_progress: Union[Unset, "StatusOfAFileUploadAndClassificationFileClassificationProgress"] = UNSET
    file_path: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        file_classification_progress: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.file_classification_progress, Unset):
            file_classification_progress = self.file_classification_progress.to_dict()

        file_path = self.file_path

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if file_classification_progress is not UNSET:
            field_dict["file_classification_progress"] = file_classification_progress
        if file_path is not UNSET:
            field_dict["file_path"] = file_path

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.status_of_a_file_upload_and_classification_file_classification_progress import (
            StatusOfAFileUploadAndClassificationFileClassificationProgress,
        )

        d = src_dict.copy()
        _file_classification_progress = d.pop("file_classification_progress", UNSET)
        file_classification_progress: Union[Unset, StatusOfAFileUploadAndClassificationFileClassificationProgress]
        if isinstance(_file_classification_progress, Unset):
            file_classification_progress = UNSET
        else:
            file_classification_progress = StatusOfAFileUploadAndClassificationFileClassificationProgress.from_dict(
                _file_classification_progress
            )

        file_path = d.pop("file_path", UNSET)

        status_of_a_file_upload_and_classification = cls(
            file_classification_progress=file_classification_progress,
            file_path=file_path,
        )

        status_of_a_file_upload_and_classification.additional_properties = d
        return status_of_a_file_upload_and_classification

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
