import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin_version_creation_base_operating_systems_item import (
        DigitalTwinVersionCreationBaseOperatingSystemsItem,
    )
    from ..models.hardware import Hardware
    from ..models.sbom_metadata import SbomMetadata


T = TypeVar("T", bound="DigitalTwinVersionCreationBase")


@attr.s(auto_attribs=True)
class DigitalTwinVersionCreationBase:
    """Digital twin version creation base

    Attributes:
        name (str): the name of the DT Version
        date (Union[Unset, datetime.datetime]): the date of the DT Version - if not set will be defaulted to the current
            time
        external_id (Union[Unset, str]): an external id field that will be supplied by the customer
        hardware (Union[Unset, Hardware]): digital twin hardware
        operating_systems (Union[Unset, List['DigitalTwinVersionCreationBaseOperatingSystemsItem']]):
        production_phase (Union[Unset, str]): Component Production Phase
        sbom_metadata (Union[Unset, SbomMetadata]): sbom metadata from intermediate sbom
        sbom_phase (Union[Unset, str]):
    """

    name: str
    date: Union[Unset, datetime.datetime] = UNSET
    external_id: Union[Unset, str] = UNSET
    hardware: Union[Unset, "Hardware"] = UNSET
    operating_systems: Union[Unset, List["DigitalTwinVersionCreationBaseOperatingSystemsItem"]] = UNSET
    production_phase: Union[Unset, str] = UNSET
    sbom_metadata: Union[Unset, "SbomMetadata"] = UNSET
    sbom_phase: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        name = self.name
        date: Union[Unset, str] = UNSET
        if not isinstance(self.date, Unset):
            date = self.date.isoformat()

        external_id = self.external_id
        hardware: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.hardware, Unset):
            hardware = self.hardware.to_dict()

        operating_systems: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.operating_systems, Unset):
            operating_systems = []
            for operating_systems_item_data in self.operating_systems:
                operating_systems_item = operating_systems_item_data.to_dict()

                operating_systems.append(operating_systems_item)

        production_phase = self.production_phase
        sbom_metadata: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.sbom_metadata, Unset):
            sbom_metadata = self.sbom_metadata.to_dict()

        sbom_phase = self.sbom_phase

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if date is not UNSET:
            field_dict["date"] = date
        if external_id is not UNSET:
            field_dict["external_id"] = external_id
        if hardware is not UNSET:
            field_dict["hardware"] = hardware
        if operating_systems is not UNSET:
            field_dict["operating systems"] = operating_systems
        if production_phase is not UNSET:
            field_dict["production_phase"] = production_phase
        if sbom_metadata is not UNSET:
            field_dict["sbom_metadata"] = sbom_metadata
        if sbom_phase is not UNSET:
            field_dict["sbom_phase"] = sbom_phase

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin_version_creation_base_operating_systems_item import (
            DigitalTwinVersionCreationBaseOperatingSystemsItem,
        )
        from ..models.hardware import Hardware
        from ..models.sbom_metadata import SbomMetadata

        d = src_dict.copy()
        name = d.pop("name")

        _date = d.pop("date", UNSET)
        date: Union[Unset, datetime.datetime]
        if isinstance(_date, Unset):
            date = UNSET
        else:
            date = isoparse(_date)

        external_id = d.pop("external_id", UNSET)

        _hardware = d.pop("hardware", UNSET)
        hardware: Union[Unset, Hardware]
        if isinstance(_hardware, Unset):
            hardware = UNSET
        else:
            hardware = Hardware.from_dict(_hardware)

        _operating_systems = d.pop("operating systems", UNSET)
        if (_operating_systems) is UNSET:
            operating_systems = UNSET
        else:
            if _operating_systems:
                operating_systems = []
                for operating_systems_item_data in _operating_systems:
                    operating_systems_item = DigitalTwinVersionCreationBaseOperatingSystemsItem.from_dict(
                        operating_systems_item_data
                    )

                    operating_systems.append(operating_systems_item)
            else:
                operating_systems = []

        production_phase = d.pop("production_phase", UNSET)

        _sbom_metadata = d.pop("sbom_metadata", UNSET)
        sbom_metadata: Union[Unset, SbomMetadata]
        if isinstance(_sbom_metadata, Unset):
            sbom_metadata = UNSET
        else:
            sbom_metadata = SbomMetadata.from_dict(_sbom_metadata)

        sbom_phase = d.pop("sbom_phase", UNSET)

        digital_twin_version_creation_base = cls(
            name=name,
            date=date,
            external_id=external_id,
            hardware=hardware,
            operating_systems=operating_systems,
            production_phase=production_phase,
            sbom_metadata=sbom_metadata,
            sbom_phase=sbom_phase,
        )

        digital_twin_version_creation_base.additional_properties = d
        return digital_twin_version_creation_base

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
