from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.policies_assessment_version_scan_policies_scan_partial_results_item_info_type import (
    PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfoType,
)
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.policies_assessment_version_scan_policies_scan_partial_results_item_info import (
        PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfo,
    )


T = TypeVar("T", bound="PoliciesAssessmentVersionScanPoliciesScanPartialResultsItem")


@attr.s(auto_attribs=True)
class PoliciesAssessmentVersionScanPoliciesScanPartialResultsItem:
    """
    Attributes:
        info_type (PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfoType): Information type
        info (Union[Unset, PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfo]): Information payload
    """

    info_type: PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfoType
    info: Union[Unset, "PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfo"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        info_type = PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfoType.from_val(self.info_type).value

        info: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.info, Unset):
            info = self.info.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "info_type": info_type,
            }
        )
        if info is not UNSET:
            field_dict["info"] = info

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.policies_assessment_version_scan_policies_scan_partial_results_item_info import (
            PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfo,
        )

        d = src_dict.copy()
        info_type = PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfoType.from_val(d.pop("info_type"))

        _info = d.pop("info", UNSET)
        info: Union[Unset, PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfo]
        if isinstance(_info, Unset):
            info = UNSET
        else:
            info = PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfo.from_dict(_info)

        policies_assessment_version_scan_policies_scan_partial_results_item = cls(
            info_type=info_type,
            info=info,
        )

        policies_assessment_version_scan_policies_scan_partial_results_item.additional_properties = d
        return policies_assessment_version_scan_policies_scan_partial_results_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
