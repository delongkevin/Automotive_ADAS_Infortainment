from enum import Enum
from typing import Union


class VirtualAnalystExecution(str, Enum):
    PENDING = "pending"

    CANCELLED = "cancelled"

    EXECUTED = "executed"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "VirtualAnalystExecution"]) -> "VirtualAnalystExecution":
        if isinstance(value, VirtualAnalystExecution):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return VirtualAnalystExecution(value)
