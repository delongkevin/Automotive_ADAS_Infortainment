from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="ImportedSBOMDataMetadataManufacturerContactsItem")


@attr.s(auto_attribs=True)
class ImportedSBOMDataMetadataManufacturerContactsItem:
    """
    Attributes:
        email (Union[Unset, str]):
        name (Union[Unset, str]):
        phone (Union[Unset, str]):
    """

    email: Union[Unset, str] = UNSET
    name: Union[Unset, str] = UNSET
    phone: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        email = self.email
        name = self.name
        phone = self.phone

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if email is not UNSET:
            field_dict["email"] = email
        if name is not UNSET:
            field_dict["name"] = name
        if phone is not UNSET:
            field_dict["phone"] = phone

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        email = d.pop("email", UNSET)

        name = d.pop("name", UNSET)

        phone = d.pop("phone", UNSET)

        imported_sbom_data_metadata_manufacturer_contacts_item = cls(
            email=email,
            name=name,
            phone=phone,
        )

        imported_sbom_data_metadata_manufacturer_contacts_item.additional_properties = d
        return imported_sbom_data_metadata_manufacturer_contacts_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
