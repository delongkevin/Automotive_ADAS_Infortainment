from enum import Enum
from typing import Union


class ResumableUploadSessionType(str, Enum):
    CREATE_SBOM_SOURCE = "create_sbom_source"

    CREATE_BINARY_SOURCE = "create_binary_source"

    ADD_RESOURCE = "add_resource"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "ResumableUploadSessionType"]) -> "ResumableUploadSessionType":
        if isinstance(value, ResumableUploadSessionType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return ResumableUploadSessionType(value)
