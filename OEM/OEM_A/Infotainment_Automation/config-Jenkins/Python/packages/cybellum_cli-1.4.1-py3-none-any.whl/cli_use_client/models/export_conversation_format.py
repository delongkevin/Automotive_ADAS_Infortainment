from enum import Enum
from typing import Union


class ExportConversationFormat(str, Enum):
    JSON = "json"

    CSV = "csv"

    TXT = "txt"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "ExportConversationFormat"]) -> "ExportConversationFormat":
        if isinstance(value, ExportConversationFormat):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return ExportConversationFormat(value)
