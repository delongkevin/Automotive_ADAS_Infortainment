from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.license_type import LicenseType
from ..models.package_usage_risk import PackageUsageRisk
from ..types import UNSET, Unset

T = TypeVar("T", bound="SBOMPackageLicense")


@attr.s(auto_attribs=True)
class SBOMPackageLicense:
    """SBOM Package license

    Attributes:
        global_license_id (str): Global license id
        id (str): Package license id
        name (str): License name
        type (LicenseType): License type
        manually_attached (Union[Unset, bool]): Indicator if the license was manually attached to the package in the
            SBOM context
        not_relevant (Union[Unset, bool]): Indicator for the license relevancy for the package in the SBOM context
        usage_risk (Union[Unset, PackageUsageRisk]): Package usage risk
    """

    global_license_id: str
    id: str
    name: str
    type: LicenseType
    manually_attached: Union[Unset, bool] = UNSET
    not_relevant: Union[Unset, bool] = UNSET
    usage_risk: Union[Unset, PackageUsageRisk] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        global_license_id = self.global_license_id
        id = self.id
        name = self.name
        type = LicenseType.from_val(self.type).value

        manually_attached = self.manually_attached
        not_relevant = self.not_relevant
        usage_risk: Union[Unset, str] = UNSET
        if not isinstance(self.usage_risk, Unset):
            usage_risk = PackageUsageRisk.from_val(self.usage_risk).value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "global_license_id": global_license_id,
                "id": id,
                "name": name,
                "type": type,
            }
        )
        if manually_attached is not UNSET:
            field_dict["manually_attached"] = manually_attached
        if not_relevant is not UNSET:
            field_dict["not_relevant"] = not_relevant
        if usage_risk is not UNSET:
            field_dict["usage_risk"] = usage_risk

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        global_license_id = d.pop("global_license_id")

        id = d.pop("id")

        name = d.pop("name")

        type = LicenseType.from_val(d.pop("type"))

        manually_attached = d.pop("manually_attached", UNSET)

        not_relevant = d.pop("not_relevant", UNSET)

        _usage_risk = d.pop("usage_risk", UNSET)
        usage_risk: Union[Unset, PackageUsageRisk]
        if isinstance(_usage_risk, Unset):
            usage_risk = UNSET
        else:
            usage_risk = PackageUsageRisk.from_val(_usage_risk)

        sbom_package_license = cls(
            global_license_id=global_license_id,
            id=id,
            name=name,
            type=type,
            manually_attached=manually_attached,
            not_relevant=not_relevant,
            usage_risk=usage_risk,
        )

        sbom_package_license.additional_properties = d
        return sbom_package_license

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
