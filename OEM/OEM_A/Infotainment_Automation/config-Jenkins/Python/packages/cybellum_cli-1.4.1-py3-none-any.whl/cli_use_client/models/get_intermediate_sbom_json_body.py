from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="GetIntermediateSBOMJsonBody")


@attr.s(auto_attribs=True)
class GetIntermediateSBOMJsonBody:
    """
    Attributes:
        file_id (str): ID
        components (Union[Unset, bool]): If False the "components" value will not be returned
             Default: True.
        dependencies (Union[Unset, bool]): If False the "dependencies" value will not be returned
             Default: True.
        license_text (Union[Unset, bool]): If False the "license_text" value will not be returned
             Default: True.
        metadata (Union[Unset, bool]): If False the "metadata" value will not be returned
             Default: True.
        primary_component (Union[Unset, bool]): If False the "primary_component" value will not be returned
             Default: True.
    """

    file_id: str
    components: Union[Unset, bool] = True
    dependencies: Union[Unset, bool] = True
    license_text: Union[Unset, bool] = True
    metadata: Union[Unset, bool] = True
    primary_component: Union[Unset, bool] = True
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        file_id = self.file_id
        components = self.components
        dependencies = self.dependencies
        license_text = self.license_text
        metadata = self.metadata
        primary_component = self.primary_component

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "file_id": file_id,
            }
        )
        if components is not UNSET:
            field_dict["components"] = components
        if dependencies is not UNSET:
            field_dict["dependencies"] = dependencies
        if license_text is not UNSET:
            field_dict["license_text"] = license_text
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if primary_component is not UNSET:
            field_dict["primary_component"] = primary_component

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        file_id = d.pop("file_id")

        components = d.pop("components", UNSET)

        dependencies = d.pop("dependencies", UNSET)

        license_text = d.pop("license_text", UNSET)

        metadata = d.pop("metadata", UNSET)

        primary_component = d.pop("primary_component", UNSET)

        get_intermediate_sbom_json_body = cls(
            file_id=file_id,
            components=components,
            dependencies=dependencies,
            license_text=license_text,
            metadata=metadata,
            primary_component=primary_component,
        )

        get_intermediate_sbom_json_body.additional_properties = d
        return get_intermediate_sbom_json_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
