from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="SBOMPackageInfoPathsItem")


@attr.s(auto_attribs=True)
class SBOMPackageInfoPathsItem:
    """
    Attributes:
        evidence_id (Union[Unset, str]): ID
        id (Union[Unset, str]): ID
        path (Union[Unset, str]): Relative path
    """

    evidence_id: Union[Unset, str] = UNSET
    id: Union[Unset, str] = UNSET
    path: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        evidence_id = self.evidence_id
        id = self.id
        path = self.path

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if evidence_id is not UNSET:
            field_dict["evidence_id"] = evidence_id
        if id is not UNSET:
            field_dict["id"] = id
        if path is not UNSET:
            field_dict["path"] = path

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        evidence_id = d.pop("evidence_id", UNSET)

        id = d.pop("id", UNSET)

        path = d.pop("path", UNSET)

        sbom_package_info_paths_item = cls(
            evidence_id=evidence_id,
            id=id,
            path=path,
        )

        sbom_package_info_paths_item.additional_properties = d
        return sbom_package_info_paths_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
