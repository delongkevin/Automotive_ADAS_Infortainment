import datetime
from typing import Any, Dict, List, Type, TypeVar, Union, cast

import attr
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AttachedElementsProductVersion")


@attr.s(auto_attribs=True)
class AttachedElementsProductVersion:
    """
    Attributes:
        created_by (str): Product version created by user
        created_on (datetime.datetime): Creation date of the product version
        id (str): ID
        last_modified_on (datetime.datetime): Last modified date of the product version
        name (str): Product version name
        risk_score (float): Assessment risk score Example: 7.5.
        approval_status (Union[Unset, float]): Percentage of attached Products and Components that are approved
        clients (Union[Unset, List[str]]): Product version clients
        description (Union[Unset, str]): Product version description
        model_name (Union[Unset, str]): Product version model name
        parent_id (Union[Unset, str]): ID
        production_phase (Union[Unset, str]): Component Production Phase
        sop_date (Union[Unset, datetime.datetime]): Product version SOP date
        total_approved_items (Union[Unset, int]): Total number of attached Products and Components with approved SBOMs
        total_attached_items (Union[Unset, int]): Total number of Products and Components attached to this Product
        variant (Union[Unset, str]): Product version variant
        vendors (Union[Unset, List[str]]): Product version vendors
        feasibility (Union[Unset, float]): Feasibility of the attached product version in terms of risk
        weight (Union[Unset, float]): The weight of the attached elements in terms of risk
    """

    created_by: str
    created_on: datetime.datetime
    id: str
    last_modified_on: datetime.datetime
    name: str
    risk_score: float
    approval_status: Union[Unset, float] = UNSET
    clients: Union[Unset, List[str]] = UNSET
    description: Union[Unset, str] = UNSET
    model_name: Union[Unset, str] = UNSET
    parent_id: Union[Unset, str] = UNSET
    production_phase: Union[Unset, str] = UNSET
    sop_date: Union[Unset, datetime.datetime] = UNSET
    total_approved_items: Union[Unset, int] = UNSET
    total_attached_items: Union[Unset, int] = UNSET
    variant: Union[Unset, str] = UNSET
    vendors: Union[Unset, List[str]] = UNSET
    feasibility: Union[Unset, float] = UNSET
    weight: Union[Unset, float] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        created_by = self.created_by
        created_on = self.created_on.isoformat()

        id = self.id
        last_modified_on = self.last_modified_on.isoformat()

        name = self.name
        risk_score = self.risk_score
        approval_status = self.approval_status
        clients: Union[Unset, List[str]] = UNSET
        if not isinstance(self.clients, Unset):
            clients = self.clients

        description = self.description
        model_name = self.model_name
        parent_id = self.parent_id
        production_phase = self.production_phase
        sop_date: Union[Unset, str] = UNSET
        if not isinstance(self.sop_date, Unset):
            sop_date = self.sop_date.isoformat()

        total_approved_items = self.total_approved_items
        total_attached_items = self.total_attached_items
        variant = self.variant
        vendors: Union[Unset, List[str]] = UNSET
        if not isinstance(self.vendors, Unset):
            vendors = self.vendors

        feasibility = self.feasibility
        weight = self.weight

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "created_by": created_by,
                "created_on": created_on,
                "id": id,
                "last_modified_on": last_modified_on,
                "name": name,
                "risk_score": risk_score,
            }
        )
        if approval_status is not UNSET:
            field_dict["approval_status"] = approval_status
        if clients is not UNSET:
            field_dict["clients"] = clients
        if description is not UNSET:
            field_dict["description"] = description
        if model_name is not UNSET:
            field_dict["model_name"] = model_name
        if parent_id is not UNSET:
            field_dict["parent_id"] = parent_id
        if production_phase is not UNSET:
            field_dict["production_phase"] = production_phase
        if sop_date is not UNSET:
            field_dict["sop_date"] = sop_date
        if total_approved_items is not UNSET:
            field_dict["total_approved_items"] = total_approved_items
        if total_attached_items is not UNSET:
            field_dict["total_attached_items"] = total_attached_items
        if variant is not UNSET:
            field_dict["variant"] = variant
        if vendors is not UNSET:
            field_dict["vendors"] = vendors
        if feasibility is not UNSET:
            field_dict["feasibility"] = feasibility
        if weight is not UNSET:
            field_dict["weight"] = weight

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        created_by = d.pop("created_by")

        created_on = isoparse(d.pop("created_on"))

        id = d.pop("id")

        last_modified_on = isoparse(d.pop("last_modified_on"))

        name = d.pop("name")

        risk_score = d.pop("risk_score")

        approval_status = d.pop("approval_status", UNSET)

        clients = cast(List[str], d.pop("clients", UNSET))

        description = d.pop("description", UNSET)

        model_name = d.pop("model_name", UNSET)

        parent_id = d.pop("parent_id", UNSET)

        production_phase = d.pop("production_phase", UNSET)

        _sop_date = d.pop("sop_date", UNSET)
        sop_date: Union[Unset, datetime.datetime]
        if isinstance(_sop_date, Unset):
            sop_date = UNSET
        else:
            sop_date = isoparse(_sop_date)

        total_approved_items = d.pop("total_approved_items", UNSET)

        total_attached_items = d.pop("total_attached_items", UNSET)

        variant = d.pop("variant", UNSET)

        vendors = cast(List[str], d.pop("vendors", UNSET))

        feasibility = d.pop("feasibility", UNSET)

        weight = d.pop("weight", UNSET)

        attached_elements_product_version = cls(
            created_by=created_by,
            created_on=created_on,
            id=id,
            last_modified_on=last_modified_on,
            name=name,
            risk_score=risk_score,
            approval_status=approval_status,
            clients=clients,
            description=description,
            model_name=model_name,
            parent_id=parent_id,
            production_phase=production_phase,
            sop_date=sop_date,
            total_approved_items=total_approved_items,
            total_attached_items=total_attached_items,
            variant=variant,
            vendors=vendors,
            feasibility=feasibility,
            weight=weight,
        )

        attached_elements_product_version.additional_properties = d
        return attached_elements_product_version

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
