import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.status_of_an_sbom_document_analysis_document_analysis_result import (
        StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResult,
    )
    from ..models.status_of_an_sbom_document_analysis_sbom_importer_version import (
        StatusOfAnSBOMDocumentAnalysisSbomImporterVersion,
    )


T = TypeVar("T", bound="StatusOfAnSBOMDocumentAnalysis")


@attr.s(auto_attribs=True)
class StatusOfAnSBOMDocumentAnalysis:
    """The status (and eventually result) for an SBOM document analysis

    Attributes:
        analysis_id (Union[Unset, str]): A unique identifier for the analysis task
        created (Union[Unset, datetime.datetime]):
        document_analysis_result (Union[Unset, StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResult]):
        failure_reason (Union[Unset, str]):
        file_name (Union[Unset, str]):
        finished (Union[Unset, datetime.datetime]):
        percentage (Union[Unset, int]):
        sbom_importer_version (Union[Unset, StatusOfAnSBOMDocumentAnalysisSbomImporterVersion]):
        started (Union[Unset, datetime.datetime]):
        status (Union[Unset, str]): "queued", "running" or "completed"
        success (Union[Unset, bool]): True if the analysis completed successfully and False otherwise
    """

    analysis_id: Union[Unset, str] = UNSET
    created: Union[Unset, datetime.datetime] = UNSET
    document_analysis_result: Union[Unset, "StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResult"] = UNSET
    failure_reason: Union[Unset, str] = UNSET
    file_name: Union[Unset, str] = UNSET
    finished: Union[Unset, datetime.datetime] = UNSET
    percentage: Union[Unset, int] = UNSET
    sbom_importer_version: Union[Unset, "StatusOfAnSBOMDocumentAnalysisSbomImporterVersion"] = UNSET
    started: Union[Unset, datetime.datetime] = UNSET
    status: Union[Unset, str] = UNSET
    success: Union[Unset, bool] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        analysis_id = self.analysis_id
        created: Union[Unset, str] = UNSET
        if not isinstance(self.created, Unset):
            created = self.created.isoformat()

        document_analysis_result: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.document_analysis_result, Unset):
            document_analysis_result = self.document_analysis_result.to_dict()

        failure_reason = self.failure_reason
        file_name = self.file_name
        finished: Union[Unset, str] = UNSET
        if not isinstance(self.finished, Unset):
            finished = self.finished.isoformat()

        percentage = self.percentage
        sbom_importer_version: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.sbom_importer_version, Unset):
            sbom_importer_version = self.sbom_importer_version.to_dict()

        started: Union[Unset, str] = UNSET
        if not isinstance(self.started, Unset):
            started = self.started.isoformat()

        status = self.status
        success = self.success

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if analysis_id is not UNSET:
            field_dict["analysis_id"] = analysis_id
        if created is not UNSET:
            field_dict["created"] = created
        if document_analysis_result is not UNSET:
            field_dict["document_analysis_result"] = document_analysis_result
        if failure_reason is not UNSET:
            field_dict["failure_reason"] = failure_reason
        if file_name is not UNSET:
            field_dict["file_name"] = file_name
        if finished is not UNSET:
            field_dict["finished"] = finished
        if percentage is not UNSET:
            field_dict["percentage"] = percentage
        if sbom_importer_version is not UNSET:
            field_dict["sbom_importer_version"] = sbom_importer_version
        if started is not UNSET:
            field_dict["started"] = started
        if status is not UNSET:
            field_dict["status"] = status
        if success is not UNSET:
            field_dict["success"] = success

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.status_of_an_sbom_document_analysis_document_analysis_result import (
            StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResult,
        )
        from ..models.status_of_an_sbom_document_analysis_sbom_importer_version import (
            StatusOfAnSBOMDocumentAnalysisSbomImporterVersion,
        )

        d = src_dict.copy()
        analysis_id = d.pop("analysis_id", UNSET)

        _created = d.pop("created", UNSET)
        created: Union[Unset, datetime.datetime]
        if isinstance(_created, Unset):
            created = UNSET
        else:
            created = isoparse(_created)

        _document_analysis_result = d.pop("document_analysis_result", UNSET)
        document_analysis_result: Union[Unset, StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResult]
        if isinstance(_document_analysis_result, Unset):
            document_analysis_result = UNSET
        else:
            document_analysis_result = StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResult.from_dict(
                _document_analysis_result
            )

        failure_reason = d.pop("failure_reason", UNSET)

        file_name = d.pop("file_name", UNSET)

        _finished = d.pop("finished", UNSET)
        finished: Union[Unset, datetime.datetime]
        if isinstance(_finished, Unset):
            finished = UNSET
        else:
            finished = isoparse(_finished)

        percentage = d.pop("percentage", UNSET)

        _sbom_importer_version = d.pop("sbom_importer_version", UNSET)
        sbom_importer_version: Union[Unset, StatusOfAnSBOMDocumentAnalysisSbomImporterVersion]
        if isinstance(_sbom_importer_version, Unset):
            sbom_importer_version = UNSET
        else:
            sbom_importer_version = StatusOfAnSBOMDocumentAnalysisSbomImporterVersion.from_dict(_sbom_importer_version)

        _started = d.pop("started", UNSET)
        started: Union[Unset, datetime.datetime]
        if isinstance(_started, Unset):
            started = UNSET
        else:
            started = isoparse(_started)

        status = d.pop("status", UNSET)

        success = d.pop("success", UNSET)

        status_of_an_sbom_document_analysis = cls(
            analysis_id=analysis_id,
            created=created,
            document_analysis_result=document_analysis_result,
            failure_reason=failure_reason,
            file_name=file_name,
            finished=finished,
            percentage=percentage,
            sbom_importer_version=sbom_importer_version,
            started=started,
            status=status,
            success=success,
        )

        status_of_an_sbom_document_analysis.additional_properties = d
        return status_of_an_sbom_document_analysis

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
