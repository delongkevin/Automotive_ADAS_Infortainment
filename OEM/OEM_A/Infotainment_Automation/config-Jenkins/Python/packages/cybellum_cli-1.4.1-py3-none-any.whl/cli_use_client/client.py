import datetime
import ssl
from enum import Enum
from os import getenv, path
from typing import Callable, Dict, Optional, Union

import attr
import jwt
import yaml

from .errors import EndpointNotConfigured


class AuthenticationStatus(str, Enum):
    NOT_AUTHENTICATED = "not authenticated"
    AUTHENTICATED = "authenticated"


class ParseResponseBehavior(str, Enum):
    TYPED_PARSING = "typed_parsing"
    JSON_PARSING = "json_parsing"
    NO_PARSING = "no_parsing"
    RAW_RESPONSE = "raw_response"


@attr.s(auto_attribs=True)
class Client:
    """A class for keeping track of data related to the API

    Attributes:
        base_url: The base URL for the API, all requests are made to a relative path to this URL
        cookies: A dictionary of cookies to be sent with every request
        headers: A dictionary of headers to be sent with every request
        timeout: The maximum amount of a time in seconds a request can take. API functions will raise
            httpx.TimeoutException if this is exceeded.
        verify_ssl: Whether or not to verify the SSL certificate of the API server. This should be True in production,
            but can be set to False for testing purposes.
        cert: Path to SSL certificate
        raise_on_unexpected_status: Whether or not to raise an errors.UnexpectedStatus if the API returns a
            status code that was not documented in the source OpenAPI document.
        raise_on_failed_status: Whether or not to raise an errors.FailedStatus if the API returns a
            status code that match a failed response (marked using x-failed-response, by default != 200).
        always_authenticate: Whether or not to always check the authentication status before performing a call
        parse_response_behavior: How to handle response parsing
        mounts: Mounts and proxy definitions object
    """

    base_url: str = attr.ib("", kw_only=True)
    cookies: Dict[str, str] = attr.ib(factory=dict, kw_only=True)
    headers: Dict[str, str] = attr.ib(factory=dict, kw_only=True)
    timeout: float = attr.ib(60.0, kw_only=True)
    mounts: Union[str, Dict[str, str]] = attr.ib(None, kw_only=True)
    verify_ssl: Union[str, bool, ssl.SSLContext] = attr.ib(True, kw_only=True)
    cert: Optional[str] = attr.ib(None, kw_only=True)
    raise_on_unexpected_status: bool = attr.ib(True, kw_only=True)
    raise_on_failed_status: bool = attr.ib(True, kw_only=True)
    always_authenticate: bool = attr.ib(False, kw_only=True)
    is_authenticated: bool = attr.ib(False, kw_only=True)
    parse_response_behavior: ParseResponseBehavior = attr.ib(True, kw_only=ParseResponseBehavior.TYPED_PARSING)

    def get_service_url(self, service):
        if self.base_url:
            return self.base_url

        services = [service, "_default"]
        protocol = get_service_property(services, ["protocol", "default_protocol"])
        host = get_service_property(services, ["host", "default_host"])
        port = get_service_property(services, ["port", "default_port"])
        base_path = get_service_property(services, ["base_path", "default_base_path"])

        if not protocol or not host or not port:
            raise EndpointNotConfigured(
                f"Failed to find base url for service {service}, found: {protocol}://{host}:{port}/{base_path}"
            )

        return f"{protocol}://{host}:{port}/{base_path}"

    def get_authentication_status_sync(self) -> AuthenticationStatus:
        if self.is_authenticated:
            return AuthenticationStatus.AUTHENTICATED
        return AuthenticationStatus.NOT_AUTHENTICATED

    async def get_authentication_status_async(self) -> AuthenticationStatus:
        return self.get_authentication_status_sync()

    def get_headers(self) -> Dict[str, str]:
        """Get headers to be used in all endpoints"""
        return {**self.headers}

    def get_cookies(self) -> Dict[str, str]:
        return {**self.cookies}

    def get_timeout(self) -> float:
        return self.timeout

    def with_headers(self, headers: Dict[str, str]) -> "Client":
        """Get a new client matching this one with additional headers"""
        return attr.evolve(self, headers={**self.headers, **headers})

    def with_cookies(self, cookies: Dict[str, str]) -> "Client":
        """Get a new client matching this one with additional cookies"""
        return attr.evolve(self, cookies={**self.cookies, **cookies})

    def with_timeout(self, timeout: float) -> "Client":
        """Get a new client matching this one with a new timeout (in seconds)"""
        return attr.evolve(self, timeout=timeout)

    def with_parse_response_behavior(self, parse_response_behavior: ParseResponseBehavior) -> "Client":
        """Get a new client matching this one with a new parse_response_behavior"""
        return attr.evolve(self, parse_response_behavior=parse_response_behavior)


@attr.s(auto_attribs=True)
class AuthenticatedClient(Client):
    """A Client which has been authenticated for use on secured endpoints"""

    token: str = None
    jwt_token: bool = True
    jwt_ttl_leeway: int = 1
    prefix: str = "Bearer"
    auth_header_name: str = "Authorization"

    @staticmethod
    def for_token(token: str, **kwargs):
        return AuthenticatedClient(token=token, **kwargs)

    @staticmethod
    def for_api_key(api_key: str, **kwargs):
        return AuthenticatedClient(token=api_key, auth_header_name="X-API-KEY", prefix="", jwt_token=False, **kwargs)

    def get_authentication_status_sync(self) -> AuthenticationStatus:
        # First check the API key authorization
        if self.token and self.auth_header_name == "X-API-KEY" and self.prefix == "":
            return AuthenticationStatus.AUTHENTICATED

        if self.token and check_jwt_validity(self.token, self.jwt_ttl_leeway):
            return AuthenticationStatus.AUTHENTICATED

        return super().get_authentication_status_sync()

    def get_headers(self) -> Dict[str, str]:
        auth_header_value = f"{self.prefix} {self.token}" if self.prefix else self.token
        """Get headers to be used in authenticated endpoints"""
        return {self.auth_header_name: auth_header_value, **self.headers}

    def with_headers(self, headers: Dict[str, str]) -> "AuthenticatedClient":
        """Get a new authenticated client matching this one with additional headers"""
        return attr.evolve(self, headers={**self.headers, **headers})

    def with_cookies(self, cookies: Dict[str, str]) -> "AuthenticatedClient":
        """Get a new authenticated client matching this one with additional cookies"""
        return attr.evolve(self, cookies={**self.cookies, **cookies})

    def with_timeout(self, timeout: float) -> "AuthenticatedClient":
        """Get a new authenticated client matching this one with a new timeout (in seconds)"""
        return attr.evolve(self, timeout=timeout)

    def with_parse_response_behavior(self, parse_response_behavior: ParseResponseBehavior) -> "AuthenticatedClient":
        """Get a new client matching this one with a new parse_response_behavior"""
        return attr.evolve(self, parse_response_behavior=parse_response_behavior)


@attr.s(auto_attribs=True)
class AuthenticationInfo:
    token: str
    refresh_token: str


@attr.s(auto_attribs=True)
class LoginClient(AuthenticatedClient):
    """A Client that knows to login/refresh for use on secured endpoints"""

    refresh_token: str = None
    login_endpoint: Callable[[Client], AuthenticationInfo] = None
    refresh_endpoint: Callable[[AuthenticatedClient], AuthenticationInfo] = None

    @staticmethod
    def for_login(
        login_endpoint: Callable[[Client], AuthenticationInfo],
        refresh_endpoint: Callable[[AuthenticatedClient], AuthenticationInfo] = None,
        **kwargs,
    ):
        return LoginClient(
            login_endpoint=login_endpoint, refresh_endpoint=refresh_endpoint, always_authenticate=True, **kwargs
        )

    def get_authentication_status_sync(self) -> AuthenticationStatus:
        if self.token and check_jwt_validity(self.token, self.jwt_ttl_leeway):
            return AuthenticationStatus.AUTHENTICATED

        self.token = None

        if self.refresh_token and check_jwt_validity(self.refresh_token, self.jwt_ttl_leeway):
            self._refresh_jwt_sync()
        else:
            self.refresh_token = None

        if not self.token:
            self._initiate_jwt_sync()

        if self.token:
            return AuthenticationStatus.AUTHENTICATED

        return AuthenticationStatus.NOT_AUTHENTICATED

    def _refresh_client(self):
        return AuthenticatedClient(
            base_url=self.base_url,
            cookies=self.cookies,
            headers=self.headers,
            timeout=self.timeout,
            verify_ssl=self.verify_ssl,
            mounts=self.mounts,
            cert=self.cert,
            raise_on_unexpected_status=self.raise_on_unexpected_status,
            raise_on_failed_status=self.raise_on_failed_status,
            always_authenticate=False,
            is_authenticated=True,
            token=self.refresh_token,
        )

    def _login_client(self):
        return Client(
            base_url=self.base_url,
            cookies=self.cookies,
            headers=self.headers,
            timeout=self.timeout,
            verify_ssl=self.verify_ssl,
            mounts=self.mounts,
            cert=self.cert,
            raise_on_unexpected_status=self.raise_on_unexpected_status,
            raise_on_failed_status=self.raise_on_failed_status,
            always_authenticate=False,
            is_authenticated=False,
        )

    def _refresh_jwt_sync(self):
        if self.refresh_endpoint:
            result = self.refresh_endpoint(self._refresh_client())
            if result:
                self.token = result.token
                self.refresh_token = result.refresh_token

    def _initiate_jwt_sync(self):
        if self.login_endpoint:
            result = self.login_endpoint(self._login_client())
            if result:
                self.token = result.token
                self.refresh_token = result.refresh_token

    async def get_authentication_status_asyncio(self) -> AuthenticationStatus:
        if self.token and check_jwt_validity(self.token, self.jwt_ttl_leeway):
            return AuthenticationStatus.AUTHENTICATED

        self.token = None

        if self.refresh_token and check_jwt_validity(self.refresh_token, self.jwt_ttl_leeway):
            await self._refresh_jwt_asyncio()
        else:
            self.refresh_token = None

        if not self.token:
            await self._initiate_jwt_asyncio()

        if self.token:
            return AuthenticationStatus.AUTHENTICATED

        return AuthenticationStatus.NOT_AUTHENTICATED

    async def _refresh_jwt_asyncio(self):
        if self.refresh_endpoint:
            result = await self.refresh_endpoint(self.refresh_client())
            if result:
                self.token = result.token
                self.refresh_token = result.refresh_token

    async def _initiate_jwt_asyncio(self):
        if self.login_endpoint:
            result = await self.login_endpoint(self._login_client())
            if result:
                self.token = result.token
                self.refresh_token = result.refresh_token

    def with_headers(self, headers: Dict[str, str]) -> "LoginClient":
        """Get a new login client matching this one with additional headers"""
        return attr.evolve(self, headers={**self.headers, **headers})

    def with_cookies(self, cookies: Dict[str, str]) -> "LoginClient":
        """Get a new login client matching this one with additional cookies"""
        return attr.evolve(self, cookies={**self.cookies, **cookies})

    def with_timeout(self, timeout: float) -> "LoginClient":
        """Get a new login client matching this one with a new timeout (in seconds)"""
        return attr.evolve(self, timeout=timeout)

    def with_parse_response_behavior(self, parse_response_behavior: ParseResponseBehavior) -> "LoginClient":
        """Get a new client matching this one with a new parse_response_behavior"""
        return attr.evolve(self, parse_response_behavior=parse_response_behavior)


def check_jwt_validity(token, leeway) -> bool:
    if not token:
        return False

    now = datetime.datetime.now(tz=datetime.timezone.utc).timestamp()
    payload = jwt.decode(token, options={"verify_signature": False})

    if "nbf" in payload:
        nbf = payload.get("nbf")
        if nbf > now:
            return False

    if "exp" in payload:
        exp = payload.get("exp")
        if now > exp - leeway:
            return False

    return True


_servers: dict = None


def get_servers():
    global _servers
    if not _servers:
        servers_path = path.join(path.dirname(path.abspath(__file__)), "servers.yaml")
        with open(servers_path, "r") as servers_file:
            config = yaml.safe_load(servers_file)
        _servers = config.get("servers")

    return _servers


def get_service_property(services, properties):
    servers = get_servers()

    for service in services:
        if service in servers:
            service_info = servers.get(service)
            for property in properties:
                if property in service_info:
                    value = service_info.get(property)
                    if value and value.startswith("$"):
                        value = getenv(value[1:])
                    if value:
                        return value
    return None


def flatten_params(json_object, including_lists=True):
    results_dict = {}
    _add_prefixed_object(json_object, "", results_dict, including_lists=including_lists)
    return results_dict


def _add_prefixed_object(nested_object, prefix, results_dict, including_lists=True):
    if isinstance(nested_object, dict):
        if prefix != "":
            prefix += "."
        for key, val in nested_object.items():
            new_prefix = prefix + key
            _add_prefixed_object(val, new_prefix, results_dict)
    elif isinstance(nested_object, list) and including_lists:
        for idx, elem in enumerate(nested_object):
            new_prefix = prefix + f"[{idx}]"
            _add_prefixed_object(elem, new_prefix, results_dict)
    else:
        results_dict[prefix] = nested_object
