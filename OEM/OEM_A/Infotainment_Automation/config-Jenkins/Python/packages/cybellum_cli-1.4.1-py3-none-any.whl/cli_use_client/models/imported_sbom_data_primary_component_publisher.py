from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.imported_sbom_data_primary_component_publisher_contacts_item import (
        ImportedSBOMDataPrimaryComponentPublisherContactsItem,
    )


T = TypeVar("T", bound="ImportedSBOMDataPrimaryComponentPublisher")


@attr.s(auto_attribs=True)
class ImportedSBOMDataPrimaryComponentPublisher:
    """
    Attributes:
        name (str):
        type (str): Allowed values: "PERSON", "ORGANIZATION", "TOOL"
        bom_ref (Union[Unset, str]):
        contacts (Union[Unset, List['ImportedSBOMDataPrimaryComponentPublisherContactsItem']]):
        urls (Union[Unset, List[str]]):
    """

    name: str
    type: str
    bom_ref: Union[Unset, str] = UNSET
    contacts: Union[Unset, List["ImportedSBOMDataPrimaryComponentPublisherContactsItem"]] = UNSET
    urls: Union[Unset, List[str]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        name = self.name
        type = self.type
        bom_ref = self.bom_ref
        contacts: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.contacts, Unset):
            contacts = []
            for contacts_item_data in self.contacts:
                contacts_item = contacts_item_data.to_dict()

                contacts.append(contacts_item)

        urls: Union[Unset, List[str]] = UNSET
        if not isinstance(self.urls, Unset):
            urls = self.urls

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type,
            }
        )
        if bom_ref is not UNSET:
            field_dict["bom_ref"] = bom_ref
        if contacts is not UNSET:
            field_dict["contacts"] = contacts
        if urls is not UNSET:
            field_dict["urls"] = urls

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.imported_sbom_data_primary_component_publisher_contacts_item import (
            ImportedSBOMDataPrimaryComponentPublisherContactsItem,
        )

        d = src_dict.copy()
        name = d.pop("name")

        type = d.pop("type")

        bom_ref = d.pop("bom_ref", UNSET)

        _contacts = d.pop("contacts", UNSET)
        if (_contacts) is UNSET:
            contacts = UNSET
        else:
            if _contacts:
                contacts = []
                for contacts_item_data in _contacts:
                    contacts_item = ImportedSBOMDataPrimaryComponentPublisherContactsItem.from_dict(contacts_item_data)

                    contacts.append(contacts_item)
            else:
                contacts = []

        urls = cast(List[str], d.pop("urls", UNSET))

        imported_sbom_data_primary_component_publisher = cls(
            name=name,
            type=type,
            bom_ref=bom_ref,
            contacts=contacts,
            urls=urls,
        )

        imported_sbom_data_primary_component_publisher.additional_properties = d
        return imported_sbom_data_primary_component_publisher

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
