import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ImportSbomSourceResponse200DataSbomSource")


@attr.s(auto_attribs=True)
class ImportSbomSourceResponse200DataSbomSource:
    """Source which is going to be used for new sbom packages. Is used only for async calls to find new sboms which are
    linked to the given source id

        Attributes:
            created_at (Union[Unset, datetime.datetime]):
            created_by (Union[Unset, str]): Name of the user who did the import
            created_by_user_id (Union[Unset, str]): ID of the user who did the import
            dt_version_id (Union[Unset, str]): ID of linked dt version
            id (Union[Unset, str]): ID of sbom source object
            source_name (Union[Unset, str]): Sbom source name
            source_type (Union[Unset, str]): Sbom source type
    """

    created_at: Union[Unset, datetime.datetime] = UNSET
    created_by: Union[Unset, str] = UNSET
    created_by_user_id: Union[Unset, str] = UNSET
    dt_version_id: Union[Unset, str] = UNSET
    id: Union[Unset, str] = UNSET
    source_name: Union[Unset, str] = UNSET
    source_type: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        created_at: Union[Unset, str] = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        created_by = self.created_by
        created_by_user_id = self.created_by_user_id
        dt_version_id = self.dt_version_id
        id = self.id
        source_name = self.source_name
        source_type = self.source_type

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if created_by_user_id is not UNSET:
            field_dict["created_by_user_id"] = created_by_user_id
        if dt_version_id is not UNSET:
            field_dict["dt_version_id"] = dt_version_id
        if id is not UNSET:
            field_dict["id"] = id
        if source_name is not UNSET:
            field_dict["source_name"] = source_name
        if source_type is not UNSET:
            field_dict["source_type"] = source_type

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _created_at = d.pop("created_at", UNSET)
        created_at: Union[Unset, datetime.datetime]
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        created_by = d.pop("created_by", UNSET)

        created_by_user_id = d.pop("created_by_user_id", UNSET)

        dt_version_id = d.pop("dt_version_id", UNSET)

        id = d.pop("id", UNSET)

        source_name = d.pop("source_name", UNSET)

        source_type = d.pop("source_type", UNSET)

        import_sbom_source_response_200_data_sbom_source = cls(
            created_at=created_at,
            created_by=created_by,
            created_by_user_id=created_by_user_id,
            dt_version_id=dt_version_id,
            id=id,
            source_name=source_name,
            source_type=source_type,
        )

        import_sbom_source_response_200_data_sbom_source.additional_properties = d
        return import_sbom_source_response_200_data_sbom_source

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
