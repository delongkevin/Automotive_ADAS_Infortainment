from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.errors_for_an_sbom_document_analysis_document_analysis_result import (
        ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResult,
    )


T = TypeVar("T", bound="ErrorsForAnSBOMDocumentAnalysis")


@attr.s(auto_attribs=True)
class ErrorsForAnSBOMDocumentAnalysis:
    """The errors for an SBOM document analysis Note: this is a truncated version of the data returned by the
    "/api/dts/get_analysis_progress" API ("Get analysis status")

        Attributes:
            document_analysis_result (Union[Unset, ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResult]):
    """

    document_analysis_result: Union[Unset, "ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResult"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        document_analysis_result: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.document_analysis_result, Unset):
            document_analysis_result = self.document_analysis_result.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if document_analysis_result is not UNSET:
            field_dict["document_analysis_result"] = document_analysis_result

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.errors_for_an_sbom_document_analysis_document_analysis_result import (
            ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResult,
        )

        d = src_dict.copy()
        _document_analysis_result = d.pop("document_analysis_result", UNSET)
        document_analysis_result: Union[Unset, ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResult]
        if isinstance(_document_analysis_result, Unset):
            document_analysis_result = UNSET
        else:
            document_analysis_result = ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResult.from_dict(
                _document_analysis_result
            )

        errors_for_an_sbom_document_analysis = cls(
            document_analysis_result=document_analysis_result,
        )

        errors_for_an_sbom_document_analysis.additional_properties = d
        return errors_for_an_sbom_document_analysis

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
