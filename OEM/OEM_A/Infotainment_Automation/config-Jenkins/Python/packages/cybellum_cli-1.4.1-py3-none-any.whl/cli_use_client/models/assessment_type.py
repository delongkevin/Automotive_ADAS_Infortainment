from enum import Enum
from typing import Union


class AssessmentType(str, Enum):
    ZERO_DAYS = "zero_days"

    VULNERABILITIES = "vulnerabilities"

    POLICIES = "policies"

    MALWARE = "malware"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "AssessmentType"]) -> "AssessmentType":
        if isinstance(value, AssessmentType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return AssessmentType(value)
