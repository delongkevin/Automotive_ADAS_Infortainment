from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.vulnerabilities_assessment_version_stats_by_status import (
        VulnerabilitiesAssessmentVersionStatsByStatus,
    )


T = TypeVar("T", bound="VulnerabilitiesAssessmentVersionStats")


@attr.s(auto_attribs=True)
class VulnerabilitiesAssessmentVersionStats:
    """Vulnerabilities assessment version stats

    Attributes:
        by_status (Union[Unset, VulnerabilitiesAssessmentVersionStatsByStatus]): A dictionary of status - severity
            seperation of the vulnerabilities of the assessment version
    """

    by_status: Union[Unset, "VulnerabilitiesAssessmentVersionStatsByStatus"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        by_status: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.by_status, Unset):
            by_status = self.by_status.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if by_status is not UNSET:
            field_dict["by_status"] = by_status

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.vulnerabilities_assessment_version_stats_by_status import (
            VulnerabilitiesAssessmentVersionStatsByStatus,
        )

        d = src_dict.copy()
        _by_status = d.pop("by_status", UNSET)
        by_status: Union[Unset, VulnerabilitiesAssessmentVersionStatsByStatus]
        if isinstance(_by_status, Unset):
            by_status = UNSET
        else:
            by_status = VulnerabilitiesAssessmentVersionStatsByStatus.from_dict(_by_status)

        vulnerabilities_assessment_version_stats = cls(
            by_status=by_status,
        )

        vulnerabilities_assessment_version_stats.additional_properties = d
        return vulnerabilities_assessment_version_stats

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
