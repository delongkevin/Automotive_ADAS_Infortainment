from enum import Enum
from typing import Union


class ExportDigitalTwinCyclonedxSpec(str, Enum):
    VALUE_0 = "1.6"

    VALUE_1 = "1.5"

    VALUE_2 = "1.4"

    VALUE_3 = "1.3"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "ExportDigitalTwinCyclonedxSpec"]) -> "ExportDigitalTwinCyclonedxSpec":
        if isinstance(value, ExportDigitalTwinCyclonedxSpec):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return ExportDigitalTwinCyclonedxSpec(value)
