from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="AutofixErrorsForAnSBOMDocumentAnalysisErrorsItem")


@attr.s(auto_attribs=True)
class AutofixErrorsForAnSBOMDocumentAnalysisErrorsItem:
    """
    Attributes:
        action (Union[Unset, str]):
        finding (Union[Unset, str]):
        location (Union[Unset, str]):
    """

    action: Union[Unset, str] = UNSET
    finding: Union[Unset, str] = UNSET
    location: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        action = self.action
        finding = self.finding
        location = self.location

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if action is not UNSET:
            field_dict["action"] = action
        if finding is not UNSET:
            field_dict["finding"] = finding
        if location is not UNSET:
            field_dict["location"] = location

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        action = d.pop("action", UNSET)

        finding = d.pop("finding", UNSET)

        location = d.pop("location", UNSET)

        autofix_errors_for_an_sbom_document_analysis_errors_item = cls(
            action=action,
            finding=finding,
            location=location,
        )

        autofix_errors_for_an_sbom_document_analysis_errors_item.additional_properties = d
        return autofix_errors_for_an_sbom_document_analysis_errors_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
