from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.metadata_autosar import MetadataAutosar
    from ..models.metadata_cpu import MetadataCpu


T = TypeVar("T", bound="Metadata")


@attr.s(auto_attribs=True)
class Metadata:
    """Metadata

    Attributes:
        autosar (Union[Unset, MetadataAutosar]):
        cpu (Union[Unset, MetadataCpu]): CPU information
    """

    autosar: Union[Unset, "MetadataAutosar"] = UNSET
    cpu: Union[Unset, "MetadataCpu"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        autosar: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.autosar, Unset):
            autosar = self.autosar.to_dict()

        cpu: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.cpu, Unset):
            cpu = self.cpu.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if autosar is not UNSET:
            field_dict["autosar"] = autosar
        if cpu is not UNSET:
            field_dict["cpu"] = cpu

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.metadata_autosar import MetadataAutosar
        from ..models.metadata_cpu import MetadataCpu

        d = src_dict.copy()
        _autosar = d.pop("autosar", UNSET)
        autosar: Union[Unset, MetadataAutosar]
        if isinstance(_autosar, Unset):
            autosar = UNSET
        else:
            autosar = MetadataAutosar.from_dict(_autosar)

        _cpu = d.pop("cpu", UNSET)
        cpu: Union[Unset, MetadataCpu]
        if isinstance(_cpu, Unset):
            cpu = UNSET
        else:
            cpu = MetadataCpu.from_dict(_cpu)

        metadata = cls(
            autosar=autosar,
            cpu=cpu,
        )

        metadata.additional_properties = d
        return metadata

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
