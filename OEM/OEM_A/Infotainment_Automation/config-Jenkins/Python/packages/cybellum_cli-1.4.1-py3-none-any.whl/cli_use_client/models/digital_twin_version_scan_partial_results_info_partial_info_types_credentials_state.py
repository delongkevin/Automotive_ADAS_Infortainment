from enum import Enum
from typing import Union


class DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentialsState(str, Enum):
    SUCCESS = "success"

    FAILED = "failed"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(
        cls, value: Union[str, "DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentialsState"]
    ) -> "DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentialsState":
        if isinstance(value, DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentialsState):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentialsState(value)
