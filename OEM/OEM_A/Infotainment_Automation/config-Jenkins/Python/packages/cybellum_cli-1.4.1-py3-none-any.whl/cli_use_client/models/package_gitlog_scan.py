from typing import Any, Dict, List, Type, TypeVar

import attr

from ..models.scan_state import ScanState
from ..models.scan_sub_state import ScanSubState

T = TypeVar("T", bound="PackageGitlogScan")


@attr.s(auto_attribs=True)
class PackageGitlogScan:
    """
    Attributes:
        state (ScanState): Scan state
        sub_state (ScanSubState): Scan sub state
        worker_id (str): Worker id of the gitlog scan
    """

    state: ScanState
    sub_state: ScanSubState
    worker_id: str
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        state = ScanState.from_val(self.state).value

        sub_state = ScanSubState.from_val(self.sub_state).value

        worker_id = self.worker_id

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "state": state,
                "sub_state": sub_state,
                "worker_id": worker_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        state = ScanState.from_val(d.pop("state"))

        sub_state = ScanSubState.from_val(d.pop("sub_state"))

        worker_id = d.pop("worker_id")

        package_gitlog_scan = cls(
            state=state,
            sub_state=sub_state,
            worker_id=worker_id,
        )

        package_gitlog_scan.additional_properties = d
        return package_gitlog_scan

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
