from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="ImportedSBOMDataLicenseTextItem")


@attr.s(auto_attribs=True)
class ImportedSBOMDataLicenseTextItem:
    """
    Attributes:
        reference (str):
        text (str):
        name (Union[Unset, str]):
    """

    reference: str
    text: str
    name: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        reference = self.reference
        text = self.text
        name = self.name

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "reference": reference,
                "text": text,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        reference = d.pop("reference")

        text = d.pop("text")

        name = d.pop("name", UNSET)

        imported_sbom_data_license_text_item = cls(
            reference=reference,
            text=text,
            name=name,
        )

        imported_sbom_data_license_text_item.additional_properties = d
        return imported_sbom_data_license_text_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
