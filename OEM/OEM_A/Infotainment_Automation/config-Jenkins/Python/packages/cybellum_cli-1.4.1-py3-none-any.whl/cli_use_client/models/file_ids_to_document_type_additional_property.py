from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="FileIdsToDocumentTypeAdditionalProperty")


@attr.s(auto_attribs=True)
class FileIdsToDocumentTypeAdditionalProperty:
    """
    Attributes:
        document_type (Union[Unset, str]): "spdx", "cyclonedx", "cpe" or "other"
        error (Union[Unset, str]): None or error string
        file_path (Union[Unset, str]):
        upload_size (Union[Unset, int]): None or total bytes uploaded
    """

    document_type: Union[Unset, str] = UNSET
    error: Union[Unset, str] = UNSET
    file_path: Union[Unset, str] = UNSET
    upload_size: Union[Unset, int] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        document_type = self.document_type
        error = self.error
        file_path = self.file_path
        upload_size = self.upload_size

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if document_type is not UNSET:
            field_dict["document_type"] = document_type
        if error is not UNSET:
            field_dict["error"] = error
        if file_path is not UNSET:
            field_dict["file_path"] = file_path
        if upload_size is not UNSET:
            field_dict["upload_size"] = upload_size

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        document_type = d.pop("document_type", UNSET)

        error = d.pop("error", UNSET)

        file_path = d.pop("file_path", UNSET)

        upload_size = d.pop("upload_size", UNSET)

        file_ids_to_document_type_additional_property = cls(
            document_type=document_type,
            error=error,
            file_path=file_path,
            upload_size=upload_size,
        )

        file_ids_to_document_type_additional_property.additional_properties = d
        return file_ids_to_document_type_additional_property

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
