from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.element_type import ElementType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.attached_elements_dt_version import AttachedElementsDtVersion
    from ..models.attached_elements_product_version import AttachedElementsProductVersion
    from ..models.attached_elements_virtual_dt import AttachedElementsVirtualDt


T = TypeVar("T", bound="AttachedElements")


@attr.s(auto_attribs=True)
class AttachedElements:
    """Attached elements

    Attributes:
        type (ElementType): Element type
        dt_version (Union[Unset, AttachedElementsDtVersion]):
        product_version (Union[Unset, AttachedElementsProductVersion]):
        virtual_dt (Union[Unset, AttachedElementsVirtualDt]):
    """

    type: ElementType
    dt_version: Union[Unset, "AttachedElementsDtVersion"] = UNSET
    product_version: Union[Unset, "AttachedElementsProductVersion"] = UNSET
    virtual_dt: Union[Unset, "AttachedElementsVirtualDt"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        type = ElementType.from_val(self.type).value

        dt_version: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.dt_version, Unset):
            dt_version = self.dt_version.to_dict()

        product_version: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.product_version, Unset):
            product_version = self.product_version.to_dict()

        virtual_dt: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.virtual_dt, Unset):
            virtual_dt = self.virtual_dt.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type,
            }
        )
        if dt_version is not UNSET:
            field_dict["dt_version"] = dt_version
        if product_version is not UNSET:
            field_dict["product_version"] = product_version
        if virtual_dt is not UNSET:
            field_dict["virtual_dt"] = virtual_dt

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.attached_elements_dt_version import AttachedElementsDtVersion
        from ..models.attached_elements_product_version import AttachedElementsProductVersion
        from ..models.attached_elements_virtual_dt import AttachedElementsVirtualDt

        d = src_dict.copy()
        type = ElementType.from_val(d.pop("type"))

        _dt_version = d.pop("dt_version", UNSET)
        dt_version: Union[Unset, AttachedElementsDtVersion]
        if isinstance(_dt_version, Unset):
            dt_version = UNSET
        else:
            dt_version = AttachedElementsDtVersion.from_dict(_dt_version)

        _product_version = d.pop("product_version", UNSET)
        product_version: Union[Unset, AttachedElementsProductVersion]
        if isinstance(_product_version, Unset):
            product_version = UNSET
        else:
            product_version = AttachedElementsProductVersion.from_dict(_product_version)

        _virtual_dt = d.pop("virtual_dt", UNSET)
        virtual_dt: Union[Unset, AttachedElementsVirtualDt]
        if isinstance(_virtual_dt, Unset):
            virtual_dt = UNSET
        else:
            virtual_dt = AttachedElementsVirtualDt.from_dict(_virtual_dt)

        attached_elements = cls(
            type=type,
            dt_version=dt_version,
            product_version=product_version,
            virtual_dt=virtual_dt,
        )

        attached_elements.additional_properties = d
        return attached_elements

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
