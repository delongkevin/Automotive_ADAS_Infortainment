from enum import Enum
from typing import Union


class PackageCPEType(str, Enum):
    A = "a"

    H = "h"

    O = "o"

    K = "k"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "PackageCPEType"]) -> "PackageCPEType":
        if isinstance(value, PackageCPEType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return PackageCPEType(value)
