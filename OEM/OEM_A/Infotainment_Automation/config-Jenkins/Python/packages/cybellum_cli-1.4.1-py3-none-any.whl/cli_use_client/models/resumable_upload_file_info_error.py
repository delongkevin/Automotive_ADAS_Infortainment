from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="ResumableUploadFileInfoError")


@attr.s(auto_attribs=True)
class ResumableUploadFileInfoError:
    """Resumable upload file info error

    Attributes:
        description (Union[Unset, str]): Error description
        error_code (Union[Unset, str]): File upload error code
        phase (Union[Unset, str]): Name of the phase where the error occurred
    """

    description: Union[Unset, str] = UNSET
    error_code: Union[Unset, str] = UNSET
    phase: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        description = self.description
        error_code = self.error_code
        phase = self.phase

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if description is not UNSET:
            field_dict["description"] = description
        if error_code is not UNSET:
            field_dict["error_code"] = error_code
        if phase is not UNSET:
            field_dict["phase"] = phase

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        description = d.pop("description", UNSET)

        error_code = d.pop("error_code", UNSET)

        phase = d.pop("phase", UNSET)

        resumable_upload_file_info_error = cls(
            description=description,
            error_code=error_code,
            phase=phase,
        )

        resumable_upload_file_info_error.additional_properties = d
        return resumable_upload_file_info_error

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
