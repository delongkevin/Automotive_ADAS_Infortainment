from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.element_type import ElementType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin import DigitalTwin
    from ..models.product import Product
    from ..models.virtual_digital_twin import VirtualDigitalTwin


T = TypeVar("T", bound="AttachedElement")


@attr.s(auto_attribs=True)
class AttachedElement:
    """Attached element

    Attributes:
        type (ElementType): Element type
        dt (Union[Unset, DigitalTwin]): Digital twin
        product (Union[Unset, Product]): Product
        virtual_dt (Union[Unset, VirtualDigitalTwin]): Virtual digital twin
    """

    type: ElementType
    dt: Union[Unset, "DigitalTwin"] = UNSET
    product: Union[Unset, "Product"] = UNSET
    virtual_dt: Union[Unset, "VirtualDigitalTwin"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        type = ElementType.from_val(self.type).value

        dt: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.dt, Unset):
            dt = self.dt.to_dict()

        product: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.product, Unset):
            product = self.product.to_dict()

        virtual_dt: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.virtual_dt, Unset):
            virtual_dt = self.virtual_dt.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type,
            }
        )
        if dt is not UNSET:
            field_dict["dt"] = dt
        if product is not UNSET:
            field_dict["product"] = product
        if virtual_dt is not UNSET:
            field_dict["virtual_dt"] = virtual_dt

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin import DigitalTwin
        from ..models.product import Product
        from ..models.virtual_digital_twin import VirtualDigitalTwin

        d = src_dict.copy()
        type = ElementType.from_val(d.pop("type"))

        _dt = d.pop("dt", UNSET)
        dt: Union[Unset, DigitalTwin]
        if isinstance(_dt, Unset):
            dt = UNSET
        else:
            dt = DigitalTwin.from_dict(_dt)

        _product = d.pop("product", UNSET)
        product: Union[Unset, Product]
        if isinstance(_product, Unset):
            product = UNSET
        else:
            product = Product.from_dict(_product)

        _virtual_dt = d.pop("virtual_dt", UNSET)
        virtual_dt: Union[Unset, VirtualDigitalTwin]
        if isinstance(_virtual_dt, Unset):
            virtual_dt = UNSET
        else:
            virtual_dt = VirtualDigitalTwin.from_dict(_virtual_dt)

        attached_element = cls(
            type=type,
            dt=dt,
            product=product,
            virtual_dt=virtual_dt,
        )

        attached_element.additional_properties = d
        return attached_element

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
