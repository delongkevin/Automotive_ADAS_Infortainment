from typing import Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..models.resumable_upload_session_type import ResumableUploadSessionType
from ..types import UNSET, Unset

T = TypeVar("T", bound="ResumableUploadSessionParams")


@attr.s(auto_attribs=True)
class ResumableUploadSessionParams:
    """Resumable upload session params

    Attributes:
        type (ResumableUploadSessionType): Session type
        auto_complete (Union[Unset, bool]): Session auto complete file Default: True.
        default_flow (Union[Unset, List[str]]): Session flow
    """

    type: ResumableUploadSessionType
    auto_complete: Union[Unset, bool] = True
    default_flow: Union[Unset, List[str]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        type = ResumableUploadSessionType.from_val(self.type).value

        auto_complete = self.auto_complete
        default_flow: Union[Unset, List[str]] = UNSET
        if not isinstance(self.default_flow, Unset):
            default_flow = self.default_flow

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type,
            }
        )
        if auto_complete is not UNSET:
            field_dict["auto_complete"] = auto_complete
        if default_flow is not UNSET:
            field_dict["default_flow"] = default_flow

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        type = ResumableUploadSessionType.from_val(d.pop("type"))

        auto_complete = d.pop("auto_complete", UNSET)

        default_flow = cast(List[str], d.pop("default_flow", UNSET))

        resumable_upload_session_params = cls(
            type=type,
            auto_complete=auto_complete,
            default_flow=default_flow,
        )

        resumable_upload_session_params.additional_properties = d
        return resumable_upload_session_params

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
