from enum import Enum
from typing import Union


class SBOMPackageInfoFindingsItem(str, Enum):
    MISSING_VERSION = "missing_version"

    MISSING_LICENSES = "missing_licenses"

    MISSING_SUPPLIER = "missing_supplier"

    MISSING_CPE = "missing_cpe"

    MISSING_EOL = "missing_eol"

    MISSING_EOS = "missing_eos"

    EOL = "eol"

    EOS = "eos"

    APPROVED = "approved"

    CPE_NOT_VERIFIED = "cpe_not_verified"

    IS_LOCAL_PACKAGE = "is_local_package"

    NO_FINDINGS = "no_findings"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "SBOMPackageInfoFindingsItem"]) -> "SBOMPackageInfoFindingsItem":
        if isinstance(value, SBOMPackageInfoFindingsItem):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return SBOMPackageInfoFindingsItem(value)
