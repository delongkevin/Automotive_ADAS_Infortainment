from enum import Enum
from typing import Union


class ElementType(str, Enum):
    PRODUCT_VERSION = "product_version"

    DT_VERSION = "dt_version"

    VIRTUAL_DT = "virtual_dt"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "ElementType"]) -> "ElementType":
        if isinstance(value, ElementType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return ElementType(value)
