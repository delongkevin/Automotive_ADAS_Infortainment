from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.imported_sbom_data_components_item_authors_item import ImportedSBOMDataComponentsItemAuthorsItem
    from ..models.imported_sbom_data_components_item_cpes_item import ImportedSBOMDataComponentsItemCpesItem
    from ..models.imported_sbom_data_components_item_external_references_item import (
        ImportedSBOMDataComponentsItemExternalReferencesItem,
    )
    from ..models.imported_sbom_data_components_item_group import ImportedSBOMDataComponentsItemGroup
    from ..models.imported_sbom_data_components_item_hashes_item import ImportedSBOMDataComponentsItemHashesItem
    from ..models.imported_sbom_data_components_item_licenses_item import ImportedSBOMDataComponentsItemLicensesItem
    from ..models.imported_sbom_data_components_item_originator import ImportedSBOMDataComponentsItemOriginator
    from ..models.imported_sbom_data_components_item_properties_item import ImportedSBOMDataComponentsItemPropertiesItem
    from ..models.imported_sbom_data_components_item_publisher import ImportedSBOMDataComponentsItemPublisher
    from ..models.imported_sbom_data_components_item_supplier import ImportedSBOMDataComponentsItemSupplier
    from ..models.imported_sbom_data_components_item_swid import ImportedSBOMDataComponentsItemSwid


T = TypeVar("T", bound="ImportedSBOMDataComponentsItem")


@attr.s(auto_attribs=True)
class ImportedSBOMDataComponentsItem:
    """
    Attributes:
        name (str):
        authors (Union[Unset, List['ImportedSBOMDataComponentsItemAuthorsItem']]):
        bom_ref (Union[Unset, str]):
        comment (Union[Unset, str]):
        component_file_name (Union[Unset, str]):
        copyright_ (Union[Unset, str]):
        cpes (Union[Unset, List['ImportedSBOMDataComponentsItemCpesItem']]):
        description (Union[Unset, str]):
        external_references (Union[Unset, List['ImportedSBOMDataComponentsItemExternalReferencesItem']]):
        file_name (Union[Unset, str]):
        group (Union[Unset, ImportedSBOMDataComponentsItemGroup]):
        hashes (Union[Unset, List['ImportedSBOMDataComponentsItemHashesItem']]):
        licenses (Union[Unset, List['ImportedSBOMDataComponentsItemLicensesItem']]):
        originator (Union[Unset, ImportedSBOMDataComponentsItemOriginator]):
        properties (Union[Unset, List['ImportedSBOMDataComponentsItemPropertiesItem']]):
        publisher (Union[Unset, ImportedSBOMDataComponentsItemPublisher]):
        purls (Union[Unset, List[str]]):
        supplier (Union[Unset, ImportedSBOMDataComponentsItemSupplier]):
        swid (Union[Unset, ImportedSBOMDataComponentsItemSwid]):
        type (Union[Unset, str]): Allowed values: "application", "framework", "library", "container", "platform",
            "operating-system", "device", "device-driver", "firmware", "machine-learning-model", "data", "file", "hardware",
            "kernel", "source", "archive", "install", "other"
        vendor (Union[Unset, str]):
        version (Union[Unset, str]):
        website (Union[Unset, str]):
    """

    name: str
    authors: Union[Unset, List["ImportedSBOMDataComponentsItemAuthorsItem"]] = UNSET
    bom_ref: Union[Unset, str] = UNSET
    comment: Union[Unset, str] = UNSET
    component_file_name: Union[Unset, str] = UNSET
    copyright_: Union[Unset, str] = UNSET
    cpes: Union[Unset, List["ImportedSBOMDataComponentsItemCpesItem"]] = UNSET
    description: Union[Unset, str] = UNSET
    external_references: Union[Unset, List["ImportedSBOMDataComponentsItemExternalReferencesItem"]] = UNSET
    file_name: Union[Unset, str] = UNSET
    group: Union[Unset, "ImportedSBOMDataComponentsItemGroup"] = UNSET
    hashes: Union[Unset, List["ImportedSBOMDataComponentsItemHashesItem"]] = UNSET
    licenses: Union[Unset, List["ImportedSBOMDataComponentsItemLicensesItem"]] = UNSET
    originator: Union[Unset, "ImportedSBOMDataComponentsItemOriginator"] = UNSET
    properties: Union[Unset, List["ImportedSBOMDataComponentsItemPropertiesItem"]] = UNSET
    publisher: Union[Unset, "ImportedSBOMDataComponentsItemPublisher"] = UNSET
    purls: Union[Unset, List[str]] = UNSET
    supplier: Union[Unset, "ImportedSBOMDataComponentsItemSupplier"] = UNSET
    swid: Union[Unset, "ImportedSBOMDataComponentsItemSwid"] = UNSET
    type: Union[Unset, str] = UNSET
    vendor: Union[Unset, str] = UNSET
    version: Union[Unset, str] = UNSET
    website: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        name = self.name
        authors: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.authors, Unset):
            authors = []
            for authors_item_data in self.authors:
                authors_item = authors_item_data.to_dict()

                authors.append(authors_item)

        bom_ref = self.bom_ref
        comment = self.comment
        component_file_name = self.component_file_name
        copyright_ = self.copyright_
        cpes: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.cpes, Unset):
            cpes = []
            for cpes_item_data in self.cpes:
                cpes_item = cpes_item_data.to_dict()

                cpes.append(cpes_item)

        description = self.description
        external_references: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.external_references, Unset):
            external_references = []
            for external_references_item_data in self.external_references:
                external_references_item = external_references_item_data.to_dict()

                external_references.append(external_references_item)

        file_name = self.file_name
        group: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.group, Unset):
            group = self.group.to_dict()

        hashes: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.hashes, Unset):
            hashes = []
            for hashes_item_data in self.hashes:
                hashes_item = hashes_item_data.to_dict()

                hashes.append(hashes_item)

        licenses: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.licenses, Unset):
            licenses = []
            for licenses_item_data in self.licenses:
                licenses_item = licenses_item_data.to_dict()

                licenses.append(licenses_item)

        originator: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.originator, Unset):
            originator = self.originator.to_dict()

        properties: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.properties, Unset):
            properties = []
            for properties_item_data in self.properties:
                properties_item = properties_item_data.to_dict()

                properties.append(properties_item)

        publisher: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.publisher, Unset):
            publisher = self.publisher.to_dict()

        purls: Union[Unset, List[str]] = UNSET
        if not isinstance(self.purls, Unset):
            purls = self.purls

        supplier: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.supplier, Unset):
            supplier = self.supplier.to_dict()

        swid: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.swid, Unset):
            swid = self.swid.to_dict()

        type = self.type
        vendor = self.vendor
        version = self.version
        website = self.website

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if authors is not UNSET:
            field_dict["authors"] = authors
        if bom_ref is not UNSET:
            field_dict["bom_ref"] = bom_ref
        if comment is not UNSET:
            field_dict["comment"] = comment
        if component_file_name is not UNSET:
            field_dict["component_file_name"] = component_file_name
        if copyright_ is not UNSET:
            field_dict["copyright"] = copyright_
        if cpes is not UNSET:
            field_dict["cpes"] = cpes
        if description is not UNSET:
            field_dict["description"] = description
        if external_references is not UNSET:
            field_dict["external_references"] = external_references
        if file_name is not UNSET:
            field_dict["file_name"] = file_name
        if group is not UNSET:
            field_dict["group"] = group
        if hashes is not UNSET:
            field_dict["hashes"] = hashes
        if licenses is not UNSET:
            field_dict["licenses"] = licenses
        if originator is not UNSET:
            field_dict["originator"] = originator
        if properties is not UNSET:
            field_dict["properties"] = properties
        if publisher is not UNSET:
            field_dict["publisher"] = publisher
        if purls is not UNSET:
            field_dict["purls"] = purls
        if supplier is not UNSET:
            field_dict["supplier"] = supplier
        if swid is not UNSET:
            field_dict["swid"] = swid
        if type is not UNSET:
            field_dict["type"] = type
        if vendor is not UNSET:
            field_dict["vendor"] = vendor
        if version is not UNSET:
            field_dict["version"] = version
        if website is not UNSET:
            field_dict["website"] = website

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.imported_sbom_data_components_item_authors_item import ImportedSBOMDataComponentsItemAuthorsItem
        from ..models.imported_sbom_data_components_item_cpes_item import ImportedSBOMDataComponentsItemCpesItem
        from ..models.imported_sbom_data_components_item_external_references_item import (
            ImportedSBOMDataComponentsItemExternalReferencesItem,
        )
        from ..models.imported_sbom_data_components_item_group import ImportedSBOMDataComponentsItemGroup
        from ..models.imported_sbom_data_components_item_hashes_item import ImportedSBOMDataComponentsItemHashesItem
        from ..models.imported_sbom_data_components_item_licenses_item import ImportedSBOMDataComponentsItemLicensesItem
        from ..models.imported_sbom_data_components_item_originator import ImportedSBOMDataComponentsItemOriginator
        from ..models.imported_sbom_data_components_item_properties_item import (
            ImportedSBOMDataComponentsItemPropertiesItem,
        )
        from ..models.imported_sbom_data_components_item_publisher import ImportedSBOMDataComponentsItemPublisher
        from ..models.imported_sbom_data_components_item_supplier import ImportedSBOMDataComponentsItemSupplier
        from ..models.imported_sbom_data_components_item_swid import ImportedSBOMDataComponentsItemSwid

        d = src_dict.copy()
        name = d.pop("name")

        _authors = d.pop("authors", UNSET)
        if (_authors) is UNSET:
            authors = UNSET
        else:
            if _authors:
                authors = []
                for authors_item_data in _authors:
                    authors_item = ImportedSBOMDataComponentsItemAuthorsItem.from_dict(authors_item_data)

                    authors.append(authors_item)
            else:
                authors = []

        bom_ref = d.pop("bom_ref", UNSET)

        comment = d.pop("comment", UNSET)

        component_file_name = d.pop("component_file_name", UNSET)

        copyright_ = d.pop("copyright", UNSET)

        _cpes = d.pop("cpes", UNSET)
        if (_cpes) is UNSET:
            cpes = UNSET
        else:
            if _cpes:
                cpes = []
                for cpes_item_data in _cpes:
                    cpes_item = ImportedSBOMDataComponentsItemCpesItem.from_dict(cpes_item_data)

                    cpes.append(cpes_item)
            else:
                cpes = []

        description = d.pop("description", UNSET)

        _external_references = d.pop("external_references", UNSET)
        if (_external_references) is UNSET:
            external_references = UNSET
        else:
            if _external_references:
                external_references = []
                for external_references_item_data in _external_references:
                    external_references_item = ImportedSBOMDataComponentsItemExternalReferencesItem.from_dict(
                        external_references_item_data
                    )

                    external_references.append(external_references_item)
            else:
                external_references = []

        file_name = d.pop("file_name", UNSET)

        _group = d.pop("group", UNSET)
        group: Union[Unset, ImportedSBOMDataComponentsItemGroup]
        if isinstance(_group, Unset):
            group = UNSET
        else:
            group = ImportedSBOMDataComponentsItemGroup.from_dict(_group)

        _hashes = d.pop("hashes", UNSET)
        if (_hashes) is UNSET:
            hashes = UNSET
        else:
            if _hashes:
                hashes = []
                for hashes_item_data in _hashes:
                    hashes_item = ImportedSBOMDataComponentsItemHashesItem.from_dict(hashes_item_data)

                    hashes.append(hashes_item)
            else:
                hashes = []

        _licenses = d.pop("licenses", UNSET)
        if (_licenses) is UNSET:
            licenses = UNSET
        else:
            if _licenses:
                licenses = []
                for licenses_item_data in _licenses:
                    licenses_item = ImportedSBOMDataComponentsItemLicensesItem.from_dict(licenses_item_data)

                    licenses.append(licenses_item)
            else:
                licenses = []

        _originator = d.pop("originator", UNSET)
        originator: Union[Unset, ImportedSBOMDataComponentsItemOriginator]
        if isinstance(_originator, Unset):
            originator = UNSET
        else:
            originator = ImportedSBOMDataComponentsItemOriginator.from_dict(_originator)

        _properties = d.pop("properties", UNSET)
        if (_properties) is UNSET:
            properties = UNSET
        else:
            if _properties:
                properties = []
                for properties_item_data in _properties:
                    properties_item = ImportedSBOMDataComponentsItemPropertiesItem.from_dict(properties_item_data)

                    properties.append(properties_item)
            else:
                properties = []

        _publisher = d.pop("publisher", UNSET)
        publisher: Union[Unset, ImportedSBOMDataComponentsItemPublisher]
        if isinstance(_publisher, Unset):
            publisher = UNSET
        else:
            publisher = ImportedSBOMDataComponentsItemPublisher.from_dict(_publisher)

        purls = cast(List[str], d.pop("purls", UNSET))

        _supplier = d.pop("supplier", UNSET)
        supplier: Union[Unset, ImportedSBOMDataComponentsItemSupplier]
        if isinstance(_supplier, Unset):
            supplier = UNSET
        else:
            supplier = ImportedSBOMDataComponentsItemSupplier.from_dict(_supplier)

        _swid = d.pop("swid", UNSET)
        swid: Union[Unset, ImportedSBOMDataComponentsItemSwid]
        if isinstance(_swid, Unset):
            swid = UNSET
        else:
            swid = ImportedSBOMDataComponentsItemSwid.from_dict(_swid)

        type = d.pop("type", UNSET)

        vendor = d.pop("vendor", UNSET)

        version = d.pop("version", UNSET)

        website = d.pop("website", UNSET)

        imported_sbom_data_components_item = cls(
            name=name,
            authors=authors,
            bom_ref=bom_ref,
            comment=comment,
            component_file_name=component_file_name,
            copyright_=copyright_,
            cpes=cpes,
            description=description,
            external_references=external_references,
            file_name=file_name,
            group=group,
            hashes=hashes,
            licenses=licenses,
            originator=originator,
            properties=properties,
            publisher=publisher,
            purls=purls,
            supplier=supplier,
            swid=swid,
            type=type,
            vendor=vendor,
            version=version,
            website=website,
        )

        imported_sbom_data_components_item.additional_properties = d
        return imported_sbom_data_components_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
