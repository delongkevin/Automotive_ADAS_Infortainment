from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.global_policy import GlobalPolicy


T = TypeVar("T", bound="GetPoliciesResponse200Data")


@attr.s(auto_attribs=True)
class GetPoliciesResponse200Data:
    """
    Attributes:
        policies (Union[Unset, List['GlobalPolicy']]):
    """

    policies: Union[Unset, List["GlobalPolicy"]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        policies: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.policies, Unset):
            policies = []
            for policies_item_data in self.policies:
                policies_item = policies_item_data.to_dict()

                policies.append(policies_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if policies is not UNSET:
            field_dict["policies"] = policies

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.global_policy import GlobalPolicy

        d = src_dict.copy()
        _policies = d.pop("policies", UNSET)
        if (_policies) is UNSET:
            policies = UNSET
        else:
            if _policies:
                policies = []
                for policies_item_data in _policies:
                    policies_item = GlobalPolicy.from_dict(policies_item_data)

                    policies.append(policies_item)
            else:
                policies = []

        get_policies_response_200_data = cls(
            policies=policies,
        )

        get_policies_response_200_data.additional_properties = d
        return get_policies_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
