from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="ImportedSBOMDataMetadataTools")


@attr.s(auto_attribs=True)
class ImportedSBOMDataMetadataTools:
    """
    Attributes:
        name (str):
        url (Union[Unset, str]):
        vendor (Union[Unset, str]):
        version (Union[Unset, str]):
    """

    name: str
    url: Union[Unset, str] = UNSET
    vendor: Union[Unset, str] = UNSET
    version: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        name = self.name
        url = self.url
        vendor = self.vendor
        version = self.version

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if url is not UNSET:
            field_dict["url"] = url
        if vendor is not UNSET:
            field_dict["vendor"] = vendor
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        name = d.pop("name")

        url = d.pop("url", UNSET)

        vendor = d.pop("vendor", UNSET)

        version = d.pop("version", UNSET)

        imported_sbom_data_metadata_tools = cls(
            name=name,
            url=url,
            vendor=vendor,
            version=version,
        )

        imported_sbom_data_metadata_tools.additional_properties = d
        return imported_sbom_data_metadata_tools

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
