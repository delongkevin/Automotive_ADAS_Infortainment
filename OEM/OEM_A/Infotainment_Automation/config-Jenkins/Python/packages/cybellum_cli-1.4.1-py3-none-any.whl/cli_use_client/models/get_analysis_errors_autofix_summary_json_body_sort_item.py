from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="GetAnalysisErrorsAutofixSummaryJsonBodySortItem")


@attr.s(auto_attribs=True)
class GetAnalysisErrorsAutofixSummaryJsonBodySortItem:
    """
    Attributes:
        direction (Union[Unset, str]): "ascending" or "descending"
             Default: '\\"descending\\"\n'.
        key (Union[Unset, str]): "package_name" or "num_of_errors"
             Default: '\\"num_of_errors\\"\n'.
    """

    direction: Union[Unset, str] = '\\"descending\\"\n'
    key: Union[Unset, str] = '\\"num_of_errors\\"\n'
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        direction = self.direction
        key = self.key

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if direction is not UNSET:
            field_dict["direction"] = direction
        if key is not UNSET:
            field_dict["key"] = key

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        direction = d.pop("direction", UNSET)

        key = d.pop("key", UNSET)

        get_analysis_errors_autofix_summary_json_body_sort_item = cls(
            direction=direction,
            key=key,
        )

        get_analysis_errors_autofix_summary_json_body_sort_item.additional_properties = d
        return get_analysis_errors_autofix_summary_json_body_sort_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
