from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.policies_assessment_version_dependent_assessment_versions_item import (
        PoliciesAssessmentVersionDependentAssessmentVersionsItem,
    )
    from ..models.policies_assessment_version_scan import PoliciesAssessmentVersionScan
    from ..models.policies_assessment_version_stats import PoliciesAssessmentVersionStats


T = TypeVar("T", bound="PoliciesAssessmentVersion")


@attr.s(auto_attribs=True)
class PoliciesAssessmentVersion:
    """Policies assessment version

    Attributes:
        created_on (str): Creation date of the assessment
        dt_version_id (str): ID
        id (str): ID
        last_modified_on (str): Last modified date
        assessment_id (Union[Unset, str]): ID
        created_by (Union[Unset, str]): ID
        dependent_assessment_versions (Union[Unset, List['PoliciesAssessmentVersionDependentAssessmentVersionsItem']]):
        inherit_from_previous_version (Union[Unset, bool]): Inherit from previous assessment version
        latest_scan (Union[Unset, PoliciesAssessmentVersionScan]): Policies assessment version scan
        prev_assessment_version_id (Union[Unset, str]): ID
        stats (Union[Unset, PoliciesAssessmentVersionStats]): Policies assessment version stats
    """

    created_on: str
    dt_version_id: str
    id: str
    last_modified_on: str
    assessment_id: Union[Unset, str] = UNSET
    created_by: Union[Unset, str] = UNSET
    dependent_assessment_versions: Union[Unset, List["PoliciesAssessmentVersionDependentAssessmentVersionsItem"]] = (
        UNSET
    )
    inherit_from_previous_version: Union[Unset, bool] = UNSET
    latest_scan: Union[Unset, "PoliciesAssessmentVersionScan"] = UNSET
    prev_assessment_version_id: Union[Unset, str] = UNSET
    stats: Union[Unset, "PoliciesAssessmentVersionStats"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        created_on = self.created_on
        dt_version_id = self.dt_version_id
        id = self.id
        last_modified_on = self.last_modified_on
        assessment_id = self.assessment_id
        created_by = self.created_by
        dependent_assessment_versions: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.dependent_assessment_versions, Unset):
            dependent_assessment_versions = []
            for dependent_assessment_versions_item_data in self.dependent_assessment_versions:
                dependent_assessment_versions_item = dependent_assessment_versions_item_data.to_dict()

                dependent_assessment_versions.append(dependent_assessment_versions_item)

        inherit_from_previous_version = self.inherit_from_previous_version
        latest_scan: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.latest_scan, Unset):
            latest_scan = self.latest_scan.to_dict()

        prev_assessment_version_id = self.prev_assessment_version_id
        stats: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.stats, Unset):
            stats = self.stats.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "created_on": created_on,
                "dt_version_id": dt_version_id,
                "id": id,
                "last_modified_on": last_modified_on,
            }
        )
        if assessment_id is not UNSET:
            field_dict["assessment_id"] = assessment_id
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if dependent_assessment_versions is not UNSET:
            field_dict["dependent_assessment_versions"] = dependent_assessment_versions
        if inherit_from_previous_version is not UNSET:
            field_dict["inherit_from_previous_version"] = inherit_from_previous_version
        if latest_scan is not UNSET:
            field_dict["latest_scan"] = latest_scan
        if prev_assessment_version_id is not UNSET:
            field_dict["prev_assessment_version_id"] = prev_assessment_version_id
        if stats is not UNSET:
            field_dict["stats"] = stats

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.policies_assessment_version_dependent_assessment_versions_item import (
            PoliciesAssessmentVersionDependentAssessmentVersionsItem,
        )
        from ..models.policies_assessment_version_scan import PoliciesAssessmentVersionScan
        from ..models.policies_assessment_version_stats import PoliciesAssessmentVersionStats

        d = src_dict.copy()
        created_on = d.pop("created_on")

        dt_version_id = d.pop("dt_version_id")

        id = d.pop("id")

        last_modified_on = d.pop("last_modified_on")

        assessment_id = d.pop("assessment_id", UNSET)

        created_by = d.pop("created_by", UNSET)

        _dependent_assessment_versions = d.pop("dependent_assessment_versions", UNSET)
        if (_dependent_assessment_versions) is UNSET:
            dependent_assessment_versions = UNSET
        else:
            if _dependent_assessment_versions:
                dependent_assessment_versions = []
                for dependent_assessment_versions_item_data in _dependent_assessment_versions:
                    dependent_assessment_versions_item = (
                        PoliciesAssessmentVersionDependentAssessmentVersionsItem.from_dict(
                            dependent_assessment_versions_item_data
                        )
                    )

                    dependent_assessment_versions.append(dependent_assessment_versions_item)
            else:
                dependent_assessment_versions = []

        inherit_from_previous_version = d.pop("inherit_from_previous_version", UNSET)

        _latest_scan = d.pop("latest_scan", UNSET)
        latest_scan: Union[Unset, PoliciesAssessmentVersionScan]
        if isinstance(_latest_scan, Unset):
            latest_scan = UNSET
        else:
            latest_scan = PoliciesAssessmentVersionScan.from_dict(_latest_scan)

        prev_assessment_version_id = d.pop("prev_assessment_version_id", UNSET)

        _stats = d.pop("stats", UNSET)
        stats: Union[Unset, PoliciesAssessmentVersionStats]
        if isinstance(_stats, Unset):
            stats = UNSET
        else:
            stats = PoliciesAssessmentVersionStats.from_dict(_stats)

        policies_assessment_version = cls(
            created_on=created_on,
            dt_version_id=dt_version_id,
            id=id,
            last_modified_on=last_modified_on,
            assessment_id=assessment_id,
            created_by=created_by,
            dependent_assessment_versions=dependent_assessment_versions,
            inherit_from_previous_version=inherit_from_previous_version,
            latest_scan=latest_scan,
            prev_assessment_version_id=prev_assessment_version_id,
            stats=stats,
        )

        policies_assessment_version.additional_properties = d
        return policies_assessment_version

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
