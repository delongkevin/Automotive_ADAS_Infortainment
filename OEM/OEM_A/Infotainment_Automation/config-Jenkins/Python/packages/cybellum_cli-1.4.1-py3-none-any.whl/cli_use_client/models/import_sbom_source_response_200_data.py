from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.import_sbom_source_response_200_data_sbom_source import ImportSbomSourceResponse200DataSbomSource
    from ..models.sbom_package import SBOMPackage


T = TypeVar("T", bound="ImportSbomSourceResponse200Data")


@attr.s(auto_attribs=True)
class ImportSbomSourceResponse200Data:
    """
    Attributes:
        packages (Union[Unset, List['SBOMPackage']]):
        sbom_source (Union[Unset, ImportSbomSourceResponse200DataSbomSource]): Source which is going to be used for new
            sbom packages. Is used only for async calls to find new sboms which are linked to the given source id
    """

    packages: Union[Unset, List["SBOMPackage"]] = UNSET
    sbom_source: Union[Unset, "ImportSbomSourceResponse200DataSbomSource"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        packages: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.packages, Unset):
            packages = []
            for packages_item_data in self.packages:
                packages_item = packages_item_data.to_dict()

                packages.append(packages_item)

        sbom_source: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.sbom_source, Unset):
            sbom_source = self.sbom_source.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if packages is not UNSET:
            field_dict["packages"] = packages
        if sbom_source is not UNSET:
            field_dict["sbom_source"] = sbom_source

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.import_sbom_source_response_200_data_sbom_source import ImportSbomSourceResponse200DataSbomSource
        from ..models.sbom_package import SBOMPackage

        d = src_dict.copy()
        _packages = d.pop("packages", UNSET)
        if (_packages) is UNSET:
            packages = UNSET
        else:
            if _packages:
                packages = []
                for packages_item_data in _packages:
                    packages_item = SBOMPackage.from_dict(packages_item_data)

                    packages.append(packages_item)
            else:
                packages = []

        _sbom_source = d.pop("sbom_source", UNSET)
        sbom_source: Union[Unset, ImportSbomSourceResponse200DataSbomSource]
        if isinstance(_sbom_source, Unset):
            sbom_source = UNSET
        else:
            sbom_source = ImportSbomSourceResponse200DataSbomSource.from_dict(_sbom_source)

        import_sbom_source_response_200_data = cls(
            packages=packages,
            sbom_source=sbom_source,
        )

        import_sbom_source_response_200_data.additional_properties = d
        return import_sbom_source_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
