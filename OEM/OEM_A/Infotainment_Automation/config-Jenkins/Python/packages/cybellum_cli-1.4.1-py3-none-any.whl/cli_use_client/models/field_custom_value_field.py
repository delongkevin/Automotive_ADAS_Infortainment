from enum import Enum
from typing import Union


class FieldCustomValueField(str, Enum):
    COMPONENT_CATEGORY = "component_category"

    PRODUCTION_PHASE = "production_phase"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "FieldCustomValueField"]) -> "FieldCustomValueField":
        if isinstance(value, FieldCustomValueField):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return FieldCustomValueField(value)
