import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_file_classification_result import (
        StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResult,
    )
    from ..models.status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_sbom_importer_version import (
        StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressSbomImporterVersion,
    )


T = TypeVar("T", bound="StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgress")


@attr.s(auto_attribs=True)
class StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgress:
    """The status (and eventually result) of the file classification

    Attributes:
        classification_id (Union[Unset, str]): A unique identifier for the classification task
        created (Union[Unset, datetime.datetime]):
        failure_reason (Union[Unset, str]):
        file_classification_result (Union[Unset,
            StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResult]):
        finished (Union[Unset, datetime.datetime]):
        sbom_importer_version (Union[Unset,
            StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressSbomImporterVersion]):
        started (Union[Unset, datetime.datetime]):
        status (Union[Unset, str]): "queued", "running" or "completed"
        success (Union[Unset, bool]): True if the classification completed successfully and False otherwise
    """

    classification_id: Union[Unset, str] = UNSET
    created: Union[Unset, datetime.datetime] = UNSET
    failure_reason: Union[Unset, str] = UNSET
    file_classification_result: Union[
        Unset,
        "StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResult",
    ] = UNSET
    finished: Union[Unset, datetime.datetime] = UNSET
    sbom_importer_version: Union[
        Unset, "StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressSbomImporterVersion"
    ] = UNSET
    started: Union[Unset, datetime.datetime] = UNSET
    status: Union[Unset, str] = UNSET
    success: Union[Unset, bool] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        classification_id = self.classification_id
        created: Union[Unset, str] = UNSET
        if not isinstance(self.created, Unset):
            created = self.created.isoformat()

        failure_reason = self.failure_reason
        file_classification_result: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.file_classification_result, Unset):
            file_classification_result = self.file_classification_result.to_dict()

        finished: Union[Unset, str] = UNSET
        if not isinstance(self.finished, Unset):
            finished = self.finished.isoformat()

        sbom_importer_version: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.sbom_importer_version, Unset):
            sbom_importer_version = self.sbom_importer_version.to_dict()

        started: Union[Unset, str] = UNSET
        if not isinstance(self.started, Unset):
            started = self.started.isoformat()

        status = self.status
        success = self.success

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if classification_id is not UNSET:
            field_dict["classification_id"] = classification_id
        if created is not UNSET:
            field_dict["created"] = created
        if failure_reason is not UNSET:
            field_dict["failure_reason"] = failure_reason
        if file_classification_result is not UNSET:
            field_dict["file_classification_result"] = file_classification_result
        if finished is not UNSET:
            field_dict["finished"] = finished
        if sbom_importer_version is not UNSET:
            field_dict["sbom_importer_version"] = sbom_importer_version
        if started is not UNSET:
            field_dict["started"] = started
        if status is not UNSET:
            field_dict["status"] = status
        if success is not UNSET:
            field_dict["success"] = success

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_file_classification_result import (
            StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResult,
        )
        from ..models.status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_sbom_importer_version import (
            StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressSbomImporterVersion,
        )

        d = src_dict.copy()
        classification_id = d.pop("classification_id", UNSET)

        _created = d.pop("created", UNSET)
        created: Union[Unset, datetime.datetime]
        if isinstance(_created, Unset):
            created = UNSET
        else:
            created = isoparse(_created)

        failure_reason = d.pop("failure_reason", UNSET)

        _file_classification_result = d.pop("file_classification_result", UNSET)
        file_classification_result: Union[
            Unset,
            StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResult,
        ]
        if isinstance(_file_classification_result, Unset):
            file_classification_result = UNSET
        else:
            file_classification_result = StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResult.from_dict(
                _file_classification_result
            )

        _finished = d.pop("finished", UNSET)
        finished: Union[Unset, datetime.datetime]
        if isinstance(_finished, Unset):
            finished = UNSET
        else:
            finished = isoparse(_finished)

        _sbom_importer_version = d.pop("sbom_importer_version", UNSET)
        sbom_importer_version: Union[
            Unset,
            StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressSbomImporterVersion,
        ]
        if isinstance(_sbom_importer_version, Unset):
            sbom_importer_version = UNSET
        else:
            sbom_importer_version = StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressSbomImporterVersion.from_dict(
                _sbom_importer_version
            )

        _started = d.pop("started", UNSET)
        started: Union[Unset, datetime.datetime]
        if isinstance(_started, Unset):
            started = UNSET
        else:
            started = isoparse(_started)

        status = d.pop("status", UNSET)

        success = d.pop("success", UNSET)

        status_of_a_file_upload_and_classification_file_classification_progress_classification_progress = cls(
            classification_id=classification_id,
            created=created,
            failure_reason=failure_reason,
            file_classification_result=file_classification_result,
            finished=finished,
            sbom_importer_version=sbom_importer_version,
            started=started,
            status=status,
            success=success,
        )

        status_of_a_file_upload_and_classification_file_classification_progress_classification_progress.additional_properties = (
            d
        )
        return status_of_a_file_upload_and_classification_file_classification_progress_classification_progress

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
