from enum import Enum
from typing import Union


class VirtualAnalystExecutionMetadataContext(str, Enum):
    MANUAL = "manual"

    VULNERABILITIES_SCAN = "vulnerabilities_scan"

    MONITOR = "monitor"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(
        cls, value: Union[str, "VirtualAnalystExecutionMetadataContext"]
    ) -> "VirtualAnalystExecutionMetadataContext":
        if isinstance(value, VirtualAnalystExecutionMetadataContext):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return VirtualAnalystExecutionMetadataContext(value)
