from http import HTTPStatus
from typing import Any, Dict, List, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, AuthenticationStatus, Client, ParseResponseBehavior, flatten_params
from ...models.dt_creation_types import DtCreationTypes
from ...models.error import Error
from ...models.wait_for_file_uploads_response_200 import WaitForFileUploadsResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    client: AuthenticatedClient,
    file_ids: List[str],
    creation_type: Union[Unset, None, DtCreationTypes] = UNSET,
    dt_repo_files: Union[Unset, None, str] = UNSET,
) -> Dict[str, Any]:
    url = "{}/internal/dts/wait_for_uploads".format(client.get_service_url("digital-twins"))

    headers: Dict[str, str] = client.get_headers()
    cookies: Dict[str, Any] = client.get_cookies()

    params: Dict[str, Any] = {}
    json_file_ids = file_ids

    params["file_ids"] = json_file_ids

    json_creation_type: Union[Unset, None, str] = UNSET
    if not isinstance(creation_type, Unset):
        json_creation_type = DtCreationTypes.from_val(creation_type).value if creation_type else None

    params["creation_type"] = json_creation_type

    params["dt_repo_files"] = dt_repo_files

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}
    params = flatten_params(params)

    return {
        "method": "get",
        "url": url,
        "headers": headers,
        "cookies": cookies,
        "timeout": client.get_timeout(),
        "params": params,
    }


def _parse_response(
    *, client: Client, response: httpx.Response
) -> Optional[Union[Error, WaitForFileUploadsResponse200]]:
    if response.status_code == HTTPStatus.OK:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_200 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_200 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_200 = WaitForFileUploadsResponse200.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        return response_200

    if response.status_code == HTTPStatus.BAD_REQUEST:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_400 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_400 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_400 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_400, status_code=response.status_code
            )
        return response_400

    if response.status_code == HTTPStatus.UNAUTHORIZED:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_401 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_401 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_401 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_401, status_code=response.status_code
            )
        return response_401

    if response.status_code == HTTPStatus.FORBIDDEN:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_403 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_403 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_403 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_403, status_code=response.status_code
            )
        return response_403

    if response.status_code == HTTPStatus.NOT_FOUND:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_404 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_404 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_404 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_404, status_code=response.status_code
            )
        return response_404

    if response.status_code == HTTPStatus.METHOD_NOT_ALLOWED:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_405 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_405 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_405 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_405, status_code=response.status_code
            )
        return response_405

    if response.status_code == HTTPStatus.INTERNAL_SERVER_ERROR:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_500 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_500 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_500 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_500, status_code=response.status_code
            )
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(f"Unexpected status code: {response.status_code}")
    else:
        return None


def _build_response(
    *, client: Client, response: httpx.Response
) -> Union[Response[Union[Error, WaitForFileUploadsResponse200]], httpx.Response]:
    if client.parse_response_behavior == ParseResponseBehavior.RAW_RESPONSE:
        return response

    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    file_ids: List[str],
    creation_type: Union[Unset, None, DtCreationTypes] = UNSET,
    dt_repo_files: Union[Unset, None, str] = UNSET,
) -> Union[Response[Union[Error, WaitForFileUploadsResponse200]], httpx.Response]:
    """Wait for file uploads complete

     Wait for file uploads to complete

    Args:
        file_ids (List[str]): Each entry in the list is a unique identifier for an uploaded file.
            This value should match the identifier used for the file upload, either the
            "resumableIdentifier" value used for "Upload a resumable file", or the "file_id" value
            used for "Upload file from URL".
        creation_type (Union[Unset, None, DtCreationTypes]): The creation type of the digital twin
            version.  For "create_from_firmware" you can specify multiple files via the "urls",
            "files", "file_ids" or "resumable_identifiers" parameters.  For "create_manually" you
            should not specify any files and for all other creation types you should specify exactly
            one file.  You can use "import_from_sbom_file" to create a DT version from either a
            CycloneDX, SPDX or "CPE CVEs" list.  You can use "import_based_on_file_classification" to
            create a DT version from either a single binary/firmware file or from an SBOM format file
            (CycloneDX, SPDX or "CPE CVEs" list). You can use "create_from_source_code" you can
            specify multiple source code sources via the "urls", "files", "file_ids" or
            "resumable_identifiers" parameters.
        dt_repo_files (Union[Unset, None, str]): A directory to move the file(s) to

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, WaitForFileUploadsResponse200]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
        file_ids=file_ids,
        creation_type=creation_type,
        dt_repo_files=dt_repo_files,
    )

    with httpx.Client(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = _client.request(**kwargs)

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    file_ids: List[str],
    creation_type: Union[Unset, None, DtCreationTypes] = UNSET,
    dt_repo_files: Union[Unset, None, str] = UNSET,
) -> Optional[Union[Error, WaitForFileUploadsResponse200]]:
    """Wait for file uploads complete

     Wait for file uploads to complete

    Args:
        file_ids (List[str]): Each entry in the list is a unique identifier for an uploaded file.
            This value should match the identifier used for the file upload, either the
            "resumableIdentifier" value used for "Upload a resumable file", or the "file_id" value
            used for "Upload file from URL".
        creation_type (Union[Unset, None, DtCreationTypes]): The creation type of the digital twin
            version.  For "create_from_firmware" you can specify multiple files via the "urls",
            "files", "file_ids" or "resumable_identifiers" parameters.  For "create_manually" you
            should not specify any files and for all other creation types you should specify exactly
            one file.  You can use "import_from_sbom_file" to create a DT version from either a
            CycloneDX, SPDX or "CPE CVEs" list.  You can use "import_based_on_file_classification" to
            create a DT version from either a single binary/firmware file or from an SBOM format file
            (CycloneDX, SPDX or "CPE CVEs" list). You can use "create_from_source_code" you can
            specify multiple source code sources via the "urls", "files", "file_ids" or
            "resumable_identifiers" parameters.
        dt_repo_files (Union[Unset, None, str]): A directory to move the file(s) to

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, WaitForFileUploadsResponse200]]
    """

    return sync_detailed(
        client=client,
        file_ids=file_ids,
        creation_type=creation_type,
        dt_repo_files=dt_repo_files,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    file_ids: List[str],
    creation_type: Union[Unset, None, DtCreationTypes] = UNSET,
    dt_repo_files: Union[Unset, None, str] = UNSET,
) -> Union[Response[Union[Error, WaitForFileUploadsResponse200]], httpx.Response]:
    """Wait for file uploads complete

     Wait for file uploads to complete

    Args:
        file_ids (List[str]): Each entry in the list is a unique identifier for an uploaded file.
            This value should match the identifier used for the file upload, either the
            "resumableIdentifier" value used for "Upload a resumable file", or the "file_id" value
            used for "Upload file from URL".
        creation_type (Union[Unset, None, DtCreationTypes]): The creation type of the digital twin
            version.  For "create_from_firmware" you can specify multiple files via the "urls",
            "files", "file_ids" or "resumable_identifiers" parameters.  For "create_manually" you
            should not specify any files and for all other creation types you should specify exactly
            one file.  You can use "import_from_sbom_file" to create a DT version from either a
            CycloneDX, SPDX or "CPE CVEs" list.  You can use "import_based_on_file_classification" to
            create a DT version from either a single binary/firmware file or from an SBOM format file
            (CycloneDX, SPDX or "CPE CVEs" list). You can use "create_from_source_code" you can
            specify multiple source code sources via the "urls", "files", "file_ids" or
            "resumable_identifiers" parameters.
        dt_repo_files (Union[Unset, None, str]): A directory to move the file(s) to

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, WaitForFileUploadsResponse200]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
        file_ids=file_ids,
        creation_type=creation_type,
        dt_repo_files=dt_repo_files,
    )

    async with httpx.AsyncClient(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = await _client.request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    file_ids: List[str],
    creation_type: Union[Unset, None, DtCreationTypes] = UNSET,
    dt_repo_files: Union[Unset, None, str] = UNSET,
) -> Optional[Union[Error, WaitForFileUploadsResponse200]]:
    """Wait for file uploads complete

     Wait for file uploads to complete

    Args:
        file_ids (List[str]): Each entry in the list is a unique identifier for an uploaded file.
            This value should match the identifier used for the file upload, either the
            "resumableIdentifier" value used for "Upload a resumable file", or the "file_id" value
            used for "Upload file from URL".
        creation_type (Union[Unset, None, DtCreationTypes]): The creation type of the digital twin
            version.  For "create_from_firmware" you can specify multiple files via the "urls",
            "files", "file_ids" or "resumable_identifiers" parameters.  For "create_manually" you
            should not specify any files and for all other creation types you should specify exactly
            one file.  You can use "import_from_sbom_file" to create a DT version from either a
            CycloneDX, SPDX or "CPE CVEs" list.  You can use "import_based_on_file_classification" to
            create a DT version from either a single binary/firmware file or from an SBOM format file
            (CycloneDX, SPDX or "CPE CVEs" list). You can use "create_from_source_code" you can
            specify multiple source code sources via the "urls", "files", "file_ids" or
            "resumable_identifiers" parameters.
        dt_repo_files (Union[Unset, None, str]): A directory to move the file(s) to

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, WaitForFileUploadsResponse200]]
    """

    return (
        await asyncio_detailed(
            client=client,
            file_ids=file_ids,
            creation_type=creation_type,
            dt_repo_files=dt_repo_files,
        )
    ).parsed
