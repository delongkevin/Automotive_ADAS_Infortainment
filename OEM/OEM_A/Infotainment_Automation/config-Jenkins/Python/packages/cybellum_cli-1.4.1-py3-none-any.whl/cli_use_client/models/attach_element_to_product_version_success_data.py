from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.product_version_information import ProductVersionInformation


T = TypeVar("T", bound="AttachElementToProductVersionSuccessData")


@attr.s(auto_attribs=True)
class AttachElementToProductVersionSuccessData:
    """
    Attributes:
        product_information (Union[Unset, ProductVersionInformation]): Product version information
    """

    product_information: Union[Unset, "ProductVersionInformation"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        product_information: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.product_information, Unset):
            product_information = self.product_information.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if product_information is not UNSET:
            field_dict["product_information"] = product_information

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.product_version_information import ProductVersionInformation

        d = src_dict.copy()
        _product_information = d.pop("product_information", UNSET)
        product_information: Union[Unset, ProductVersionInformation]
        if isinstance(_product_information, Unset):
            product_information = UNSET
        else:
            product_information = ProductVersionInformation.from_dict(_product_information)

        attach_element_to_product_version_success_data = cls(
            product_information=product_information,
        )

        attach_element_to_product_version_success_data.additional_properties = d
        return attach_element_to_product_version_success_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
