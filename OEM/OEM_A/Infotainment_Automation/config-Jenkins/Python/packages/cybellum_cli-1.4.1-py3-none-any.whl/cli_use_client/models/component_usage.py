from enum import Enum
from typing import Union


class ComponentUsage(str, Enum):
    SOURCE_CODE = "source_code"

    STATIC = "static"

    DYNAMIC = "dynamic"

    SEPARATE_WORK = "separate_work"

    NOT_PART_OF_PRODUCT = "not_part_of_product"

    UNKNOWN = "unknown"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "ComponentUsage"]) -> "ComponentUsage":
        if isinstance(value, ComponentUsage):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return ComponentUsage(value)
