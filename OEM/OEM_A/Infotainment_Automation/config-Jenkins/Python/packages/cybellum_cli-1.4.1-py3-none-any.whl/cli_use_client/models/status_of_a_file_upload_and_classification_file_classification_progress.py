from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.status_of_a_file_upload_and_classification_file_classification_progress_classification_progress import (
        StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgress,
    )
    from ..models.status_of_a_file_upload_and_classification_file_classification_progress_upload_progress import (
        StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgress,
    )


T = TypeVar("T", bound="StatusOfAFileUploadAndClassificationFileClassificationProgress")


@attr.s(auto_attribs=True)
class StatusOfAFileUploadAndClassificationFileClassificationProgress:
    """
    Attributes:
        classification_progress (Union[Unset,
            StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgress]): The status (and
            eventually result) of the file classification
        upload_progress (Union[Unset, StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgress]):
            The status (and eventually result) of the file upload
    """

    classification_progress: Union[
        Unset, "StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgress"
    ] = UNSET
    upload_progress: Union[Unset, "StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgress"] = (
        UNSET
    )
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        classification_progress: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.classification_progress, Unset):
            classification_progress = self.classification_progress.to_dict()

        upload_progress: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.upload_progress, Unset):
            upload_progress = self.upload_progress.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if classification_progress is not UNSET:
            field_dict["classification_progress"] = classification_progress
        if upload_progress is not UNSET:
            field_dict["upload_progress"] = upload_progress

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.status_of_a_file_upload_and_classification_file_classification_progress_classification_progress import (
            StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgress,
        )
        from ..models.status_of_a_file_upload_and_classification_file_classification_progress_upload_progress import (
            StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgress,
        )

        d = src_dict.copy()
        _classification_progress = d.pop("classification_progress", UNSET)
        classification_progress: Union[
            Unset, StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgress
        ]
        if isinstance(_classification_progress, Unset):
            classification_progress = UNSET
        else:
            classification_progress = (
                StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgress.from_dict(
                    _classification_progress
                )
            )

        _upload_progress = d.pop("upload_progress", UNSET)
        upload_progress: Union[Unset, StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgress]
        if isinstance(_upload_progress, Unset):
            upload_progress = UNSET
        else:
            upload_progress = StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgress.from_dict(
                _upload_progress
            )

        status_of_a_file_upload_and_classification_file_classification_progress = cls(
            classification_progress=classification_progress,
            upload_progress=upload_progress,
        )

        status_of_a_file_upload_and_classification_file_classification_progress.additional_properties = d
        return status_of_a_file_upload_and_classification_file_classification_progress

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
