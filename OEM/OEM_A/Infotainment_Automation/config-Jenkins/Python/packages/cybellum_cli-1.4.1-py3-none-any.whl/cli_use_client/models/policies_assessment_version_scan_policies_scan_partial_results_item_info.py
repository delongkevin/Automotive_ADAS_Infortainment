from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfo")


@attr.s(auto_attribs=True)
class PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfo:
    """Information payload

    Attributes:
        requirement_id (Union[Unset, str]): ID
        signature (Union[Unset, str]): Signature
    """

    requirement_id: Union[Unset, str] = UNSET
    signature: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        requirement_id = self.requirement_id
        signature = self.signature

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if requirement_id is not UNSET:
            field_dict["requirement_id"] = requirement_id
        if signature is not UNSET:
            field_dict["signature"] = signature

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        requirement_id = d.pop("requirement_id", UNSET)

        signature = d.pop("signature", UNSET)

        policies_assessment_version_scan_policies_scan_partial_results_item_info = cls(
            requirement_id=requirement_id,
            signature=signature,
        )

        policies_assessment_version_scan_policies_scan_partial_results_item_info.additional_properties = d
        return policies_assessment_version_scan_policies_scan_partial_results_item_info

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
