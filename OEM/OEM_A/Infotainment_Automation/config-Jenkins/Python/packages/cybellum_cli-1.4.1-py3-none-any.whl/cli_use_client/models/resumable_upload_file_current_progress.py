from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="ResumableUploadFileCurrentProgress")


@attr.s(auto_attribs=True)
class ResumableUploadFileCurrentProgress:
    """Resumable upload file current progress

    Attributes:
        completed (Union[Unset, float]): Progress completed
        label (Union[Unset, str]): Progress label
        percentage (Union[Unset, float]): Progress percentage completed
        total (Union[Unset, float]): Progress total
        units (Union[Unset, str]): Progress units
    """

    completed: Union[Unset, float] = UNSET
    label: Union[Unset, str] = UNSET
    percentage: Union[Unset, float] = UNSET
    total: Union[Unset, float] = UNSET
    units: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        completed = self.completed
        label = self.label
        percentage = self.percentage
        total = self.total
        units = self.units

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if completed is not UNSET:
            field_dict["completed"] = completed
        if label is not UNSET:
            field_dict["label"] = label
        if percentage is not UNSET:
            field_dict["percentage"] = percentage
        if total is not UNSET:
            field_dict["total"] = total
        if units is not UNSET:
            field_dict["units"] = units

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        completed = d.pop("completed", UNSET)

        label = d.pop("label", UNSET)

        percentage = d.pop("percentage", UNSET)

        total = d.pop("total", UNSET)

        units = d.pop("units", UNSET)

        resumable_upload_file_current_progress = cls(
            completed=completed,
            label=label,
            percentage=percentage,
            total=total,
            units=units,
        )

        resumable_upload_file_current_progress.additional_properties = d
        return resumable_upload_file_current_progress

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
