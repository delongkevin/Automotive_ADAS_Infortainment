from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.package_version_information import PackageVersionInformation


T = TypeVar("T", bound="SBOMPackageReference")


@attr.s(auto_attribs=True)
class SBOMPackageReference:
    """SBOM package reference

    Attributes:
        id (str): ID
        name (str): SBOM package name
        dt_id (Union[Unset, str]): ID
        dt_name (Union[Unset, str]): Name of the component that owns SBOM
        dt_version (Union[Unset, str]): Version of the component that owns SBOM
        dt_version_id (Union[Unset, str]): ID
        package_id (Union[Unset, str]): Id of the mapped package
        version (Union[Unset, PackageVersionInformation]): Pacakge version information
    """

    id: str
    name: str
    dt_id: Union[Unset, str] = UNSET
    dt_name: Union[Unset, str] = UNSET
    dt_version: Union[Unset, str] = UNSET
    dt_version_id: Union[Unset, str] = UNSET
    package_id: Union[Unset, str] = UNSET
    version: Union[Unset, "PackageVersionInformation"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        id = self.id
        name = self.name
        dt_id = self.dt_id
        dt_name = self.dt_name
        dt_version = self.dt_version
        dt_version_id = self.dt_version_id
        package_id = self.package_id
        version: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.version, Unset):
            version = self.version.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
            }
        )
        if dt_id is not UNSET:
            field_dict["dt_id"] = dt_id
        if dt_name is not UNSET:
            field_dict["dt_name"] = dt_name
        if dt_version is not UNSET:
            field_dict["dt_version"] = dt_version
        if dt_version_id is not UNSET:
            field_dict["dt_version_id"] = dt_version_id
        if package_id is not UNSET:
            field_dict["package_id"] = package_id
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.package_version_information import PackageVersionInformation

        d = src_dict.copy()
        id = d.pop("id")

        name = d.pop("name")

        dt_id = d.pop("dt_id", UNSET)

        dt_name = d.pop("dt_name", UNSET)

        dt_version = d.pop("dt_version", UNSET)

        dt_version_id = d.pop("dt_version_id", UNSET)

        package_id = d.pop("package_id", UNSET)

        _version = d.pop("version", UNSET)
        version: Union[Unset, PackageVersionInformation]
        if isinstance(_version, Unset):
            version = UNSET
        else:
            version = PackageVersionInformation.from_dict(_version)

        sbom_package_reference = cls(
            id=id,
            name=name,
            dt_id=dt_id,
            dt_name=dt_name,
            dt_version=dt_version,
            dt_version_id=dt_version_id,
            package_id=package_id,
            version=version,
        )

        sbom_package_reference.additional_properties = d
        return sbom_package_reference

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
