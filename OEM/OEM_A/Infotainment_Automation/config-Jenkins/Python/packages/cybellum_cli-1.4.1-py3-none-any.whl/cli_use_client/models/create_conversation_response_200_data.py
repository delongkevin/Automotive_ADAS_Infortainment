from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateConversationResponse200Data")


@attr.s(auto_attribs=True)
class CreateConversationResponse200Data:
    """
    Attributes:
        conversation_id (Union[Unset, str]): ID
        introduction_message (Union[Unset, str]): Initial message from the AI assistant
    """

    conversation_id: Union[Unset, str] = UNSET
    introduction_message: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        conversation_id = self.conversation_id
        introduction_message = self.introduction_message

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if conversation_id is not UNSET:
            field_dict["conversation_id"] = conversation_id
        if introduction_message is not UNSET:
            field_dict["introduction_message"] = introduction_message

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        conversation_id = d.pop("conversation_id", UNSET)

        introduction_message = d.pop("introduction_message", UNSET)

        create_conversation_response_200_data = cls(
            conversation_id=conversation_id,
            introduction_message=introduction_message,
        )

        create_conversation_response_200_data.additional_properties = d
        return create_conversation_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
