from enum import Enum
from typing import Union


class FieldCustomValueSource(str, Enum):
    SYSTEM = "system"

    USER = "user"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "FieldCustomValueSource"]) -> "FieldCustomValueSource":
        if isinstance(value, FieldCustomValueSource):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return FieldCustomValueSource(value)
