from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScorePackageInformation")


@attr.s(auto_attribs=True)
class StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScorePackageInformation:
    """
    Attributes:
        name (Union[Unset, str]): "passed" or "failed"
        supplier (Union[Unset, str]): "passed" or "failed"
        unique_identifier (Union[Unset, str]): "passed" or "failed"
        version (Union[Unset, str]): "passed" or "failed"
    """

    name: Union[Unset, str] = UNSET
    supplier: Union[Unset, str] = UNSET
    unique_identifier: Union[Unset, str] = UNSET
    version: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        name = self.name
        supplier = self.supplier
        unique_identifier = self.unique_identifier
        version = self.version

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if supplier is not UNSET:
            field_dict["supplier"] = supplier
        if unique_identifier is not UNSET:
            field_dict["unique_identifier"] = unique_identifier
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        name = d.pop("name", UNSET)

        supplier = d.pop("supplier", UNSET)

        unique_identifier = d.pop("unique_identifier", UNSET)

        version = d.pop("version", UNSET)

        status_of_an_sbom_document_analysis_document_analysis_result_score_package_information = cls(
            name=name,
            supplier=supplier,
            unique_identifier=unique_identifier,
            version=version,
        )

        status_of_an_sbom_document_analysis_document_analysis_result_score_package_information.additional_properties = d
        return status_of_an_sbom_document_analysis_document_analysis_result_score_package_information

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
