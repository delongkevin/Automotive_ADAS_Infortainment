from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="GetVulnerabilitiesDatabaseVersionResponse200DataDbVersion")


@attr.s(auto_attribs=True)
class GetVulnerabilitiesDatabaseVersionResponse200DataDbVersion:
    """Database version

    Attributes:
        schema (Union[Unset, int]): Schema
        version (Union[Unset, str]): Version
    """

    schema: Union[Unset, int] = UNSET
    version: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        schema = self.schema
        version = self.version

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if schema is not UNSET:
            field_dict["schema"] = schema
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        schema = d.pop("schema", UNSET)

        version = d.pop("version", UNSET)

        get_vulnerabilities_database_version_response_200_data_db_version = cls(
            schema=schema,
            version=version,
        )

        get_vulnerabilities_database_version_response_200_data_db_version.additional_properties = d
        return get_vulnerabilities_database_version_response_200_data_db_version

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
