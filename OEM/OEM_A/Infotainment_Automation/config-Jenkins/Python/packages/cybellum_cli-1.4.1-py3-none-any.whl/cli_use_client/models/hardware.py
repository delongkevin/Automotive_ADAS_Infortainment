from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin_architecture import DigitalTwinArchitecture


T = TypeVar("T", bound="Hardware")


@attr.s(auto_attribs=True)
class Hardware:
    """digital twin hardware

    Attributes:
        architectures (Union[Unset, List['DigitalTwinArchitecture']]): digital twin architectures
        ram (Union[Unset, str]): system ram
        video (Union[Unset, str]): video information
    """

    architectures: Union[Unset, List["DigitalTwinArchitecture"]] = UNSET
    ram: Union[Unset, str] = UNSET
    video: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        architectures: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.architectures, Unset):
            architectures = []
            for architectures_item_data in self.architectures:
                architectures_item = architectures_item_data.to_dict()

                architectures.append(architectures_item)

        ram = self.ram
        video = self.video

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if architectures is not UNSET:
            field_dict["architectures"] = architectures
        if ram is not UNSET:
            field_dict["ram"] = ram
        if video is not UNSET:
            field_dict["video"] = video

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin_architecture import DigitalTwinArchitecture

        d = src_dict.copy()
        _architectures = d.pop("architectures", UNSET)
        if (_architectures) is UNSET:
            architectures = UNSET
        else:
            if _architectures:
                architectures = []
                for architectures_item_data in _architectures:
                    architectures_item = DigitalTwinArchitecture.from_dict(architectures_item_data)

                    architectures.append(architectures_item)
            else:
                architectures = []

        ram = d.pop("ram", UNSET)

        video = d.pop("video", UNSET)

        hardware = cls(
            architectures=architectures,
            ram=ram,
            video=video,
        )

        hardware.additional_properties = d
        return hardware

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
