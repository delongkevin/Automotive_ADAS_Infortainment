from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..models.policy_configuration_source import PolicyConfigurationSource
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.global_requirement_dependent_assessments import GlobalRequirementDependentAssessments
    from ..models.global_requirement_handler_parameters import GlobalRequirementHandlerParameters


T = TypeVar("T", bound="GlobalRequirement")


@attr.s(auto_attribs=True)
class GlobalRequirement:
    """Global requirement

    Attributes:
        category (Union[Unset, str]): Requirement category
        configuration_source (Union[Unset, PolicyConfigurationSource]): Policy configuration source
        dependent_assessments (Union[Unset, GlobalRequirementDependentAssessments]): Dependent assessments information
        description (Union[Unset, str]): Requirement description
        group (Union[Unset, str]): Requirement group
        handler_parameters (Union[Unset, GlobalRequirementHandlerParameters]): Handler parameter JSON object
        handler_type (Union[Unset, str]): Handler type
        hierarchy (Union[Unset, List[str]]): Requirement hierarchy
        id (Union[Unset, str]): Requirement id
        logical_validation (Union[Unset, str]): Requirement condition
        name (Union[Unset, str]): Requirement technical name
        severity (Union[Unset, str]): Requirement severity
        sub_category (Union[Unset, str]): Requirement sub-category
    """

    category: Union[Unset, str] = UNSET
    configuration_source: Union[Unset, PolicyConfigurationSource] = UNSET
    dependent_assessments: Union[Unset, "GlobalRequirementDependentAssessments"] = UNSET
    description: Union[Unset, str] = UNSET
    group: Union[Unset, str] = UNSET
    handler_parameters: Union[Unset, "GlobalRequirementHandlerParameters"] = UNSET
    handler_type: Union[Unset, str] = UNSET
    hierarchy: Union[Unset, List[str]] = UNSET
    id: Union[Unset, str] = UNSET
    logical_validation: Union[Unset, str] = UNSET
    name: Union[Unset, str] = UNSET
    severity: Union[Unset, str] = UNSET
    sub_category: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        category = self.category
        configuration_source: Union[Unset, str] = UNSET
        if not isinstance(self.configuration_source, Unset):
            configuration_source = PolicyConfigurationSource.from_val(self.configuration_source).value

        dependent_assessments: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.dependent_assessments, Unset):
            dependent_assessments = self.dependent_assessments.to_dict()

        description = self.description
        group = self.group
        handler_parameters: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.handler_parameters, Unset):
            handler_parameters = self.handler_parameters.to_dict()

        handler_type = self.handler_type
        hierarchy: Union[Unset, List[str]] = UNSET
        if not isinstance(self.hierarchy, Unset):
            hierarchy = self.hierarchy

        id = self.id
        logical_validation = self.logical_validation
        name = self.name
        severity = self.severity
        sub_category = self.sub_category

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if category is not UNSET:
            field_dict["category"] = category
        if configuration_source is not UNSET:
            field_dict["configuration_source"] = configuration_source
        if dependent_assessments is not UNSET:
            field_dict["dependent_assessments"] = dependent_assessments
        if description is not UNSET:
            field_dict["description"] = description
        if group is not UNSET:
            field_dict["group"] = group
        if handler_parameters is not UNSET:
            field_dict["handler_parameters"] = handler_parameters
        if handler_type is not UNSET:
            field_dict["handler_type"] = handler_type
        if hierarchy is not UNSET:
            field_dict["hierarchy"] = hierarchy
        if id is not UNSET:
            field_dict["id"] = id
        if logical_validation is not UNSET:
            field_dict["logical_validation"] = logical_validation
        if name is not UNSET:
            field_dict["name"] = name
        if severity is not UNSET:
            field_dict["severity"] = severity
        if sub_category is not UNSET:
            field_dict["sub_category"] = sub_category

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.global_requirement_dependent_assessments import GlobalRequirementDependentAssessments
        from ..models.global_requirement_handler_parameters import GlobalRequirementHandlerParameters

        d = src_dict.copy()
        category = d.pop("category", UNSET)

        _configuration_source = d.pop("configuration_source", UNSET)
        configuration_source: Union[Unset, PolicyConfigurationSource]
        if isinstance(_configuration_source, Unset):
            configuration_source = UNSET
        else:
            configuration_source = PolicyConfigurationSource.from_val(_configuration_source)

        _dependent_assessments = d.pop("dependent_assessments", UNSET)
        dependent_assessments: Union[Unset, GlobalRequirementDependentAssessments]
        if isinstance(_dependent_assessments, Unset):
            dependent_assessments = UNSET
        else:
            dependent_assessments = GlobalRequirementDependentAssessments.from_dict(_dependent_assessments)

        description = d.pop("description", UNSET)

        group = d.pop("group", UNSET)

        _handler_parameters = d.pop("handler_parameters", UNSET)
        handler_parameters: Union[Unset, GlobalRequirementHandlerParameters]
        if isinstance(_handler_parameters, Unset):
            handler_parameters = UNSET
        else:
            handler_parameters = GlobalRequirementHandlerParameters.from_dict(_handler_parameters)

        handler_type = d.pop("handler_type", UNSET)

        hierarchy = cast(List[str], d.pop("hierarchy", UNSET))

        id = d.pop("id", UNSET)

        logical_validation = d.pop("logical_validation", UNSET)

        name = d.pop("name", UNSET)

        severity = d.pop("severity", UNSET)

        sub_category = d.pop("sub_category", UNSET)

        global_requirement = cls(
            category=category,
            configuration_source=configuration_source,
            dependent_assessments=dependent_assessments,
            description=description,
            group=group,
            handler_parameters=handler_parameters,
            handler_type=handler_type,
            hierarchy=hierarchy,
            id=id,
            logical_validation=logical_validation,
            name=name,
            severity=severity,
            sub_category=sub_category,
        )

        global_requirement.additional_properties = d
        return global_requirement

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
