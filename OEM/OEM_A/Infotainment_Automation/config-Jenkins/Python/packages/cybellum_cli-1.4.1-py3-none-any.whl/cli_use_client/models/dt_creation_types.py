from enum import Enum
from typing import Union


class DtCreationTypes(str, Enum):
    IMPORT_FROM_CPES_LIST = "import_from_cpes_list"

    CREATE_FROM_FIRMWARE = "create_from_firmware"

    CREATE_MANUALLY = "create_manually"

    IMPORT_FROM_CYCLONEDX = "import_from_cyclonedx"

    IMPORT_FROM_SPDX = "import_from_spdx"

    IMPORT_FROM_SBOM_FILE = "import_from_sbom_file"

    IMPORT_BASED_ON_FILE_CLASSIFICATION = "import_based_on_file_classification"

    CREATE_FROM_SOURCE_CODE = "create_from_source_code"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "DtCreationTypes"]) -> "DtCreationTypes":
        if isinstance(value, DtCreationTypes):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return DtCreationTypes(value)
