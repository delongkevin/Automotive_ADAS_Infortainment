from typing import Any, Dict, List, Type, TypeVar, cast

import attr

T = TypeVar("T", bound="RoleDependencies")


@attr.s(auto_attribs=True)
class RoleDependencies:
    """Role Dependencies

    Attributes:
        dependent_product_roles (List[str]):
        users_num (int):
    """

    dependent_product_roles: List[str]
    users_num: int
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        dependent_product_roles = self.dependent_product_roles

        users_num = self.users_num

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "dependent_product_roles": dependent_product_roles,
                "users_num": users_num,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        dependent_product_roles = cast(List[str], d.pop("dependent_product_roles"))

        users_num = d.pop("users_num")

        role_dependencies = cls(
            dependent_product_roles=dependent_product_roles,
            users_num=users_num,
        )

        role_dependencies.additional_properties = d
        return role_dependencies

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
