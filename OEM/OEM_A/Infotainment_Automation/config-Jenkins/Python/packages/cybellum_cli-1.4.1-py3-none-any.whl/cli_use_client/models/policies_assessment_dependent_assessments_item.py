from typing import Any, Dict, List, Type, TypeVar

import attr

from ..models.assessment_type import AssessmentType

T = TypeVar("T", bound="PoliciesAssessmentDependentAssessmentsItem")


@attr.s(auto_attribs=True)
class PoliciesAssessmentDependentAssessmentsItem:
    """
    Attributes:
        assessment_id (str): ID
        assessment_type (AssessmentType): Assessment type
    """

    assessment_id: str
    assessment_type: AssessmentType
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        assessment_id = self.assessment_id
        assessment_type = AssessmentType.from_val(self.assessment_type).value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "assessment_id": assessment_id,
                "assessment_type": assessment_type,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        assessment_id = d.pop("assessment_id")

        assessment_type = AssessmentType.from_val(d.pop("assessment_type"))

        policies_assessment_dependent_assessments_item = cls(
            assessment_id=assessment_id,
            assessment_type=assessment_type,
        )

        policies_assessment_dependent_assessments_item.additional_properties = d
        return policies_assessment_dependent_assessments_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
