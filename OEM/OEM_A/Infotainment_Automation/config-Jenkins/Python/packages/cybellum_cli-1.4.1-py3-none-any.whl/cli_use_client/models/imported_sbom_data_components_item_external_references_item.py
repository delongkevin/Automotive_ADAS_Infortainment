from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="ImportedSBOMDataComponentsItemExternalReferencesItem")


@attr.s(auto_attribs=True)
class ImportedSBOMDataComponentsItemExternalReferencesItem:
    """
    Attributes:
        type (str): Allowed values: "VCS", "ISSUE-TRACKER", "WEBSITE", "ADVISORIES", "BOM", "MAILING-LIST", "SOCIAL",
            "CHAT", "DOCUMENTATION", "SUPPORT", "DISTRIBUTION", "DISTRIBUTION-INTAKE", "LICENSE", "BUILD-META", "BUILD-
            SYSTEM", "RELEASE-NOTES", "SECURITY-CONTACT", "MODEL-CARD", "LOG", "CONFIGURATION", "EVIDENCE", "FORMULATION",
            "ATTESTATION", "THREAT-MODEL", "ADVERSARY-MODEL", "RISK-ASSESSMENT", "VULNERABILITY-ASSERTION", "EXPLOITABILITY-
            STATEMENT", "PENTEST-REPORT", "STATIC-ANALYSIS-REPORT", "DYNAMIC-ANALYSIS-REPORT", "RUNTIME-ANALYSIS-REPORT",
            "COMPONENT-ANALYSIS-REPORT", "MATURITY-REPORT", "CERTIFICATION-REPORT", "CODIFIED-INFRASTRUCTURE", "QUALITY-
            METRICS", "POAM", "OTHER"
        uri (str):
        comment (Union[Unset, str]):
    """

    type: str
    uri: str
    comment: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        type = self.type
        uri = self.uri
        comment = self.comment

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type,
                "uri": uri,
            }
        )
        if comment is not UNSET:
            field_dict["comment"] = comment

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        type = d.pop("type")

        uri = d.pop("uri")

        comment = d.pop("comment", UNSET)

        imported_sbom_data_components_item_external_references_item = cls(
            type=type,
            uri=uri,
            comment=comment,
        )

        imported_sbom_data_components_item_external_references_item.additional_properties = d
        return imported_sbom_data_components_item_external_references_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
