import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..models.digital_twin_version_scan_state import DigitalTwinVersionScanState
from ..models.digital_twin_version_scan_sub_state import DigitalTwinVersionScanSubState
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin_version_scan_additional_info import DigitalTwinVersionScanAdditionalInfo
    from ..models.digital_twin_version_scan_partial_results_info import DigitalTwinVersionScanPartialResultsInfo


T = TypeVar("T", bound="DigitalTwinVersionScan")


@attr.s(auto_attribs=True)
class DigitalTwinVersionScan:
    """Digital twin version scan

    Attributes:
        id (str): ID
        queued_time (datetime.datetime): the time the scan was queued
        state (DigitalTwinVersionScanState): the scan state
        sub_state (DigitalTwinVersionScanSubState): the scan sub state
        worker_id (str): the internal worker id of the scan
        additional_info (Union[Unset, DigitalTwinVersionScanAdditionalInfo]): JSON-like object with additional,
            information with flexible structure
        extracted_time (Union[Unset, datetime.datetime]): the time the digital twin fiels were extracted
        extractor_worker_id (Union[Unset, str]): the extractor worker id of the scan
        finish_time (Union[Unset, datetime.datetime]): the time the digital twin scan finished
        partial_results_info (Union[Unset, DigitalTwinVersionScanPartialResultsInfo]): partial results information in
            case the scan didn't return full results
        percentage_completed (Union[Unset, float]): the completion percentage
        sbom_source_id (Union[Unset, str]): ID
        sbom_source_type (Union[Unset, str]): sbom source type  of the scan
        start_time (Union[Unset, datetime.datetime]): the time the scan was started
    """

    id: str
    queued_time: datetime.datetime
    state: DigitalTwinVersionScanState
    sub_state: DigitalTwinVersionScanSubState
    worker_id: str
    additional_info: Union[Unset, "DigitalTwinVersionScanAdditionalInfo"] = UNSET
    extracted_time: Union[Unset, datetime.datetime] = UNSET
    extractor_worker_id: Union[Unset, str] = UNSET
    finish_time: Union[Unset, datetime.datetime] = UNSET
    partial_results_info: Union[Unset, "DigitalTwinVersionScanPartialResultsInfo"] = UNSET
    percentage_completed: Union[Unset, float] = UNSET
    sbom_source_id: Union[Unset, str] = UNSET
    sbom_source_type: Union[Unset, str] = UNSET
    start_time: Union[Unset, datetime.datetime] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        id = self.id
        queued_time = self.queued_time.isoformat()

        state = DigitalTwinVersionScanState.from_val(self.state).value

        sub_state = DigitalTwinVersionScanSubState.from_val(self.sub_state).value

        worker_id = self.worker_id
        additional_info: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.additional_info, Unset):
            additional_info = self.additional_info.to_dict()

        extracted_time: Union[Unset, str] = UNSET
        if not isinstance(self.extracted_time, Unset):
            extracted_time = self.extracted_time.isoformat()

        extractor_worker_id = self.extractor_worker_id
        finish_time: Union[Unset, str] = UNSET
        if not isinstance(self.finish_time, Unset):
            finish_time = self.finish_time.isoformat()

        partial_results_info: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.partial_results_info, Unset):
            partial_results_info = self.partial_results_info.to_dict()

        percentage_completed = self.percentage_completed
        sbom_source_id = self.sbom_source_id
        sbom_source_type = self.sbom_source_type
        start_time: Union[Unset, str] = UNSET
        if not isinstance(self.start_time, Unset):
            start_time = self.start_time.isoformat()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "queued_time": queued_time,
                "state": state,
                "sub_state": sub_state,
                "worker_id": worker_id,
            }
        )
        if additional_info is not UNSET:
            field_dict["additional_info"] = additional_info
        if extracted_time is not UNSET:
            field_dict["extracted_time"] = extracted_time
        if extractor_worker_id is not UNSET:
            field_dict["extractor_worker_id"] = extractor_worker_id
        if finish_time is not UNSET:
            field_dict["finish_time"] = finish_time
        if partial_results_info is not UNSET:
            field_dict["partial_results_info"] = partial_results_info
        if percentage_completed is not UNSET:
            field_dict["percentage_completed"] = percentage_completed
        if sbom_source_id is not UNSET:
            field_dict["sbom_source_id"] = sbom_source_id
        if sbom_source_type is not UNSET:
            field_dict["sbom_source_type"] = sbom_source_type
        if start_time is not UNSET:
            field_dict["start_time"] = start_time

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin_version_scan_additional_info import DigitalTwinVersionScanAdditionalInfo
        from ..models.digital_twin_version_scan_partial_results_info import DigitalTwinVersionScanPartialResultsInfo

        d = src_dict.copy()
        id = d.pop("id")

        queued_time = isoparse(d.pop("queued_time"))

        state = DigitalTwinVersionScanState.from_val(d.pop("state"))

        sub_state = DigitalTwinVersionScanSubState.from_val(d.pop("sub_state"))

        worker_id = d.pop("worker_id")

        _additional_info = d.pop("additional_info", UNSET)
        additional_info: Union[Unset, DigitalTwinVersionScanAdditionalInfo]
        if isinstance(_additional_info, Unset):
            additional_info = UNSET
        else:
            additional_info = DigitalTwinVersionScanAdditionalInfo.from_dict(_additional_info)

        _extracted_time = d.pop("extracted_time", UNSET)
        extracted_time: Union[Unset, datetime.datetime]
        if isinstance(_extracted_time, Unset):
            extracted_time = UNSET
        else:
            extracted_time = isoparse(_extracted_time)

        extractor_worker_id = d.pop("extractor_worker_id", UNSET)

        _finish_time = d.pop("finish_time", UNSET)
        finish_time: Union[Unset, datetime.datetime]
        if isinstance(_finish_time, Unset):
            finish_time = UNSET
        else:
            finish_time = isoparse(_finish_time)

        _partial_results_info = d.pop("partial_results_info", UNSET)
        partial_results_info: Union[Unset, DigitalTwinVersionScanPartialResultsInfo]
        if isinstance(_partial_results_info, Unset):
            partial_results_info = UNSET
        else:
            partial_results_info = DigitalTwinVersionScanPartialResultsInfo.from_dict(_partial_results_info)

        percentage_completed = d.pop("percentage_completed", UNSET)

        sbom_source_id = d.pop("sbom_source_id", UNSET)

        sbom_source_type = d.pop("sbom_source_type", UNSET)

        _start_time = d.pop("start_time", UNSET)
        start_time: Union[Unset, datetime.datetime]
        if isinstance(_start_time, Unset):
            start_time = UNSET
        else:
            start_time = isoparse(_start_time)

        digital_twin_version_scan = cls(
            id=id,
            queued_time=queued_time,
            state=state,
            sub_state=sub_state,
            worker_id=worker_id,
            additional_info=additional_info,
            extracted_time=extracted_time,
            extractor_worker_id=extractor_worker_id,
            finish_time=finish_time,
            partial_results_info=partial_results_info,
            percentage_completed=percentage_completed,
            sbom_source_id=sbom_source_id,
            sbom_source_type=sbom_source_type,
            start_time=start_time,
        )

        digital_twin_version_scan.additional_properties = d
        return digital_twin_version_scan

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
