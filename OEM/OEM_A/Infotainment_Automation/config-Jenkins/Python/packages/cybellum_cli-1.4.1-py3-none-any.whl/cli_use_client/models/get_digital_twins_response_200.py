from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.get_digital_twins_response_200_data import GetDigitalTwinsResponse200Data


T = TypeVar("T", bound="GetDigitalTwinsResponse200")


@attr.s(auto_attribs=True)
class GetDigitalTwinsResponse200:
    """
    Attributes:
        data (Union[Unset, GetDigitalTwinsResponse200Data]):
        status_code (Union[Unset, float]): status_code
    """

    data: Union[Unset, "GetDigitalTwinsResponse200Data"] = UNSET
    status_code: Union[Unset, float] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        data: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.data, Unset):
            data = self.data.to_dict()

        status_code = self.status_code

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if data is not UNSET:
            field_dict["data"] = data
        if status_code is not UNSET:
            field_dict["status_code"] = status_code

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.get_digital_twins_response_200_data import GetDigitalTwinsResponse200Data

        d = src_dict.copy()
        _data = d.pop("data", UNSET)
        data: Union[Unset, GetDigitalTwinsResponse200Data]
        if isinstance(_data, Unset):
            data = UNSET
        else:
            data = GetDigitalTwinsResponse200Data.from_dict(_data)

        status_code = d.pop("status_code", UNSET)

        get_digital_twins_response_200 = cls(
            data=data,
            status_code=status_code,
        )

        get_digital_twins_response_200.additional_properties = d
        return get_digital_twins_response_200

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
