from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="GlobalRequirementDependentAssessments")


@attr.s(auto_attribs=True)
class GlobalRequirementDependentAssessments:
    """Dependent assessments information

    Attributes:
        has_dependent_assessments (Union[Unset, bool]): Indicator if the requirement has dependent assessments
    """

    has_dependent_assessments: Union[Unset, bool] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        has_dependent_assessments = self.has_dependent_assessments

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if has_dependent_assessments is not UNSET:
            field_dict["has_dependent_assessments"] = has_dependent_assessments

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        has_dependent_assessments = d.pop("has_dependent_assessments", UNSET)

        global_requirement_dependent_assessments = cls(
            has_dependent_assessments=has_dependent_assessments,
        )

        global_requirement_dependent_assessments.additional_properties = d
        return global_requirement_dependent_assessments

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
