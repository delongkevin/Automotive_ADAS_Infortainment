from enum import Enum
from typing import Union


class InputSortItemDirection(str, Enum):
    ASC = "asc"

    DESC = "desc"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "InputSortItemDirection"]) -> "InputSortItemDirection":
        if isinstance(value, InputSortItemDirection):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return InputSortItemDirection(value)
