from typing import Any, Dict, List, Type, TypeVar

import attr

T = TypeVar("T", bound="ImportedSBOMDataPrimaryComponentHashesItem")


@attr.s(auto_attribs=True)
class ImportedSBOMDataPrimaryComponentHashesItem:
    """
    Attributes:
        algorithm (str): Allowed values: "MD2", "MD4", "MD5", "MD6", "SHA-1", "SHA-224", "SHA-256", "SHA-384",
            "SHA-512", "SHA3-256", "SHA3-384", "SHA3-512", "BLAKE2b-256", "BLAKE2b-384", "BLAKE2b-512", "BLAKE3", "ADLER32"
        hash_ (str):
    """

    algorithm: str
    hash_: str
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        algorithm = self.algorithm
        hash_ = self.hash_

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "algorithm": algorithm,
                "hash": hash_,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        algorithm = d.pop("algorithm")

        hash_ = d.pop("hash")

        imported_sbom_data_primary_component_hashes_item = cls(
            algorithm=algorithm,
            hash_=hash_,
        )

        imported_sbom_data_primary_component_hashes_item.additional_properties = d
        return imported_sbom_data_primary_component_hashes_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
