from enum import Enum
from typing import Union


class AssessmentStatus(str, Enum):
    OPEN = "open"

    CLOSED = "closed"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "AssessmentStatus"]) -> "AssessmentStatus":
        if isinstance(value, AssessmentStatus):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return AssessmentStatus(value)
