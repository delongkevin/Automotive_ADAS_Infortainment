from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..models.bom_item_source_type import BOMItemSourceType
from ..models.component_usage import ComponentUsage
from ..models.package_component_types import PackageComponentTypes
from ..models.package_usage_risk import PackageUsageRisk
from ..models.sbom_package_info_confidence_level import SBOMPackageInfoConfidenceLevel
from ..models.sbom_package_info_findings_item import SBOMPackageInfoFindingsItem
from ..models.sbom_package_info_origin_type import SBOMPackageInfoOriginType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.linked_package import LinkedPackage
    from ..models.metadata import Metadata
    from ..models.package_cpe import PackageCPE
    from ..models.package_gitlog import PackageGitlog
    from ..models.package_purl import PackagePURL
    from ..models.package_version_information import PackageVersionInformation
    from ..models.sbom_package_info_decision_meta import SBOMPackageInfoDecisionMeta
    from ..models.sbom_package_info_paths_item import SBOMPackageInfoPathsItem
    from ..models.sbom_package_info_sbom_source import SBOMPackageInfoSbomSource
    from ..models.sbom_package_license import SBOMPackageLicense


T = TypeVar("T", bound="SBOMPackageInfo")


@attr.s(auto_attribs=True)
class SBOMPackageInfo:
    """SBOM package info

    Attributes:
        component_types (List[PackageComponentTypes]):
        approved (Union[Unset, bool]): Is package approved indicator
        child_packages (Union[Unset, List['LinkedPackage']]):
        component_usage (Union[Unset, ComponentUsage]): Component usage
        confidence_level (Union[Unset, SBOMPackageInfoConfidenceLevel]):
        cpes (Union[Unset, List['PackageCPE']]):
        decision_meta (Union[Unset, SBOMPackageInfoDecisionMeta]):
        description (Union[Unset, str]): Package description
        eol (Union[Unset, bool]): Indicator if the package is End of Life
        eos (Union[Unset, bool]): Indicator if package is End of Service
        findings (Union[Unset, List[SBOMPackageInfoFindingsItem]]): Package findings
        git_log (Union[Unset, PackageGitlog]): Package gitlog
        latest_version (Union[Unset, PackageVersionInformation]): Pacakge version information
        licenses (Union[Unset, List['SBOMPackageLicense']]):
        metadata (Union[Unset, Metadata]): Metadata
        num_of_items (Union[Unset, float]): BOM actual number of items
        origin_type (Union[Unset, SBOMPackageInfoOriginType]): Package origin type
        package_type (Union[Unset, str]):
        parent_package (Union[Unset, LinkedPackage]): Linked package
        paths (Union[Unset, List['SBOMPackageInfoPathsItem']]): Package paths
        purls (Union[Unset, List['PackagePURL']]):
        sbom_source (Union[Unset, SBOMPackageInfoSbomSource]): Source which was used to identify this sbom package
        sku (Union[Unset, str]): BOM SKU
        source_type (Union[Unset, BOMItemSourceType]): BOM item source type
        tags (Union[Unset, List[str]]): Package tags
        usage_risk (Union[Unset, PackageUsageRisk]): Package usage risk
        vendor (Union[Unset, str]): Package vendor
        website (Union[Unset, str]): Package website
    """

    component_types: List[PackageComponentTypes]
    approved: Union[Unset, bool] = UNSET
    child_packages: Union[Unset, List["LinkedPackage"]] = UNSET
    component_usage: Union[Unset, ComponentUsage] = UNSET
    confidence_level: Union[Unset, SBOMPackageInfoConfidenceLevel] = UNSET
    cpes: Union[Unset, List["PackageCPE"]] = UNSET
    decision_meta: Union[Unset, "SBOMPackageInfoDecisionMeta"] = UNSET
    description: Union[Unset, str] = UNSET
    eol: Union[Unset, bool] = UNSET
    eos: Union[Unset, bool] = UNSET
    findings: Union[Unset, List[SBOMPackageInfoFindingsItem]] = UNSET
    git_log: Union[Unset, "PackageGitlog"] = UNSET
    latest_version: Union[Unset, "PackageVersionInformation"] = UNSET
    licenses: Union[Unset, List["SBOMPackageLicense"]] = UNSET
    metadata: Union[Unset, "Metadata"] = UNSET
    num_of_items: Union[Unset, float] = UNSET
    origin_type: Union[Unset, SBOMPackageInfoOriginType] = UNSET
    package_type: Union[Unset, str] = UNSET
    parent_package: Union[Unset, "LinkedPackage"] = UNSET
    paths: Union[Unset, List["SBOMPackageInfoPathsItem"]] = UNSET
    purls: Union[Unset, List["PackagePURL"]] = UNSET
    sbom_source: Union[Unset, "SBOMPackageInfoSbomSource"] = UNSET
    sku: Union[Unset, str] = UNSET
    source_type: Union[Unset, BOMItemSourceType] = UNSET
    tags: Union[Unset, List[str]] = UNSET
    usage_risk: Union[Unset, PackageUsageRisk] = UNSET
    vendor: Union[Unset, str] = UNSET
    website: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        component_types = []
        for component_types_item_data in self.component_types:
            component_types_item = PackageComponentTypes.from_val(component_types_item_data).value

            component_types.append(component_types_item)

        approved = self.approved
        child_packages: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.child_packages, Unset):
            child_packages = []
            for child_packages_item_data in self.child_packages:
                child_packages_item = child_packages_item_data.to_dict()

                child_packages.append(child_packages_item)

        component_usage: Union[Unset, str] = UNSET
        if not isinstance(self.component_usage, Unset):
            component_usage = ComponentUsage.from_val(self.component_usage).value

        confidence_level: Union[Unset, str] = UNSET
        if not isinstance(self.confidence_level, Unset):
            confidence_level = SBOMPackageInfoConfidenceLevel.from_val(self.confidence_level).value

        cpes: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.cpes, Unset):
            cpes = []
            for cpes_item_data in self.cpes:
                cpes_item = cpes_item_data.to_dict()

                cpes.append(cpes_item)

        decision_meta: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.decision_meta, Unset):
            decision_meta = self.decision_meta.to_dict()

        description = self.description
        eol = self.eol
        eos = self.eos
        findings: Union[Unset, List[str]] = UNSET
        if not isinstance(self.findings, Unset):
            findings = []
            for findings_item_data in self.findings:
                findings_item = SBOMPackageInfoFindingsItem.from_val(findings_item_data).value

                findings.append(findings_item)

        git_log: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.git_log, Unset):
            git_log = self.git_log.to_dict()

        latest_version: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.latest_version, Unset):
            latest_version = self.latest_version.to_dict()

        licenses: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.licenses, Unset):
            licenses = []
            for licenses_item_data in self.licenses:
                licenses_item = licenses_item_data.to_dict()

                licenses.append(licenses_item)

        metadata: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        num_of_items = self.num_of_items
        origin_type: Union[Unset, str] = UNSET
        if not isinstance(self.origin_type, Unset):
            origin_type = SBOMPackageInfoOriginType.from_val(self.origin_type).value

        package_type = self.package_type
        parent_package: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.parent_package, Unset):
            parent_package = self.parent_package.to_dict()

        paths: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.paths, Unset):
            paths = []
            for paths_item_data in self.paths:
                paths_item = paths_item_data.to_dict()

                paths.append(paths_item)

        purls: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.purls, Unset):
            purls = []
            for purls_item_data in self.purls:
                purls_item = purls_item_data.to_dict()

                purls.append(purls_item)

        sbom_source: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.sbom_source, Unset):
            sbom_source = self.sbom_source.to_dict()

        sku = self.sku
        source_type: Union[Unset, str] = UNSET
        if not isinstance(self.source_type, Unset):
            source_type = BOMItemSourceType.from_val(self.source_type).value

        tags: Union[Unset, List[str]] = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        usage_risk: Union[Unset, str] = UNSET
        if not isinstance(self.usage_risk, Unset):
            usage_risk = PackageUsageRisk.from_val(self.usage_risk).value

        vendor = self.vendor
        website = self.website

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "component_types": component_types,
            }
        )
        if approved is not UNSET:
            field_dict["approved"] = approved
        if child_packages is not UNSET:
            field_dict["child_packages"] = child_packages
        if component_usage is not UNSET:
            field_dict["component_usage"] = component_usage
        if confidence_level is not UNSET:
            field_dict["confidence_level"] = confidence_level
        if cpes is not UNSET:
            field_dict["cpes"] = cpes
        if decision_meta is not UNSET:
            field_dict["decision_meta"] = decision_meta
        if description is not UNSET:
            field_dict["description"] = description
        if eol is not UNSET:
            field_dict["eol"] = eol
        if eos is not UNSET:
            field_dict["eos"] = eos
        if findings is not UNSET:
            field_dict["findings"] = findings
        if git_log is not UNSET:
            field_dict["git_log"] = git_log
        if latest_version is not UNSET:
            field_dict["latest_version"] = latest_version
        if licenses is not UNSET:
            field_dict["licenses"] = licenses
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if num_of_items is not UNSET:
            field_dict["num_of_items"] = num_of_items
        if origin_type is not UNSET:
            field_dict["origin_type"] = origin_type
        if package_type is not UNSET:
            field_dict["package_type"] = package_type
        if parent_package is not UNSET:
            field_dict["parent_package"] = parent_package
        if paths is not UNSET:
            field_dict["paths"] = paths
        if purls is not UNSET:
            field_dict["purls"] = purls
        if sbom_source is not UNSET:
            field_dict["sbom_source"] = sbom_source
        if sku is not UNSET:
            field_dict["sku"] = sku
        if source_type is not UNSET:
            field_dict["source_type"] = source_type
        if tags is not UNSET:
            field_dict["tags"] = tags
        if usage_risk is not UNSET:
            field_dict["usage_risk"] = usage_risk
        if vendor is not UNSET:
            field_dict["vendor"] = vendor
        if website is not UNSET:
            field_dict["website"] = website

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.linked_package import LinkedPackage
        from ..models.metadata import Metadata
        from ..models.package_cpe import PackageCPE
        from ..models.package_gitlog import PackageGitlog
        from ..models.package_purl import PackagePURL
        from ..models.package_version_information import PackageVersionInformation
        from ..models.sbom_package_info_decision_meta import SBOMPackageInfoDecisionMeta
        from ..models.sbom_package_info_paths_item import SBOMPackageInfoPathsItem
        from ..models.sbom_package_info_sbom_source import SBOMPackageInfoSbomSource
        from ..models.sbom_package_license import SBOMPackageLicense

        d = src_dict.copy()
        _component_types = d.pop("component_types")
        component_types = []
        for component_types_item_data in _component_types:
            component_types_item = PackageComponentTypes.from_val(component_types_item_data)

            component_types.append(component_types_item)

        approved = d.pop("approved", UNSET)

        _child_packages = d.pop("child_packages", UNSET)
        if (_child_packages) is UNSET:
            child_packages = UNSET
        else:
            if _child_packages:
                child_packages = []
                for child_packages_item_data in _child_packages:
                    child_packages_item = LinkedPackage.from_dict(child_packages_item_data)

                    child_packages.append(child_packages_item)
            else:
                child_packages = []

        _component_usage = d.pop("component_usage", UNSET)
        component_usage: Union[Unset, ComponentUsage]
        if isinstance(_component_usage, Unset):
            component_usage = UNSET
        else:
            component_usage = ComponentUsage.from_val(_component_usage)

        _confidence_level = d.pop("confidence_level", UNSET)
        confidence_level: Union[Unset, SBOMPackageInfoConfidenceLevel]
        if isinstance(_confidence_level, Unset):
            confidence_level = UNSET
        else:
            confidence_level = SBOMPackageInfoConfidenceLevel.from_val(_confidence_level)

        _cpes = d.pop("cpes", UNSET)
        if (_cpes) is UNSET:
            cpes = UNSET
        else:
            if _cpes:
                cpes = []
                for cpes_item_data in _cpes:
                    cpes_item = PackageCPE.from_dict(cpes_item_data)

                    cpes.append(cpes_item)
            else:
                cpes = []

        _decision_meta = d.pop("decision_meta", UNSET)
        decision_meta: Union[Unset, SBOMPackageInfoDecisionMeta]
        if isinstance(_decision_meta, Unset):
            decision_meta = UNSET
        else:
            decision_meta = SBOMPackageInfoDecisionMeta.from_dict(_decision_meta)

        description = d.pop("description", UNSET)

        eol = d.pop("eol", UNSET)

        eos = d.pop("eos", UNSET)

        _findings = d.pop("findings", UNSET)
        if (_findings) is UNSET:
            findings = UNSET
        else:
            if _findings:
                findings = []
                for findings_item_data in _findings:
                    findings_item = SBOMPackageInfoFindingsItem.from_val(findings_item_data)

                    findings.append(findings_item)
            else:
                findings = []

        _git_log = d.pop("git_log", UNSET)
        git_log: Union[Unset, PackageGitlog]
        if isinstance(_git_log, Unset):
            git_log = UNSET
        else:
            git_log = PackageGitlog.from_dict(_git_log)

        _latest_version = d.pop("latest_version", UNSET)
        latest_version: Union[Unset, PackageVersionInformation]
        if isinstance(_latest_version, Unset):
            latest_version = UNSET
        else:
            latest_version = PackageVersionInformation.from_dict(_latest_version)

        _licenses = d.pop("licenses", UNSET)
        if (_licenses) is UNSET:
            licenses = UNSET
        else:
            if _licenses:
                licenses = []
                for licenses_item_data in _licenses:
                    licenses_item = SBOMPackageLicense.from_dict(licenses_item_data)

                    licenses.append(licenses_item)
            else:
                licenses = []

        _metadata = d.pop("metadata", UNSET)
        metadata: Union[Unset, Metadata]
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = Metadata.from_dict(_metadata)

        num_of_items = d.pop("num_of_items", UNSET)

        _origin_type = d.pop("origin_type", UNSET)
        origin_type: Union[Unset, SBOMPackageInfoOriginType]
        if isinstance(_origin_type, Unset):
            origin_type = UNSET
        else:
            origin_type = SBOMPackageInfoOriginType.from_val(_origin_type)

        package_type = d.pop("package_type", UNSET)

        _parent_package = d.pop("parent_package", UNSET)
        parent_package: Union[Unset, LinkedPackage]
        if isinstance(_parent_package, Unset):
            parent_package = UNSET
        else:
            parent_package = LinkedPackage.from_dict(_parent_package)

        _paths = d.pop("paths", UNSET)
        if (_paths) is UNSET:
            paths = UNSET
        else:
            if _paths:
                paths = []
                for paths_item_data in _paths:
                    paths_item = SBOMPackageInfoPathsItem.from_dict(paths_item_data)

                    paths.append(paths_item)
            else:
                paths = []

        _purls = d.pop("purls", UNSET)
        if (_purls) is UNSET:
            purls = UNSET
        else:
            if _purls:
                purls = []
                for purls_item_data in _purls:
                    purls_item = PackagePURL.from_dict(purls_item_data)

                    purls.append(purls_item)
            else:
                purls = []

        _sbom_source = d.pop("sbom_source", UNSET)
        sbom_source: Union[Unset, SBOMPackageInfoSbomSource]
        if isinstance(_sbom_source, Unset):
            sbom_source = UNSET
        else:
            sbom_source = SBOMPackageInfoSbomSource.from_dict(_sbom_source)

        sku = d.pop("sku", UNSET)

        _source_type = d.pop("source_type", UNSET)
        source_type: Union[Unset, BOMItemSourceType]
        if isinstance(_source_type, Unset):
            source_type = UNSET
        else:
            source_type = BOMItemSourceType.from_val(_source_type)

        tags = cast(List[str], d.pop("tags", UNSET))

        _usage_risk = d.pop("usage_risk", UNSET)
        usage_risk: Union[Unset, PackageUsageRisk]
        if isinstance(_usage_risk, Unset):
            usage_risk = UNSET
        else:
            usage_risk = PackageUsageRisk.from_val(_usage_risk)

        vendor = d.pop("vendor", UNSET)

        website = d.pop("website", UNSET)

        sbom_package_info = cls(
            component_types=component_types,
            approved=approved,
            child_packages=child_packages,
            component_usage=component_usage,
            confidence_level=confidence_level,
            cpes=cpes,
            decision_meta=decision_meta,
            description=description,
            eol=eol,
            eos=eos,
            findings=findings,
            git_log=git_log,
            latest_version=latest_version,
            licenses=licenses,
            metadata=metadata,
            num_of_items=num_of_items,
            origin_type=origin_type,
            package_type=package_type,
            parent_package=parent_package,
            paths=paths,
            purls=purls,
            sbom_source=sbom_source,
            sku=sku,
            source_type=source_type,
            tags=tags,
            usage_risk=usage_risk,
            vendor=vendor,
            website=website,
        )

        sbom_package_info.additional_properties = d
        return sbom_package_info

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
