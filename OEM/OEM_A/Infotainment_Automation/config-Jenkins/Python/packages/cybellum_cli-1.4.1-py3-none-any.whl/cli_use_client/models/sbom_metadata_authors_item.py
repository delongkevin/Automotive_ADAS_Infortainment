from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.sbom_metadata_authors_item_contacts_item import SbomMetadataAuthorsItemContactsItem


T = TypeVar("T", bound="SbomMetadataAuthorsItem")


@attr.s(auto_attribs=True)
class SbomMetadataAuthorsItem:
    """
    Attributes:
        bom_ref (Union[Unset, str]):
        contacts (Union[Unset, List['SbomMetadataAuthorsItemContactsItem']]):
        name (Union[Unset, str]):
        type (Union[Unset, str]):
        urls (Union[Unset, List[str]]):
    """

    bom_ref: Union[Unset, str] = UNSET
    contacts: Union[Unset, List["SbomMetadataAuthorsItemContactsItem"]] = UNSET
    name: Union[Unset, str] = UNSET
    type: Union[Unset, str] = UNSET
    urls: Union[Unset, List[str]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        bom_ref = self.bom_ref
        contacts: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.contacts, Unset):
            contacts = []
            for contacts_item_data in self.contacts:
                contacts_item = contacts_item_data.to_dict()

                contacts.append(contacts_item)

        name = self.name
        type = self.type
        urls: Union[Unset, List[str]] = UNSET
        if not isinstance(self.urls, Unset):
            urls = self.urls

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if bom_ref is not UNSET:
            field_dict["bom_ref"] = bom_ref
        if contacts is not UNSET:
            field_dict["contacts"] = contacts
        if name is not UNSET:
            field_dict["name"] = name
        if type is not UNSET:
            field_dict["type"] = type
        if urls is not UNSET:
            field_dict["urls"] = urls

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.sbom_metadata_authors_item_contacts_item import SbomMetadataAuthorsItemContactsItem

        d = src_dict.copy()
        bom_ref = d.pop("bom_ref", UNSET)

        _contacts = d.pop("contacts", UNSET)
        if (_contacts) is UNSET:
            contacts = UNSET
        else:
            if _contacts:
                contacts = []
                for contacts_item_data in _contacts:
                    contacts_item = SbomMetadataAuthorsItemContactsItem.from_dict(contacts_item_data)

                    contacts.append(contacts_item)
            else:
                contacts = []

        name = d.pop("name", UNSET)

        type = d.pop("type", UNSET)

        urls = cast(List[str], d.pop("urls", UNSET))

        sbom_metadata_authors_item = cls(
            bom_ref=bom_ref,
            contacts=contacts,
            name=name,
            type=type,
            urls=urls,
        )

        sbom_metadata_authors_item.additional_properties = d
        return sbom_metadata_authors_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
