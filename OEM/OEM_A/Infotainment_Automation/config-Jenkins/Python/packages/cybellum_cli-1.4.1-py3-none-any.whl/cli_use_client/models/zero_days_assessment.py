import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..models.assessment_status import AssessmentStatus
from ..models.dt_user_permissions_item import DtUserPermissionsItem
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin import DigitalTwin
    from ..models.zero_days_assessment_version import ZeroDaysAssessmentVersion


T = TypeVar("T", bound="ZeroDaysAssessment")


@attr.s(auto_attribs=True)
class ZeroDaysAssessment:
    """Zero days assessment

    Attributes:
        created_by (str): Assessment creator user id
        created_on (datetime.datetime): Assessment creation date
        dt_id (str): ID
        id (str): ID
        last_modified_on (str): Last time assessment was modified
        name (str): Assessment name
        default_assessment_version (Union[Unset, None, ZeroDaysAssessmentVersion]): Zero days assessment version
        description (Union[Unset, str]): Assessment description
        dt (Union[Unset, DigitalTwin]): Digital twin
        dt_version_assessment_version (Optional[ZeroDaysAssessmentVersion]): Zero days assessment version
        end_date (Union[Unset, datetime.datetime]): Assessment end date
        start_date (Union[Unset, datetime.datetime]): Assessment start date
        status (Union[Unset, AssessmentStatus]): Status of the assessment
        status_reason (Union[Unset, str]): Status reason of the assessment
        user_dt_permissions (Union[Unset, List[DtUserPermissionsItem]]): Digital twin permissions Example: ['dt_work'].
    """

    created_by: str
    created_on: datetime.datetime
    dt_id: str
    id: str
    last_modified_on: str
    name: str
    dt_version_assessment_version: Optional["ZeroDaysAssessmentVersion"]
    default_assessment_version: Union[Unset, None, "ZeroDaysAssessmentVersion"] = UNSET
    description: Union[Unset, str] = UNSET
    dt: Union[Unset, "DigitalTwin"] = UNSET
    end_date: Union[Unset, datetime.datetime] = UNSET
    start_date: Union[Unset, datetime.datetime] = UNSET
    status: Union[Unset, AssessmentStatus] = UNSET
    status_reason: Union[Unset, str] = UNSET
    user_dt_permissions: Union[Unset, List[DtUserPermissionsItem]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        created_by = self.created_by
        created_on = self.created_on.isoformat()

        dt_id = self.dt_id
        id = self.id
        last_modified_on = self.last_modified_on
        name = self.name
        default_assessment_version: Union[Unset, None, Dict[str, Any]] = UNSET
        if not isinstance(self.default_assessment_version, Unset):
            default_assessment_version = (
                self.default_assessment_version.to_dict() if self.default_assessment_version else None
            )

        description = self.description
        dt: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.dt, Unset):
            dt = self.dt.to_dict()

        dt_version_assessment_version = (
            self.dt_version_assessment_version.to_dict() if self.dt_version_assessment_version else None
        )

        end_date: Union[Unset, str] = UNSET
        if not isinstance(self.end_date, Unset):
            end_date = self.end_date.isoformat()

        start_date: Union[Unset, str] = UNSET
        if not isinstance(self.start_date, Unset):
            start_date = self.start_date.isoformat()

        status: Union[Unset, str] = UNSET
        if not isinstance(self.status, Unset):
            status = AssessmentStatus.from_val(self.status).value

        status_reason = self.status_reason
        user_dt_permissions: Union[Unset, List[str]] = UNSET
        if not isinstance(self.user_dt_permissions, Unset):
            user_dt_permissions = []
            for componentsschemasdt_user_permissions_item_data in self.user_dt_permissions:
                componentsschemasdt_user_permissions_item = DtUserPermissionsItem.from_val(
                    componentsschemasdt_user_permissions_item_data
                ).value

                user_dt_permissions.append(componentsschemasdt_user_permissions_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "created_by": created_by,
                "created_on": created_on,
                "dt_id": dt_id,
                "id": id,
                "last_modified_on": last_modified_on,
                "name": name,
                "dt_version_assessment_version": dt_version_assessment_version,
            }
        )
        if default_assessment_version is not UNSET:
            field_dict["default_assessment_version"] = default_assessment_version
        if description is not UNSET:
            field_dict["description"] = description
        if dt is not UNSET:
            field_dict["dt"] = dt
        if end_date is not UNSET:
            field_dict["end_date"] = end_date
        if start_date is not UNSET:
            field_dict["start_date"] = start_date
        if status is not UNSET:
            field_dict["status"] = status
        if status_reason is not UNSET:
            field_dict["status_reason"] = status_reason
        if user_dt_permissions is not UNSET:
            field_dict["user_dt_permissions"] = user_dt_permissions

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin import DigitalTwin
        from ..models.zero_days_assessment_version import ZeroDaysAssessmentVersion

        d = src_dict.copy()
        created_by = d.pop("created_by")

        created_on = isoparse(d.pop("created_on"))

        dt_id = d.pop("dt_id")

        id = d.pop("id")

        last_modified_on = d.pop("last_modified_on")

        name = d.pop("name")

        _default_assessment_version = d.pop("default_assessment_version", UNSET)
        default_assessment_version: Union[Unset, None, ZeroDaysAssessmentVersion]
        if _default_assessment_version is None:
            default_assessment_version = None
        elif isinstance(_default_assessment_version, Unset):
            default_assessment_version = UNSET
        else:
            default_assessment_version = ZeroDaysAssessmentVersion.from_dict(_default_assessment_version)

        description = d.pop("description", UNSET)

        _dt = d.pop("dt", UNSET)
        dt: Union[Unset, DigitalTwin]
        if isinstance(_dt, Unset):
            dt = UNSET
        else:
            dt = DigitalTwin.from_dict(_dt)

        _dt_version_assessment_version = d.pop("dt_version_assessment_version")
        dt_version_assessment_version: Optional[ZeroDaysAssessmentVersion]
        if _dt_version_assessment_version is None:
            dt_version_assessment_version = None
        else:
            dt_version_assessment_version = ZeroDaysAssessmentVersion.from_dict(_dt_version_assessment_version)

        _end_date = d.pop("end_date", UNSET)
        end_date: Union[Unset, datetime.datetime]
        if isinstance(_end_date, Unset):
            end_date = UNSET
        else:
            end_date = isoparse(_end_date)

        _start_date = d.pop("start_date", UNSET)
        start_date: Union[Unset, datetime.datetime]
        if isinstance(_start_date, Unset):
            start_date = UNSET
        else:
            start_date = isoparse(_start_date)

        _status = d.pop("status", UNSET)
        status: Union[Unset, AssessmentStatus]
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = AssessmentStatus.from_val(_status)

        status_reason = d.pop("status_reason", UNSET)

        _user_dt_permissions = d.pop("user_dt_permissions", UNSET)
        if (_user_dt_permissions) is UNSET:
            user_dt_permissions = UNSET
        else:
            if _user_dt_permissions:
                user_dt_permissions = []
                for componentsschemasdt_user_permissions_item_data in _user_dt_permissions:
                    componentsschemasdt_user_permissions_item = DtUserPermissionsItem.from_val(
                        componentsschemasdt_user_permissions_item_data
                    )

                    user_dt_permissions.append(componentsschemasdt_user_permissions_item)
            else:
                user_dt_permissions = []

        zero_days_assessment = cls(
            created_by=created_by,
            created_on=created_on,
            dt_id=dt_id,
            id=id,
            last_modified_on=last_modified_on,
            name=name,
            default_assessment_version=default_assessment_version,
            description=description,
            dt=dt,
            dt_version_assessment_version=dt_version_assessment_version,
            end_date=end_date,
            start_date=start_date,
            status=status,
            status_reason=status_reason,
            user_dt_permissions=user_dt_permissions,
        )

        zero_days_assessment.additional_properties = d
        return zero_days_assessment

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
