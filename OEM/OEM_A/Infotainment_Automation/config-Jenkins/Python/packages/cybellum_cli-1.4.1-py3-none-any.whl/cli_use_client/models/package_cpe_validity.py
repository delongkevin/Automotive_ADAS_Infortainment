from enum import Enum
from typing import Union


class PackageCPEValidity(str, Enum):
    EXACT_MATCH = "exact_match"

    NOT_FOUND = "not_found"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "PackageCPEValidity"]) -> "PackageCPEValidity":
        if isinstance(value, PackageCPEValidity):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return PackageCPEValidity(value)
