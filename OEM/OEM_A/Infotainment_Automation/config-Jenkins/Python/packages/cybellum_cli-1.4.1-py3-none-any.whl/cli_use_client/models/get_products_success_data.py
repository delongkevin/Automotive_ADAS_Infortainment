from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.product import Product


T = TypeVar("T", bound="GetProductsSuccessData")


@attr.s(auto_attribs=True)
class GetProductsSuccessData:
    """
    Attributes:
        products (Union[Unset, List['Product']]):
    """

    products: Union[Unset, List["Product"]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        products: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.products, Unset):
            products = []
            for products_item_data in self.products:
                products_item = products_item_data.to_dict()

                products.append(products_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if products is not UNSET:
            field_dict["products"] = products

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.product import Product

        d = src_dict.copy()
        _products = d.pop("products", UNSET)
        if (_products) is UNSET:
            products = UNSET
        else:
            if _products:
                products = []
                for products_item_data in _products:
                    products_item = Product.from_dict(products_item_data)

                    products.append(products_item)
            else:
                products = []

        get_products_success_data = cls(
            products=products,
        )

        get_products_success_data.additional_properties = d
        return get_products_success_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
