from typing import Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="DigitalTwinVersionCreatedWorkflowBasicConfiguration")


@attr.s(auto_attribs=True)
class DigitalTwinVersionCreatedWorkflowBasicConfiguration:
    """Workflow configurations

    Attributes:
        auto_create_policies_assessment (Union[Unset, bool]): Indicator if create policies assessments
        auto_create_vulnerabilities_assessment (Union[Unset, bool]): Indicator if create vulnerabilities assessments
        auto_create_zero_days_assessment (Union[Unset, bool]): Indicator if create zero days assessments
        auto_start_virtual_analyst (Union[Unset, bool]): Indicator if the virtual analyst should be started
            automatically
        auto_upgrade_policies_assessment (Union[Unset, bool]): Indicator if the policies assessments should be upgraded
            automatically
        auto_upgrade_vulnerabilities_assessment (Union[Unset, bool]): Indicator if the vulnerbailities assessments
            should be upgraded automatically
        auto_upgrade_zero_days_assessment (Union[Unset, bool]): Indicator if the zero days assessments should be
            upgraded automatically
        policies_list (Union[Unset, List[str]]): Policies ids to create in case the policies should be created
            automatically
        virtual_analyst_profile (Union[Unset, str]): Virtual analyst profile
    """

    auto_create_policies_assessment: Union[Unset, bool] = UNSET
    auto_create_vulnerabilities_assessment: Union[Unset, bool] = UNSET
    auto_create_zero_days_assessment: Union[Unset, bool] = UNSET
    auto_start_virtual_analyst: Union[Unset, bool] = UNSET
    auto_upgrade_policies_assessment: Union[Unset, bool] = UNSET
    auto_upgrade_vulnerabilities_assessment: Union[Unset, bool] = UNSET
    auto_upgrade_zero_days_assessment: Union[Unset, bool] = UNSET
    policies_list: Union[Unset, List[str]] = UNSET
    virtual_analyst_profile: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        auto_create_policies_assessment = self.auto_create_policies_assessment
        auto_create_vulnerabilities_assessment = self.auto_create_vulnerabilities_assessment
        auto_create_zero_days_assessment = self.auto_create_zero_days_assessment
        auto_start_virtual_analyst = self.auto_start_virtual_analyst
        auto_upgrade_policies_assessment = self.auto_upgrade_policies_assessment
        auto_upgrade_vulnerabilities_assessment = self.auto_upgrade_vulnerabilities_assessment
        auto_upgrade_zero_days_assessment = self.auto_upgrade_zero_days_assessment
        policies_list: Union[Unset, List[str]] = UNSET
        if not isinstance(self.policies_list, Unset):
            policies_list = self.policies_list

        virtual_analyst_profile = self.virtual_analyst_profile

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if auto_create_policies_assessment is not UNSET:
            field_dict["auto_create_policies_assessment"] = auto_create_policies_assessment
        if auto_create_vulnerabilities_assessment is not UNSET:
            field_dict["auto_create_vulnerabilities_assessment"] = auto_create_vulnerabilities_assessment
        if auto_create_zero_days_assessment is not UNSET:
            field_dict["auto_create_zero_days_assessment"] = auto_create_zero_days_assessment
        if auto_start_virtual_analyst is not UNSET:
            field_dict["auto_start_virtual_analyst"] = auto_start_virtual_analyst
        if auto_upgrade_policies_assessment is not UNSET:
            field_dict["auto_upgrade_policies_assessment"] = auto_upgrade_policies_assessment
        if auto_upgrade_vulnerabilities_assessment is not UNSET:
            field_dict["auto_upgrade_vulnerabilities_assessment"] = auto_upgrade_vulnerabilities_assessment
        if auto_upgrade_zero_days_assessment is not UNSET:
            field_dict["auto_upgrade_zero_days_assessment"] = auto_upgrade_zero_days_assessment
        if policies_list is not UNSET:
            field_dict["policies_list"] = policies_list
        if virtual_analyst_profile is not UNSET:
            field_dict["virtual_analyst_profile"] = virtual_analyst_profile

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        auto_create_policies_assessment = d.pop("auto_create_policies_assessment", UNSET)

        auto_create_vulnerabilities_assessment = d.pop("auto_create_vulnerabilities_assessment", UNSET)

        auto_create_zero_days_assessment = d.pop("auto_create_zero_days_assessment", UNSET)

        auto_start_virtual_analyst = d.pop("auto_start_virtual_analyst", UNSET)

        auto_upgrade_policies_assessment = d.pop("auto_upgrade_policies_assessment", UNSET)

        auto_upgrade_vulnerabilities_assessment = d.pop("auto_upgrade_vulnerabilities_assessment", UNSET)

        auto_upgrade_zero_days_assessment = d.pop("auto_upgrade_zero_days_assessment", UNSET)

        policies_list = cast(List[str], d.pop("policies_list", UNSET))

        virtual_analyst_profile = d.pop("virtual_analyst_profile", UNSET)

        digital_twin_version_created_workflow_basic_configuration = cls(
            auto_create_policies_assessment=auto_create_policies_assessment,
            auto_create_vulnerabilities_assessment=auto_create_vulnerabilities_assessment,
            auto_create_zero_days_assessment=auto_create_zero_days_assessment,
            auto_start_virtual_analyst=auto_start_virtual_analyst,
            auto_upgrade_policies_assessment=auto_upgrade_policies_assessment,
            auto_upgrade_vulnerabilities_assessment=auto_upgrade_vulnerabilities_assessment,
            auto_upgrade_zero_days_assessment=auto_upgrade_zero_days_assessment,
            policies_list=policies_list,
            virtual_analyst_profile=virtual_analyst_profile,
        )

        digital_twin_version_created_workflow_basic_configuration.additional_properties = d
        return digital_twin_version_created_workflow_basic_configuration

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
