from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.policies_assessment import PoliciesAssessment


T = TypeVar("T", bound="CreatePoliciesAssessmentResponse200Data")


@attr.s(auto_attribs=True)
class CreatePoliciesAssessmentResponse200Data:
    """
    Attributes:
        assessment (Union[Unset, PoliciesAssessment]): Policies assessment
    """

    assessment: Union[Unset, "PoliciesAssessment"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        assessment: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.assessment, Unset):
            assessment = self.assessment.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if assessment is not UNSET:
            field_dict["assessment"] = assessment

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.policies_assessment import PoliciesAssessment

        d = src_dict.copy()
        _assessment = d.pop("assessment", UNSET)
        assessment: Union[Unset, PoliciesAssessment]
        if isinstance(_assessment, Unset):
            assessment = UNSET
        else:
            assessment = PoliciesAssessment.from_dict(_assessment)

        create_policies_assessment_response_200_data = cls(
            assessment=assessment,
        )

        create_policies_assessment_response_200_data.additional_properties = d
        return create_policies_assessment_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
