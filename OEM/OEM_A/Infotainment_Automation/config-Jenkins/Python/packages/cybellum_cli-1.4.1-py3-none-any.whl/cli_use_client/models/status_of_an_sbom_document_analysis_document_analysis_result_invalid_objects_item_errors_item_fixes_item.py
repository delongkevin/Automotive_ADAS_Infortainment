from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemFixesItem")


@attr.s(auto_attribs=True)
class StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemFixesItem:
    """
    Attributes:
        default (Union[Unset, bool]):
        location (Union[Unset, str]):
        op (Union[Unset, str]): "add", "replace", "remove", "move" or "copy"
        to_location (Union[Unset, str]):
        value (Union[Unset, str]):
    """

    default: Union[Unset, bool] = False
    location: Union[Unset, str] = UNSET
    op: Union[Unset, str] = UNSET
    to_location: Union[Unset, str] = UNSET
    value: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        default = self.default
        location = self.location
        op = self.op
        to_location = self.to_location
        value = self.value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if default is not UNSET:
            field_dict["default"] = default
        if location is not UNSET:
            field_dict["location"] = location
        if op is not UNSET:
            field_dict["op"] = op
        if to_location is not UNSET:
            field_dict["to_location"] = to_location
        if value is not UNSET:
            field_dict["value"] = value

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        default = d.pop("default", UNSET)

        location = d.pop("location", UNSET)

        op = d.pop("op", UNSET)

        to_location = d.pop("to_location", UNSET)

        value = d.pop("value", UNSET)

        status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item_fixes_item = cls(
            default=default,
            location=location,
            op=op,
            to_location=to_location,
            value=value,
        )

        status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item_fixes_item.additional_properties = (
            d
        )
        return status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item_fixes_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
