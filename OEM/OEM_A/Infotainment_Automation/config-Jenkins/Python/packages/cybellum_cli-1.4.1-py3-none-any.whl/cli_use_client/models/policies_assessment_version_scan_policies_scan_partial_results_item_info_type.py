from enum import Enum
from typing import Union


class PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfoType(str, Enum):
    ERROR = "error"

    HANDLER_NOT_FOUND = "handler_not_found"

    ASSESSMENT_REQUIREMENT_ID_NOT_FOUND = "assessment_requirement_id_not_found"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(
        cls, value: Union[str, "PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfoType"]
    ) -> "PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfoType":
        if isinstance(value, PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfoType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return PoliciesAssessmentVersionScanPoliciesScanPartialResultsItemInfoType(value)
