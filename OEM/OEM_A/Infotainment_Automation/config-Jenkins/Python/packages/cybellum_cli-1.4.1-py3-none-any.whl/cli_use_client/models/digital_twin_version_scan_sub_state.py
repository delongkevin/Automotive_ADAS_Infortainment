from enum import Enum
from typing import Union


class DigitalTwinVersionScanSubState(str, Enum):
    WAIT_MACHINE = "wait_machine"

    WAIT_ON_MACHINE = "wait_on_machine"

    EXTRACTING = "extracting"

    ANALYZING = "analyzing"

    SUCCESS = "success"

    FAILURE = "failure"

    CANCELLED = "cancelled"

    PENDING_ANALYSIS = "pending_analysis"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "DigitalTwinVersionScanSubState"]) -> "DigitalTwinVersionScanSubState":
        if isinstance(value, DigitalTwinVersionScanSubState):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return DigitalTwinVersionScanSubState(value)
