from http import HTTPStatus
from io import BytesIO
from typing import Any, Dict, List, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, AuthenticationStatus, Client, ParseResponseBehavior, flatten_params
from ...models.error import Error
from ...models.export_digital_twin_cyclonedx_spec import ExportDigitalTwinCyclonedxSpec
from ...types import UNSET, File, Response, Unset


def _get_kwargs(
    *,
    client: AuthenticatedClient,
    dt_version_id: str,
    spec: Union[Unset, None, ExportDigitalTwinCyclonedxSpec] = ExportDigitalTwinCyclonedxSpec.VALUE_2,
    exclude_packages_with_tags: Union[Unset, None, List[str]] = UNSET,
    include_vulnerabilities_data: Union[Unset, None, bool] = UNSET,
) -> Dict[str, Any]:
    url = "{}/reporting/dts/versions/export_cyclone_dx".format(client.get_service_url("digital-twins"))

    headers: Dict[str, str] = client.get_headers()
    cookies: Dict[str, Any] = client.get_cookies()

    params: Dict[str, Any] = {}
    params["dt_version_id"] = dt_version_id

    json_spec: Union[Unset, None, str] = UNSET
    if not isinstance(spec, Unset):
        json_spec = ExportDigitalTwinCyclonedxSpec.from_val(spec).value if spec else None

    params["spec"] = json_spec

    json_exclude_packages_with_tags: Union[Unset, None, List[str]] = UNSET
    if not isinstance(exclude_packages_with_tags, Unset):
        if exclude_packages_with_tags is None:
            json_exclude_packages_with_tags = None
        else:
            json_exclude_packages_with_tags = exclude_packages_with_tags

    params["exclude_packages_with_tags"] = json_exclude_packages_with_tags

    params["include_vulnerabilities_data"] = include_vulnerabilities_data

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}
    params = flatten_params(params)

    return {
        "method": "get",
        "url": url,
        "headers": headers,
        "cookies": cookies,
        "timeout": client.get_timeout(),
        "params": params,
    }


def _parse_response(*, client: Client, response: httpx.Response) -> Optional[Union[Error, File]]:
    if response.status_code == HTTPStatus.OK:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_200 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_200 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                _response_200 = response.content
                response_200: File

                if isinstance(_response_200, File):
                    response_200 = _response_200
                else:
                    response_200 = File(payload=BytesIO(_response_200))

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        return response_200

    if response.status_code == HTTPStatus.BAD_REQUEST:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_400 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_400 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_400 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_400, status_code=response.status_code
            )
        return response_400

    if response.status_code == HTTPStatus.UNAUTHORIZED:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_401 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_401 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_401 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_401, status_code=response.status_code
            )
        return response_401

    if response.status_code == HTTPStatus.FORBIDDEN:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_403 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_403 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_403 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_403, status_code=response.status_code
            )
        return response_403

    if response.status_code == HTTPStatus.NOT_FOUND:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_404 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_404 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_404 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_404, status_code=response.status_code
            )
        return response_404

    if response.status_code == HTTPStatus.METHOD_NOT_ALLOWED:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_405 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_405 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_405 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_405, status_code=response.status_code
            )
        return response_405

    if response.status_code == HTTPStatus.INTERNAL_SERVER_ERROR:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_500 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_500 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_500 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_500, status_code=response.status_code
            )
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(f"Unexpected status code: {response.status_code}")
    else:
        return None


def _build_response(*, client: Client, response: httpx.Response) -> Union[Response[Union[Error, File]], httpx.Response]:
    if client.parse_response_behavior == ParseResponseBehavior.RAW_RESPONSE:
        return response

    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    dt_version_id: str,
    spec: Union[Unset, None, ExportDigitalTwinCyclonedxSpec] = ExportDigitalTwinCyclonedxSpec.VALUE_2,
    exclude_packages_with_tags: Union[Unset, None, List[str]] = UNSET,
    include_vulnerabilities_data: Union[Unset, None, bool] = UNSET,
) -> Union[Response[Union[Error, File]], httpx.Response]:
    """Export digital twin CycloneDX

     Exports digital twin CycloneDX

    Args:
        dt_version_id (str): ID
        spec (Union[Unset, None, ExportDigitalTwinCyclonedxSpec]): Specification version Default:
            ExportDigitalTwinCyclonedxSpec.VALUE_2.
        exclude_packages_with_tags (Union[Unset, None, List[str]]): A list of tags. Packages and
            dependencies associated with these tags will NOT be included in the exported CycloneDX
            document.
        include_vulnerabilities_data (Union[Unset, None, bool]): Include vulnerabilities data in
            report

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, File]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
        dt_version_id=dt_version_id,
        spec=spec,
        exclude_packages_with_tags=exclude_packages_with_tags,
        include_vulnerabilities_data=include_vulnerabilities_data,
    )

    with httpx.Client(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = _client.request(**kwargs)

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    dt_version_id: str,
    spec: Union[Unset, None, ExportDigitalTwinCyclonedxSpec] = ExportDigitalTwinCyclonedxSpec.VALUE_2,
    exclude_packages_with_tags: Union[Unset, None, List[str]] = UNSET,
    include_vulnerabilities_data: Union[Unset, None, bool] = UNSET,
) -> Optional[Union[Error, File]]:
    """Export digital twin CycloneDX

     Exports digital twin CycloneDX

    Args:
        dt_version_id (str): ID
        spec (Union[Unset, None, ExportDigitalTwinCyclonedxSpec]): Specification version Default:
            ExportDigitalTwinCyclonedxSpec.VALUE_2.
        exclude_packages_with_tags (Union[Unset, None, List[str]]): A list of tags. Packages and
            dependencies associated with these tags will NOT be included in the exported CycloneDX
            document.
        include_vulnerabilities_data (Union[Unset, None, bool]): Include vulnerabilities data in
            report

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, File]]
    """

    return sync_detailed(
        client=client,
        dt_version_id=dt_version_id,
        spec=spec,
        exclude_packages_with_tags=exclude_packages_with_tags,
        include_vulnerabilities_data=include_vulnerabilities_data,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    dt_version_id: str,
    spec: Union[Unset, None, ExportDigitalTwinCyclonedxSpec] = ExportDigitalTwinCyclonedxSpec.VALUE_2,
    exclude_packages_with_tags: Union[Unset, None, List[str]] = UNSET,
    include_vulnerabilities_data: Union[Unset, None, bool] = UNSET,
) -> Union[Response[Union[Error, File]], httpx.Response]:
    """Export digital twin CycloneDX

     Exports digital twin CycloneDX

    Args:
        dt_version_id (str): ID
        spec (Union[Unset, None, ExportDigitalTwinCyclonedxSpec]): Specification version Default:
            ExportDigitalTwinCyclonedxSpec.VALUE_2.
        exclude_packages_with_tags (Union[Unset, None, List[str]]): A list of tags. Packages and
            dependencies associated with these tags will NOT be included in the exported CycloneDX
            document.
        include_vulnerabilities_data (Union[Unset, None, bool]): Include vulnerabilities data in
            report

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, File]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
        dt_version_id=dt_version_id,
        spec=spec,
        exclude_packages_with_tags=exclude_packages_with_tags,
        include_vulnerabilities_data=include_vulnerabilities_data,
    )

    async with httpx.AsyncClient(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = await _client.request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    dt_version_id: str,
    spec: Union[Unset, None, ExportDigitalTwinCyclonedxSpec] = ExportDigitalTwinCyclonedxSpec.VALUE_2,
    exclude_packages_with_tags: Union[Unset, None, List[str]] = UNSET,
    include_vulnerabilities_data: Union[Unset, None, bool] = UNSET,
) -> Optional[Union[Error, File]]:
    """Export digital twin CycloneDX

     Exports digital twin CycloneDX

    Args:
        dt_version_id (str): ID
        spec (Union[Unset, None, ExportDigitalTwinCyclonedxSpec]): Specification version Default:
            ExportDigitalTwinCyclonedxSpec.VALUE_2.
        exclude_packages_with_tags (Union[Unset, None, List[str]]): A list of tags. Packages and
            dependencies associated with these tags will NOT be included in the exported CycloneDX
            document.
        include_vulnerabilities_data (Union[Unset, None, bool]): Include vulnerabilities data in
            report

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, File]]
    """

    return (
        await asyncio_detailed(
            client=client,
            dt_version_id=dt_version_id,
            spec=spec,
            exclude_packages_with_tags=exclude_packages_with_tags,
            include_vulnerabilities_data=include_vulnerabilities_data,
        )
    ).parsed
