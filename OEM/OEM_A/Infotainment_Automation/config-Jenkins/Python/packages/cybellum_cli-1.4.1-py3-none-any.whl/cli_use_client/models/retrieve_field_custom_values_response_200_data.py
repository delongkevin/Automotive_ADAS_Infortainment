from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.field_custom_value import FieldCustomValue


T = TypeVar("T", bound="RetrieveFieldCustomValuesResponse200Data")


@attr.s(auto_attribs=True)
class RetrieveFieldCustomValuesResponse200Data:
    """
    Attributes:
        fields_custom_values (Union[Unset, List['FieldCustomValue']]):
    """

    fields_custom_values: Union[Unset, List["FieldCustomValue"]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        fields_custom_values: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.fields_custom_values, Unset):
            fields_custom_values = []
            for fields_custom_values_item_data in self.fields_custom_values:
                fields_custom_values_item = fields_custom_values_item_data.to_dict()

                fields_custom_values.append(fields_custom_values_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if fields_custom_values is not UNSET:
            field_dict["fields_custom_values"] = fields_custom_values

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.field_custom_value import FieldCustomValue

        d = src_dict.copy()
        _fields_custom_values = d.pop("fields_custom_values", UNSET)
        if (_fields_custom_values) is UNSET:
            fields_custom_values = UNSET
        else:
            if _fields_custom_values:
                fields_custom_values = []
                for fields_custom_values_item_data in _fields_custom_values:
                    fields_custom_values_item = FieldCustomValue.from_dict(fields_custom_values_item_data)

                    fields_custom_values.append(fields_custom_values_item)
            else:
                fields_custom_values = []

        retrieve_field_custom_values_response_200_data = cls(
            fields_custom_values=fields_custom_values,
        )

        retrieve_field_custom_values_response_200_data.additional_properties = d
        return retrieve_field_custom_values_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
