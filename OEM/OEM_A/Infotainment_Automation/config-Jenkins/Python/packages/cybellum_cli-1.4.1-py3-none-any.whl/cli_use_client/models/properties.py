from typing import Any, Dict, List, Type, TypeVar

import attr

T = TypeVar("T", bound="Properties")


@attr.s(auto_attribs=True)
class Properties:
    """Properties

    Attributes:
        feasibility (float): Feasibility of the connection
        interface (str): Interface name
    """

    feasibility: float
    interface: str
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        feasibility = self.feasibility
        interface = self.interface

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "feasibility": feasibility,
                "interface": interface,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        feasibility = d.pop("feasibility")

        interface = d.pop("interface")

        properties = cls(
            feasibility=feasibility,
            interface=interface,
        )

        properties.additional_properties = d
        return properties

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
