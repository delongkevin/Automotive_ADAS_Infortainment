import datetime
from typing import Any, Dict, List, Type, TypeVar

import attr
from dateutil.parser import isoparse

T = TypeVar("T", bound="CleanStageUploadJsonBody")


@attr.s(auto_attribs=True)
class CleanStageUploadJsonBody:
    """
    Attributes:
        older_than (datetime.datetime): Stage upload files and records created before this date will be deleted
    """

    older_than: datetime.datetime
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        older_than = self.older_than.isoformat()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "older_than": older_than,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        older_than = isoparse(d.pop("older_than"))

        clean_stage_upload_json_body = cls(
            older_than=older_than,
        )

        clean_stage_upload_json_body.additional_properties = d
        return clean_stage_upload_json_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
