from enum import Enum
from typing import Union


class PolicyConfigurationSource(str, Enum):
    CYBELLUM = "cybellum"

    USER = "user"

    USER_DEFINED = "user_defined"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "PolicyConfigurationSource"]) -> "PolicyConfigurationSource":
        if isinstance(value, PolicyConfigurationSource):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return PolicyConfigurationSource(value)
