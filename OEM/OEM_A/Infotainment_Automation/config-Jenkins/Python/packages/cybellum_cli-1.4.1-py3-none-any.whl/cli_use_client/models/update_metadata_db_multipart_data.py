from io import BytesIO
from typing import Any, Dict, List, Tuple, Type, TypeVar, Union

import attr

from ..client import flatten_params
from ..types import UNSET, File, Unset

T = TypeVar("T", bound="UpdateMetadataDBMultipartData")


@attr.s(auto_attribs=True)
class UpdateMetadataDBMultipartData:
    """
    Attributes:
        update_file (File): Metadata database file
        force (Union[Unset, bool]): in case the user will pass “true” it will skip the checks and do the update
    """

    update_file: File
    force: Union[Unset, bool] = False
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        update_file = self.update_file.to_tuple()

        force = self.force

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "update_file": update_file,
            }
        )
        if force is not UNSET:
            field_dict["force"] = force

        return field_dict

    def to_multipart(self) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        self_dict = self.to_dict()
        self_dict = flatten_params(self_dict)
        data = {
            key: value
            for key, value in self_dict.items()
            if value is not None and value is not UNSET and not isinstance(value, File) and not isinstance(value, Tuple)
        }
        files = {
            key: value.to_tuple() if isinstance(value, File) else value
            for key, value in self_dict.items()
            if value is not None and value is not UNSET and (isinstance(value, File) or isinstance(value, Tuple))
        }
        return (data, files)

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _update_file = d.pop("update_file")
        update_file: File

        if isinstance(_update_file, File):
            update_file = _update_file
        else:
            update_file = File(payload=BytesIO(_update_file))

        force = d.pop("force", UNSET)

        update_metadata_db_multipart_data = cls(
            update_file=update_file,
            force=force,
        )

        update_metadata_db_multipart_data.additional_properties = d
        return update_metadata_db_multipart_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
