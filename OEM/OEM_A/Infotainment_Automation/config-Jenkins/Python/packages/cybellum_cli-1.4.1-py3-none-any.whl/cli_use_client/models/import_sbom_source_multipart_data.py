from io import BytesIO
from typing import Any, Dict, List, Tuple, Type, TypeVar, Union, cast

import attr

from ..client import flatten_params
from ..models.dt_creation_types import DtCreationTypes
from ..types import UNSET, File, FileJsonType, Unset

T = TypeVar("T", bound="ImportSbomSourceMultipartData")


@attr.s(auto_attribs=True)
class ImportSbomSourceMultipartData:
    """There are 4 schemas for specifying information about files. Use only one of these.
    - file_ids
    - urls
    - files

        Attributes:
            dt_version_id (str): ID
            auto_fix_import_issues (Union[Unset, bool]): Automatically fix errors when importing from an SBOM format file
                (CycloneDX, SPDX or CPE CVEs) Default: True.
            creation_type (Union[Unset, DtCreationTypes]): The creation type of the digital twin version.  For
                "create_from_firmware" you can specify multiple files via the "urls", "files", "file_ids" or
                "resumable_identifiers" parameters.  For "create_manually" you should not specify any files and for all other
                creation types you should specify exactly one file.  You can use "import_from_sbom_file" to create a DT version
                from either a CycloneDX, SPDX or "CPE CVEs" list.  You can use "import_based_on_file_classification" to create a
                DT version from either a single binary/firmware file or from an SBOM format file (CycloneDX, SPDX or "CPE CVEs"
                list). You can use "create_from_source_code" you can specify multiple source code sources via the "urls",
                "files", "file_ids" or "resumable_identifiers" parameters.
            file_ids (Union[Unset, List[str]]): Each entry in the list is a unique identifier for an uploaded file. This
                value should match the identifier used for the file upload, either the "resumableIdentifier" value used for
                "Upload a resumable file", or the "file_id" value used for "Upload file from URL".
            files (Union[File, List[File], Unset]): files to upload
            urls (Union[Unset, List[str]]): files to upload from a URL - in case this field is set the system will ignore
                the 'files' parameter. otherwise it will look for the files in the 'files' parameter
    """

    dt_version_id: str
    auto_fix_import_issues: Union[Unset, bool] = True
    creation_type: Union[Unset, DtCreationTypes] = UNSET
    file_ids: Union[Unset, List[str]] = UNSET
    files: Union[File, List[File], Unset] = UNSET
    urls: Union[Unset, List[str]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        dt_version_id = self.dt_version_id
        auto_fix_import_issues = self.auto_fix_import_issues
        creation_type: Union[Unset, str] = UNSET
        if not isinstance(self.creation_type, Unset):
            creation_type = DtCreationTypes.from_val(self.creation_type).value

        file_ids: Union[Unset, List[str]] = UNSET
        if not isinstance(self.file_ids, Unset):
            file_ids = self.file_ids

        files: Union[FileJsonType, List[FileJsonType], Unset]
        if isinstance(self.files, Unset):
            files = UNSET

        elif isinstance(self.files, File):
            files = UNSET
            if not isinstance(self.files, Unset):
                files = self.files.to_tuple()

        else:
            files = UNSET
            if not isinstance(self.files, Unset):
                files = []
                for files_type_1_item_data in self.files:
                    files_type_1_item = files_type_1_item_data.to_tuple()

                    files.append(files_type_1_item)

        urls: Union[Unset, List[str]] = UNSET
        if not isinstance(self.urls, Unset):
            urls = self.urls

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "dt_version_id": dt_version_id,
            }
        )
        if auto_fix_import_issues is not UNSET:
            field_dict["auto_fix_import_issues"] = auto_fix_import_issues
        if creation_type is not UNSET:
            field_dict["creation_type"] = creation_type
        if file_ids is not UNSET:
            field_dict["file_ids"] = file_ids
        if files is not UNSET:
            field_dict["files"] = files
        if urls is not UNSET:
            field_dict["urls"] = urls

        return field_dict

    def to_multipart(self) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        self_dict = self.to_dict()
        self_dict = flatten_params(self_dict)
        data = {
            key: value
            for key, value in self_dict.items()
            if value is not None and value is not UNSET and not isinstance(value, File) and not isinstance(value, Tuple)
        }
        files = {
            key: value.to_tuple() if isinstance(value, File) else value
            for key, value in self_dict.items()
            if value is not None and value is not UNSET and (isinstance(value, File) or isinstance(value, Tuple))
        }
        return (data, files)

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        dt_version_id = d.pop("dt_version_id")

        auto_fix_import_issues = d.pop("auto_fix_import_issues", UNSET)

        _creation_type = d.pop("creation_type", UNSET)
        creation_type: Union[Unset, DtCreationTypes]
        if isinstance(_creation_type, Unset):
            creation_type = UNSET
        else:
            creation_type = DtCreationTypes.from_val(_creation_type)

        file_ids = cast(List[str], d.pop("file_ids", UNSET))

        def _parse_files(data: object) -> Union[File, List[File], Unset]:
            if isinstance(data, Unset):
                return data
            try:
                if not (isinstance(data, bytes) or isinstance(data, File)):
                    raise TypeError()
                _files_type_0 = data
                files_type_0: Union[Unset, File]

                if isinstance(_files_type_0, Unset):
                    files_type_0 = UNSET
                elif isinstance(_files_type_0, File):
                    files_type_0 = _files_type_0
                else:
                    files_type_0 = File(payload=BytesIO(_files_type_0))

                return files_type_0
            except:  # noqa: E722
                pass
            if not isinstance(data, list):
                raise TypeError()
            _files_type_1 = data
            if (_files_type_1) is UNSET:
                files_type_1 = UNSET
            else:
                if _files_type_1:
                    files_type_1 = []
                    for files_type_1_item_data in _files_type_1:
                        _files_type_1_item = files_type_1_item_data
                        files_type_1_item: File

                        if isinstance(_files_type_1_item, File):
                            files_type_1_item = _files_type_1_item
                        else:
                            files_type_1_item = File(payload=BytesIO(_files_type_1_item))

                        files_type_1.append(files_type_1_item)
                else:
                    files_type_1 = UNSET

            return files_type_1

        files = _parse_files(d.pop("files", UNSET))

        urls = cast(List[str], d.pop("urls", UNSET))

        import_sbom_source_multipart_data = cls(
            dt_version_id=dt_version_id,
            auto_fix_import_issues=auto_fix_import_issues,
            creation_type=creation_type,
            file_ids=file_ids,
            files=files,
            urls=urls,
        )

        import_sbom_source_multipart_data.additional_properties = d
        return import_sbom_source_multipart_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
