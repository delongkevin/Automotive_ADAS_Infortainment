from enum import Enum
from typing import Union


class PolicyType(str, Enum):
    OPERATIONAL = "operational"

    LEGAL = "legal"

    SECURITY = "security"

    COMPLIANCE = "compliance"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "PolicyType"]) -> "PolicyType":
        if isinstance(value, PolicyType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return PolicyType(value)
