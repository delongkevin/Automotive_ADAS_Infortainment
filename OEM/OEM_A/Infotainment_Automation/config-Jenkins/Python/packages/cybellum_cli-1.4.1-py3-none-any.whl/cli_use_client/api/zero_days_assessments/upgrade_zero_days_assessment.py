from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, AuthenticationStatus, Client, ParseResponseBehavior
from ...models.error import Error
from ...models.upgrade_zero_days_assessment_json_body import UpgradeZeroDaysAssessmentJsonBody
from ...models.upgrade_zero_days_assessment_response_200 import UpgradeZeroDaysAssessmentResponse200
from ...types import Response


def _get_kwargs(
    *,
    client: AuthenticatedClient,
    json_body: UpgradeZeroDaysAssessmentJsonBody,
) -> Dict[str, Any]:
    url = "{}/zero_days/assessments/upgrade_version".format(client.get_service_url("unknown-vulnerabilities"))

    headers: Dict[str, str] = client.get_headers()
    cookies: Dict[str, Any] = client.get_cookies()

    json_json_body = json_body.to_dict()

    return {
        "method": "post",
        "url": url,
        "headers": headers,
        "cookies": cookies,
        "timeout": client.get_timeout(),
        "json": json_json_body,
    }


def _parse_response(
    *, client: Client, response: httpx.Response
) -> Optional[Union[Error, UpgradeZeroDaysAssessmentResponse200]]:
    if response.status_code == HTTPStatus.OK:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_200 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_200 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_200 = UpgradeZeroDaysAssessmentResponse200.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        return response_200

    if response.status_code == HTTPStatus.BAD_REQUEST:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_400 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_400 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_400 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_400, status_code=response.status_code
            )
        return response_400

    if response.status_code == HTTPStatus.UNAUTHORIZED:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_401 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_401 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_401 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_401, status_code=response.status_code
            )
        return response_401

    if response.status_code == HTTPStatus.FORBIDDEN:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_403 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_403 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_403 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_403, status_code=response.status_code
            )
        return response_403

    if response.status_code == HTTPStatus.NOT_FOUND:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_404 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_404 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_404 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_404, status_code=response.status_code
            )
        return response_404

    if response.status_code == HTTPStatus.METHOD_NOT_ALLOWED:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_405 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_405 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_405 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_405, status_code=response.status_code
            )
        return response_405

    if response.status_code == HTTPStatus.INTERNAL_SERVER_ERROR:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_500 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_500 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_500 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_500, status_code=response.status_code
            )
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(f"Unexpected status code: {response.status_code}")
    else:
        return None


def _build_response(
    *, client: Client, response: httpx.Response
) -> Union[Response[Union[Error, UpgradeZeroDaysAssessmentResponse200]], httpx.Response]:
    if client.parse_response_behavior == ParseResponseBehavior.RAW_RESPONSE:
        return response

    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    json_body: UpgradeZeroDaysAssessmentJsonBody,
) -> Union[Response[Union[Error, UpgradeZeroDaysAssessmentResponse200]], httpx.Response]:
    """Upgrade zero days assessment

     Upgrades zero-days assessment

    Args:
        json_body (UpgradeZeroDaysAssessmentJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, UpgradeZeroDaysAssessmentResponse200]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
        json_body=json_body,
    )

    with httpx.Client(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = _client.request(**kwargs)

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    json_body: UpgradeZeroDaysAssessmentJsonBody,
) -> Optional[Union[Error, UpgradeZeroDaysAssessmentResponse200]]:
    """Upgrade zero days assessment

     Upgrades zero-days assessment

    Args:
        json_body (UpgradeZeroDaysAssessmentJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, UpgradeZeroDaysAssessmentResponse200]]
    """

    return sync_detailed(
        client=client,
        json_body=json_body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    json_body: UpgradeZeroDaysAssessmentJsonBody,
) -> Union[Response[Union[Error, UpgradeZeroDaysAssessmentResponse200]], httpx.Response]:
    """Upgrade zero days assessment

     Upgrades zero-days assessment

    Args:
        json_body (UpgradeZeroDaysAssessmentJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, UpgradeZeroDaysAssessmentResponse200]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
        json_body=json_body,
    )

    async with httpx.AsyncClient(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = await _client.request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    json_body: UpgradeZeroDaysAssessmentJsonBody,
) -> Optional[Union[Error, UpgradeZeroDaysAssessmentResponse200]]:
    """Upgrade zero days assessment

     Upgrades zero-days assessment

    Args:
        json_body (UpgradeZeroDaysAssessmentJsonBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, UpgradeZeroDaysAssessmentResponse200]]
    """

    return (
        await asyncio_detailed(
            client=client,
            json_body=json_body,
        )
    ).parsed
