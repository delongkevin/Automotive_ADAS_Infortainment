from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item_fixes_item import (
        StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemFixesItem,
    )
    from ..models.status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item_validation_check import (
        StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemValidationCheck,
    )


T = TypeVar("T", bound="StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItem")


@attr.s(auto_attribs=True)
class StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItem:
    """
    Attributes:
        error_type (Union[Unset, str]): "invalid_value" or "missing"
        fixes (Union[Unset,
            List['StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemFixesItem']]):
        location (Union[Unset, str]):
        original_value (Union[Unset, str]):
        validation_check (Union[Unset,
            StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemValidationCheck]):
        value_options (Union[Unset, List[str]]):
    """

    error_type: Union[Unset, str] = UNSET
    fixes: Union[
        Unset, List["StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemFixesItem"]
    ] = UNSET
    location: Union[Unset, str] = UNSET
    original_value: Union[Unset, str] = UNSET
    validation_check: Union[
        Unset, "StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemValidationCheck"
    ] = UNSET
    value_options: Union[Unset, List[str]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        error_type = self.error_type
        fixes: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.fixes, Unset):
            fixes = []
            for fixes_item_data in self.fixes:
                fixes_item = fixes_item_data.to_dict()

                fixes.append(fixes_item)

        location = self.location
        original_value = self.original_value
        validation_check: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.validation_check, Unset):
            validation_check = self.validation_check.to_dict()

        value_options: Union[Unset, List[str]] = UNSET
        if not isinstance(self.value_options, Unset):
            value_options = self.value_options

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if error_type is not UNSET:
            field_dict["error_type"] = error_type
        if fixes is not UNSET:
            field_dict["fixes"] = fixes
        if location is not UNSET:
            field_dict["location"] = location
        if original_value is not UNSET:
            field_dict["original_value"] = original_value
        if validation_check is not UNSET:
            field_dict["validation_check"] = validation_check
        if value_options is not UNSET:
            field_dict["value_options"] = value_options

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item_fixes_item import (
            StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemFixesItem,
        )
        from ..models.status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item_validation_check import (
            StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemValidationCheck,
        )

        d = src_dict.copy()
        error_type = d.pop("error_type", UNSET)

        _fixes = d.pop("fixes", UNSET)
        if (_fixes) is UNSET:
            fixes = UNSET
        else:
            if _fixes:
                fixes = []
                for fixes_item_data in _fixes:
                    fixes_item = StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemFixesItem.from_dict(
                        fixes_item_data
                    )

                    fixes.append(fixes_item)
            else:
                fixes = []

        location = d.pop("location", UNSET)

        original_value = d.pop("original_value", UNSET)

        _validation_check = d.pop("validation_check", UNSET)
        validation_check: Union[
            Unset, StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemValidationCheck
        ]
        if isinstance(_validation_check, Unset):
            validation_check = UNSET
        else:
            validation_check = StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemValidationCheck.from_dict(
                _validation_check
            )

        value_options = cast(List[str], d.pop("value_options", UNSET))

        status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item = cls(
            error_type=error_type,
            fixes=fixes,
            location=location,
            original_value=original_value,
            validation_check=validation_check,
            value_options=value_options,
        )

        status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item.additional_properties = (
            d
        )
        return status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
