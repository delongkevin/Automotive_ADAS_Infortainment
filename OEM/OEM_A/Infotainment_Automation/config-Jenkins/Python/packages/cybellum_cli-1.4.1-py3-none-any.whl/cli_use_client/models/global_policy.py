from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.policy_configuration_source import PolicyConfigurationSource
from ..models.policy_type import PolicyType
from ..models.required_source_type import RequiredSourceType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.global_requirement import GlobalRequirement


T = TypeVar("T", bound="GlobalPolicy")


@attr.s(auto_attribs=True)
class GlobalPolicy:
    """Global policy

    Attributes:
        category (str): Policy category
        id (str): Policy id
        name (str): Policy name
        configuration_source (Union[Unset, PolicyConfigurationSource]): Policy configuration source
        description (Union[Unset, str]): Policy description
        policy_types (Union[Unset, List[PolicyType]]):
        required_assessment_types (Union[Unset, List[RequiredSourceType]]):
        requirements (Union[Unset, List['GlobalRequirement']]):
    """

    category: str
    id: str
    name: str
    configuration_source: Union[Unset, PolicyConfigurationSource] = UNSET
    description: Union[Unset, str] = UNSET
    policy_types: Union[Unset, List[PolicyType]] = UNSET
    required_assessment_types: Union[Unset, List[RequiredSourceType]] = UNSET
    requirements: Union[Unset, List["GlobalRequirement"]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        category = self.category
        id = self.id
        name = self.name
        configuration_source: Union[Unset, str] = UNSET
        if not isinstance(self.configuration_source, Unset):
            configuration_source = PolicyConfigurationSource.from_val(self.configuration_source).value

        description = self.description
        policy_types: Union[Unset, List[str]] = UNSET
        if not isinstance(self.policy_types, Unset):
            policy_types = []
            for policy_types_item_data in self.policy_types:
                policy_types_item = PolicyType.from_val(policy_types_item_data).value

                policy_types.append(policy_types_item)

        required_assessment_types: Union[Unset, List[str]] = UNSET
        if not isinstance(self.required_assessment_types, Unset):
            required_assessment_types = []
            for required_assessment_types_item_data in self.required_assessment_types:
                required_assessment_types_item = RequiredSourceType.from_val(required_assessment_types_item_data).value

                required_assessment_types.append(required_assessment_types_item)

        requirements: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.requirements, Unset):
            requirements = []
            for requirements_item_data in self.requirements:
                requirements_item = requirements_item_data.to_dict()

                requirements.append(requirements_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "category": category,
                "id": id,
                "name": name,
            }
        )
        if configuration_source is not UNSET:
            field_dict["configuration_source"] = configuration_source
        if description is not UNSET:
            field_dict["description"] = description
        if policy_types is not UNSET:
            field_dict["policy_types"] = policy_types
        if required_assessment_types is not UNSET:
            field_dict["required_assessment_types"] = required_assessment_types
        if requirements is not UNSET:
            field_dict["requirements"] = requirements

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.global_requirement import GlobalRequirement

        d = src_dict.copy()
        category = d.pop("category")

        id = d.pop("id")

        name = d.pop("name")

        _configuration_source = d.pop("configuration_source", UNSET)
        configuration_source: Union[Unset, PolicyConfigurationSource]
        if isinstance(_configuration_source, Unset):
            configuration_source = UNSET
        else:
            configuration_source = PolicyConfigurationSource.from_val(_configuration_source)

        description = d.pop("description", UNSET)

        _policy_types = d.pop("policy_types", UNSET)
        if (_policy_types) is UNSET:
            policy_types = UNSET
        else:
            if _policy_types:
                policy_types = []
                for policy_types_item_data in _policy_types:
                    policy_types_item = PolicyType.from_val(policy_types_item_data)

                    policy_types.append(policy_types_item)
            else:
                policy_types = []

        _required_assessment_types = d.pop("required_assessment_types", UNSET)
        if (_required_assessment_types) is UNSET:
            required_assessment_types = UNSET
        else:
            if _required_assessment_types:
                required_assessment_types = []
                for required_assessment_types_item_data in _required_assessment_types:
                    required_assessment_types_item = RequiredSourceType.from_val(required_assessment_types_item_data)

                    required_assessment_types.append(required_assessment_types_item)
            else:
                required_assessment_types = []

        _requirements = d.pop("requirements", UNSET)
        if (_requirements) is UNSET:
            requirements = UNSET
        else:
            if _requirements:
                requirements = []
                for requirements_item_data in _requirements:
                    requirements_item = GlobalRequirement.from_dict(requirements_item_data)

                    requirements.append(requirements_item)
            else:
                requirements = []

        global_policy = cls(
            category=category,
            id=id,
            name=name,
            configuration_source=configuration_source,
            description=description,
            policy_types=policy_types,
            required_assessment_types=required_assessment_types,
            requirements=requirements,
        )

        global_policy.additional_properties = d
        return global_policy

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
