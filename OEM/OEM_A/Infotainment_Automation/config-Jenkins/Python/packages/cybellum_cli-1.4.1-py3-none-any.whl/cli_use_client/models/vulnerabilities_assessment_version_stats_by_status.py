from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar

import attr

if TYPE_CHECKING:
    from ..models.vulnerabilities_assessment_version_stats_by_status_additional_property import (
        VulnerabilitiesAssessmentVersionStatsByStatusAdditionalProperty,
    )


T = TypeVar("T", bound="VulnerabilitiesAssessmentVersionStatsByStatus")


@attr.s(auto_attribs=True)
class VulnerabilitiesAssessmentVersionStatsByStatus:
    """A dictionary of status - severity seperation of the vulnerabilities of the assessment version"""

    additional_properties: Dict[str, "VulnerabilitiesAssessmentVersionStatsByStatusAdditionalProperty"] = attr.ib(
        init=False, factory=dict
    )

    def to_dict(self) -> Dict[str, Any]:
        pass

        field_dict: Dict[str, Any] = {}
        for prop_name, prop in self.additional_properties.items():
            field_dict[prop_name] = prop.to_dict()

        field_dict.update({})

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.vulnerabilities_assessment_version_stats_by_status_additional_property import (
            VulnerabilitiesAssessmentVersionStatsByStatusAdditionalProperty,
        )

        d = src_dict.copy()
        vulnerabilities_assessment_version_stats_by_status = cls()

        additional_properties = {}
        for prop_name, prop_dict in d.items():
            additional_property = VulnerabilitiesAssessmentVersionStatsByStatusAdditionalProperty.from_dict(prop_dict)

            additional_properties[prop_name] = additional_property

        vulnerabilities_assessment_version_stats_by_status.additional_properties = additional_properties
        return vulnerabilities_assessment_version_stats_by_status

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> "VulnerabilitiesAssessmentVersionStatsByStatusAdditionalProperty":
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: "VulnerabilitiesAssessmentVersionStatsByStatusAdditionalProperty") -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
