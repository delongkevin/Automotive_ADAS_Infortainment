from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin import DigitalTwin


T = TypeVar("T", bound="CreateDigitalTwinSuccessData")


@attr.s(auto_attribs=True)
class CreateDigitalTwinSuccessData:
    """
    Attributes:
        dt (Union[Unset, DigitalTwin]): Digital twin
    """

    dt: Union[Unset, "DigitalTwin"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        dt: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.dt, Unset):
            dt = self.dt.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if dt is not UNSET:
            field_dict["dt"] = dt

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin import DigitalTwin

        d = src_dict.copy()
        _dt = d.pop("dt", UNSET)
        dt: Union[Unset, DigitalTwin]
        if isinstance(_dt, Unset):
            dt = UNSET
        else:
            dt = DigitalTwin.from_dict(_dt)

        create_digital_twin_success_data = cls(
            dt=dt,
        )

        create_digital_twin_success_data.additional_properties = d
        return create_digital_twin_success_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
