from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.package_cpe_type import PackageCPEType
from ..models.package_cpe_validity import PackageCPEValidity
from ..types import UNSET, Unset

T = TypeVar("T", bound="PackageCPE")


@attr.s(auto_attribs=True)
class PackageCPE:
    """Package CPE

    Attributes:
        primary (Union[Unset, bool]): Is CPE primary
        product (Union[Unset, str]): CPE product
        text (Union[Unset, str]): CPE full text
        type (Union[Unset, PackageCPEType]): CPE type: "a" - application, "h" - hardware, "o" - operating system, "k" -
            kernel"
        validity (Union[Unset, PackageCPEValidity]): Is CPE valid
        vendor (Union[Unset, str]): CPE vendor
    """

    primary: Union[Unset, bool] = UNSET
    product: Union[Unset, str] = UNSET
    text: Union[Unset, str] = UNSET
    type: Union[Unset, PackageCPEType] = UNSET
    validity: Union[Unset, PackageCPEValidity] = UNSET
    vendor: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        primary = self.primary
        product = self.product
        text = self.text
        type: Union[Unset, str] = UNSET
        if not isinstance(self.type, Unset):
            type = PackageCPEType.from_val(self.type).value

        validity: Union[Unset, str] = UNSET
        if not isinstance(self.validity, Unset):
            validity = PackageCPEValidity.from_val(self.validity).value

        vendor = self.vendor

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if primary is not UNSET:
            field_dict["primary"] = primary
        if product is not UNSET:
            field_dict["product"] = product
        if text is not UNSET:
            field_dict["text"] = text
        if type is not UNSET:
            field_dict["type"] = type
        if validity is not UNSET:
            field_dict["validity"] = validity
        if vendor is not UNSET:
            field_dict["vendor"] = vendor

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        primary = d.pop("primary", UNSET)

        product = d.pop("product", UNSET)

        text = d.pop("text", UNSET)

        _type = d.pop("type", UNSET)
        type: Union[Unset, PackageCPEType]
        if isinstance(_type, Unset):
            type = UNSET
        else:
            type = PackageCPEType.from_val(_type)

        _validity = d.pop("validity", UNSET)
        validity: Union[Unset, PackageCPEValidity]
        if isinstance(_validity, Unset):
            validity = UNSET
        else:
            validity = PackageCPEValidity.from_val(_validity)

        vendor = d.pop("vendor", UNSET)

        package_cpe = cls(
            primary=primary,
            product=product,
            text=text,
            type=type,
            validity=validity,
            vendor=vendor,
        )

        package_cpe.additional_properties = d
        return package_cpe

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
