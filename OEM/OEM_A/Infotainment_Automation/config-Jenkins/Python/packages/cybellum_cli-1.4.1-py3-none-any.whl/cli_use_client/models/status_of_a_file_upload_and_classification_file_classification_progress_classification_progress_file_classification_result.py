from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_file_classification_result_unrecoverable_errors_item import (
        StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResultUnrecoverableErrorsItem,
    )


T = TypeVar(
    "T",
    bound="StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResult",
)


@attr.s(auto_attribs=True)
class StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResult:
    """
    Attributes:
        document_type (Union[Unset, str]): "cyclonedx", "spdx", "cpe" or "other"
        document_type_version (Union[Unset, str]): Document type version (for example this might be "1.4" for a
            CycloneDX document)
        file_path (Union[Unset, str]): File path for uploaded file
        unrecoverable_errors (Union[Unset, List['StatusOfAFileUploadAndClassificationFileClassificationProgressClassific
            ationProgressFileClassificationResultUnrecoverableErrorsItem']]): List of unrecoverable errors
    """

    document_type: Union[Unset, str] = UNSET
    document_type_version: Union[Unset, str] = UNSET
    file_path: Union[Unset, str] = UNSET
    unrecoverable_errors: Union[
        Unset,
        List[
            "StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResultUnrecoverableErrorsItem"
        ],
    ] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        document_type = self.document_type
        document_type_version = self.document_type_version
        file_path = self.file_path
        unrecoverable_errors: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.unrecoverable_errors, Unset):
            unrecoverable_errors = []
            for unrecoverable_errors_item_data in self.unrecoverable_errors:
                unrecoverable_errors_item = unrecoverable_errors_item_data.to_dict()

                unrecoverable_errors.append(unrecoverable_errors_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if document_type is not UNSET:
            field_dict["document_type"] = document_type
        if document_type_version is not UNSET:
            field_dict["document_type_version"] = document_type_version
        if file_path is not UNSET:
            field_dict["file_path"] = file_path
        if unrecoverable_errors is not UNSET:
            field_dict["unrecoverable_errors"] = unrecoverable_errors

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_file_classification_result_unrecoverable_errors_item import (
            StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResultUnrecoverableErrorsItem,
        )

        d = src_dict.copy()
        document_type = d.pop("document_type", UNSET)

        document_type_version = d.pop("document_type_version", UNSET)

        file_path = d.pop("file_path", UNSET)

        _unrecoverable_errors = d.pop("unrecoverable_errors", UNSET)
        if (_unrecoverable_errors) is UNSET:
            unrecoverable_errors = UNSET
        else:
            if _unrecoverable_errors:
                unrecoverable_errors = []
                for unrecoverable_errors_item_data in _unrecoverable_errors:
                    unrecoverable_errors_item = StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressFileClassificationResultUnrecoverableErrorsItem.from_dict(
                        unrecoverable_errors_item_data
                    )

                    unrecoverable_errors.append(unrecoverable_errors_item)
            else:
                unrecoverable_errors = []

        status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_file_classification_result = cls(
            document_type=document_type,
            document_type_version=document_type_version,
            file_path=file_path,
            unrecoverable_errors=unrecoverable_errors,
        )

        status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_file_classification_result.additional_properties = (
            d
        )
        return status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_file_classification_result

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
