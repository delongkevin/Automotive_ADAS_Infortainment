from io import BytesIO
from typing import TYPE_CHECKING, Any, Dict, List, Tuple, Type, TypeVar, Union, cast

import attr

from ..client import flatten_params
from ..models.dt_creation_types import DtCreationTypes
from ..types import UNSET, File, FileJsonType, Unset

if TYPE_CHECKING:
    from ..models.digital_twin_creation_payload_custom_fields import DigitalTwinCreationPayloadCustomFields
    from ..models.digital_twin_version_creation_base import DigitalTwinVersionCreationBase
    from ..models.private_configurations import PrivateConfigurations


T = TypeVar("T", bound="DigitalTwinCreationPayload")


@attr.s(auto_attribs=True)
class DigitalTwinCreationPayload:
    """Digital twin creation payload.
    There are 4 schemas for specifying information about files. Use only one of these.
    If passed more than 1 it will be selected the first one of this in the following order
    - file_ids
    - resumable_identifiers
    - urls
    - files

        Attributes:
            name (str): the name of the digital twin
            version_info (DigitalTwinVersionCreationBase): Digital twin version creation base
            auto_fix_import_issues (Union[Unset, bool]): Automatically fix errors when importing from an SBOM format file
                (CycloneDX, SPDX or CPE CVEs)
            business_unit (Union[Unset, str]): the business unit of the product
            cal (Union[Unset, int]): Cybersecurity Assurance Level
            client (Union[Unset, str]): the client of the product
            component_category (Union[Unset, str]): the component category of the digital twin

                for Vehicle Edition - the default possible values are:

                - adas
                - gateway
                - infotainment
                - power_steering
                - telecommunication
                - telematics
                - transmission_control_unit
                - key_fob
                - mobile_application_automotive
                - obd2_dongle
                - connected_ecu

                for Medical Edition - the default possible values are:

                - home_care_device
                - medical_imaging_system
                - other_medical_device
                - implantable_device
                - defibrillator
                - pacemaker
                - ventricular_assist_device
                - brain_stimulator
                - dialysis_device
                - infusion_insulin_pump
                - mobile_application_medical

                for IOT Edition - the default possible values are:

                - smart_home_device
                - smart_meter
                - energy_control_system
                - ip_camera
                - industrial_robot
                - mobile_application_iot
                - network_device
                - other_iot_device
                - storage_device
                - server
                - printer
                - pbx

                for Scanner - the default possible values are:

                - connected_component

                for all editions values can be customized by configuration
            creation_type (Union[Unset, DtCreationTypes]): The creation type of the digital twin version.  For
                "create_from_firmware" you can specify multiple files via the "urls", "files", "file_ids" or
                "resumable_identifiers" parameters.  For "create_manually" you should not specify any files and for all other
                creation types you should specify exactly one file.  You can use "import_from_sbom_file" to create a DT version
                from either a CycloneDX, SPDX or "CPE CVEs" list.  You can use "import_based_on_file_classification" to create a
                DT version from either a single binary/firmware file or from an SBOM format file (CycloneDX, SPDX or "CPE CVEs"
                list). You can use "create_from_source_code" you can specify multiple source code sources via the "urls",
                "files", "file_ids" or "resumable_identifiers" parameters.
            custom_fields (Union[Unset, DigitalTwinCreationPayloadCustomFields]): Custom Fields
            description (Union[Unset, str]): the digital twin description
            external_id (Union[Unset, str]):
            file_ids (Union[Unset, List[str]]): Each entry in the list is a unique identifier for an uploaded file. This
                value should match the identifier used for the file upload, either the "resumableIdentifier" value used for
                "Upload a resumable file", or the "file_id" value used for "Upload file from URL".
            files (Union[File, List[File], Unset]): files to upload for the DT created version
            gitlog_archive_file (Union[Unset, File]): the git log archive file
            micro_controller (Union[Unset, bool]): set to true if the product is a micro-controller - otherwise false by
                default.
            model_name (Union[Unset, str]): the model name of the product
            part_number (Union[Unset, str]): the part number of the product
            private_configurations (Union[Unset, PrivateConfigurations]): Private configurations
            resumable_gitlog_identifier (Union[Unset, str]): resumable upload gitlog file identifier
            resumable_identifiers (Union[Unset, List[str]]): resumable upload file identifiers
            resumable_session_id (Union[Unset, str]): resumable upload session id
            tags (Union[Unset, List[str]]): relevant tags for the dt
            urls (Union[Unset, List[str]]): files to upload from a URL to the DT - in case this field is set the system will
                ignore the 'files' parameter. otherwise it will look for the files in the 'files' parameter
            vendor (Union[Unset, str]): the vendor of the product
            workflow_id (Union[Unset, str]): ID
    """

    name: str
    version_info: "DigitalTwinVersionCreationBase"
    auto_fix_import_issues: Union[Unset, bool] = UNSET
    business_unit: Union[Unset, str] = UNSET
    cal: Union[Unset, int] = UNSET
    client: Union[Unset, str] = UNSET
    component_category: Union[Unset, str] = UNSET
    creation_type: Union[Unset, DtCreationTypes] = UNSET
    custom_fields: Union[Unset, "DigitalTwinCreationPayloadCustomFields"] = UNSET
    description: Union[Unset, str] = UNSET
    external_id: Union[Unset, str] = UNSET
    file_ids: Union[Unset, List[str]] = UNSET
    files: Union[File, List[File], Unset] = UNSET
    gitlog_archive_file: Union[Unset, File] = UNSET
    micro_controller: Union[Unset, bool] = UNSET
    model_name: Union[Unset, str] = UNSET
    part_number: Union[Unset, str] = UNSET
    private_configurations: Union[Unset, "PrivateConfigurations"] = UNSET
    resumable_gitlog_identifier: Union[Unset, str] = UNSET
    resumable_identifiers: Union[Unset, List[str]] = UNSET
    resumable_session_id: Union[Unset, str] = UNSET
    tags: Union[Unset, List[str]] = UNSET
    urls: Union[Unset, List[str]] = UNSET
    vendor: Union[Unset, str] = UNSET
    workflow_id: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        name = self.name
        version_info = self.version_info.to_dict()

        auto_fix_import_issues = self.auto_fix_import_issues
        business_unit = self.business_unit
        cal = self.cal
        client = self.client
        component_category = self.component_category
        creation_type: Union[Unset, str] = UNSET
        if not isinstance(self.creation_type, Unset):
            creation_type = DtCreationTypes.from_val(self.creation_type).value

        custom_fields: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        description = self.description
        external_id = self.external_id
        file_ids: Union[Unset, List[str]] = UNSET
        if not isinstance(self.file_ids, Unset):
            file_ids = self.file_ids

        files: Union[FileJsonType, List[FileJsonType], Unset]
        if isinstance(self.files, Unset):
            files = UNSET

        elif isinstance(self.files, File):
            files = UNSET
            if not isinstance(self.files, Unset):
                files = self.files.to_tuple()

        else:
            files = UNSET
            if not isinstance(self.files, Unset):
                files = []
                for files_type_1_item_data in self.files:
                    files_type_1_item = files_type_1_item_data.to_tuple()

                    files.append(files_type_1_item)

        gitlog_archive_file: Union[Unset, FileJsonType] = UNSET
        if not isinstance(self.gitlog_archive_file, Unset):
            gitlog_archive_file = self.gitlog_archive_file.to_tuple()

        micro_controller = self.micro_controller
        model_name = self.model_name
        part_number = self.part_number
        private_configurations: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.private_configurations, Unset):
            private_configurations = self.private_configurations.to_dict()

        resumable_gitlog_identifier = self.resumable_gitlog_identifier
        resumable_identifiers: Union[Unset, List[str]] = UNSET
        if not isinstance(self.resumable_identifiers, Unset):
            resumable_identifiers = self.resumable_identifiers

        resumable_session_id = self.resumable_session_id
        tags: Union[Unset, List[str]] = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        urls: Union[Unset, List[str]] = UNSET
        if not isinstance(self.urls, Unset):
            urls = self.urls

        vendor = self.vendor
        workflow_id = self.workflow_id

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "version_info": version_info,
            }
        )
        if auto_fix_import_issues is not UNSET:
            field_dict["auto_fix_import_issues"] = auto_fix_import_issues
        if business_unit is not UNSET:
            field_dict["business_unit"] = business_unit
        if cal is not UNSET:
            field_dict["cal"] = cal
        if client is not UNSET:
            field_dict["client"] = client
        if component_category is not UNSET:
            field_dict["component_category"] = component_category
        if creation_type is not UNSET:
            field_dict["creation_type"] = creation_type
        if custom_fields is not UNSET:
            field_dict["custom_fields"] = custom_fields
        if description is not UNSET:
            field_dict["description"] = description
        if external_id is not UNSET:
            field_dict["external_id"] = external_id
        if file_ids is not UNSET:
            field_dict["file_ids"] = file_ids
        if files is not UNSET:
            field_dict["files"] = files
        if gitlog_archive_file is not UNSET:
            field_dict["gitlog_archive_file"] = gitlog_archive_file
        if micro_controller is not UNSET:
            field_dict["micro_controller"] = micro_controller
        if model_name is not UNSET:
            field_dict["model_name"] = model_name
        if part_number is not UNSET:
            field_dict["part_number"] = part_number
        if private_configurations is not UNSET:
            field_dict["private_configurations"] = private_configurations
        if resumable_gitlog_identifier is not UNSET:
            field_dict["resumable_gitlog_identifier"] = resumable_gitlog_identifier
        if resumable_identifiers is not UNSET:
            field_dict["resumable_identifiers"] = resumable_identifiers
        if resumable_session_id is not UNSET:
            field_dict["resumable_session_id"] = resumable_session_id
        if tags is not UNSET:
            field_dict["tags"] = tags
        if urls is not UNSET:
            field_dict["urls"] = urls
        if vendor is not UNSET:
            field_dict["vendor"] = vendor
        if workflow_id is not UNSET:
            field_dict["workflow_id"] = workflow_id

        return field_dict

    def to_multipart(self) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        self_dict = self.to_dict()
        self_dict = flatten_params(self_dict)
        data = {
            key: value
            for key, value in self_dict.items()
            if value is not None and value is not UNSET and not isinstance(value, File) and not isinstance(value, Tuple)
        }
        files = {
            key: value.to_tuple() if isinstance(value, File) else value
            for key, value in self_dict.items()
            if value is not None and value is not UNSET and (isinstance(value, File) or isinstance(value, Tuple))
        }
        return (data, files)

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin_creation_payload_custom_fields import DigitalTwinCreationPayloadCustomFields
        from ..models.digital_twin_version_creation_base import DigitalTwinVersionCreationBase
        from ..models.private_configurations import PrivateConfigurations

        d = src_dict.copy()
        name = d.pop("name")

        version_info = DigitalTwinVersionCreationBase.from_dict(d.pop("version_info"))

        auto_fix_import_issues = d.pop("auto_fix_import_issues", UNSET)

        business_unit = d.pop("business_unit", UNSET)

        cal = d.pop("cal", UNSET)

        client = d.pop("client", UNSET)

        component_category = d.pop("component_category", UNSET)

        _creation_type = d.pop("creation_type", UNSET)
        creation_type: Union[Unset, DtCreationTypes]
        if isinstance(_creation_type, Unset):
            creation_type = UNSET
        else:
            creation_type = DtCreationTypes.from_val(_creation_type)

        _custom_fields = d.pop("custom_fields", UNSET)
        custom_fields: Union[Unset, DigitalTwinCreationPayloadCustomFields]
        if isinstance(_custom_fields, Unset):
            custom_fields = UNSET
        else:
            custom_fields = DigitalTwinCreationPayloadCustomFields.from_dict(_custom_fields)

        description = d.pop("description", UNSET)

        external_id = d.pop("external_id", UNSET)

        file_ids = cast(List[str], d.pop("file_ids", UNSET))

        def _parse_files(data: object) -> Union[File, List[File], Unset]:
            if isinstance(data, Unset):
                return data
            try:
                if not (isinstance(data, bytes) or isinstance(data, File)):
                    raise TypeError()
                _files_type_0 = data
                files_type_0: Union[Unset, File]

                if isinstance(_files_type_0, Unset):
                    files_type_0 = UNSET
                elif isinstance(_files_type_0, File):
                    files_type_0 = _files_type_0
                else:
                    files_type_0 = File(payload=BytesIO(_files_type_0))

                return files_type_0
            except:  # noqa: E722
                pass
            if not isinstance(data, list):
                raise TypeError()
            _files_type_1 = data
            if (_files_type_1) is UNSET:
                files_type_1 = UNSET
            else:
                if _files_type_1:
                    files_type_1 = []
                    for files_type_1_item_data in _files_type_1:
                        _files_type_1_item = files_type_1_item_data
                        files_type_1_item: File

                        if isinstance(_files_type_1_item, File):
                            files_type_1_item = _files_type_1_item
                        else:
                            files_type_1_item = File(payload=BytesIO(_files_type_1_item))

                        files_type_1.append(files_type_1_item)
                else:
                    files_type_1 = UNSET

            return files_type_1

        files = _parse_files(d.pop("files", UNSET))

        _gitlog_archive_file = d.pop("gitlog_archive_file", UNSET)
        gitlog_archive_file: Union[Unset, File]

        if isinstance(_gitlog_archive_file, Unset):
            gitlog_archive_file = UNSET
        elif isinstance(_gitlog_archive_file, File):
            gitlog_archive_file = _gitlog_archive_file
        else:
            gitlog_archive_file = File(payload=BytesIO(_gitlog_archive_file))

        micro_controller = d.pop("micro_controller", UNSET)

        model_name = d.pop("model_name", UNSET)

        part_number = d.pop("part_number", UNSET)

        _private_configurations = d.pop("private_configurations", UNSET)
        private_configurations: Union[Unset, PrivateConfigurations]
        if isinstance(_private_configurations, Unset):
            private_configurations = UNSET
        else:
            private_configurations = PrivateConfigurations.from_dict(_private_configurations)

        resumable_gitlog_identifier = d.pop("resumable_gitlog_identifier", UNSET)

        resumable_identifiers = cast(List[str], d.pop("resumable_identifiers", UNSET))

        resumable_session_id = d.pop("resumable_session_id", UNSET)

        tags = cast(List[str], d.pop("tags", UNSET))

        urls = cast(List[str], d.pop("urls", UNSET))

        vendor = d.pop("vendor", UNSET)

        workflow_id = d.pop("workflow_id", UNSET)

        digital_twin_creation_payload = cls(
            name=name,
            version_info=version_info,
            auto_fix_import_issues=auto_fix_import_issues,
            business_unit=business_unit,
            cal=cal,
            client=client,
            component_category=component_category,
            creation_type=creation_type,
            custom_fields=custom_fields,
            description=description,
            external_id=external_id,
            file_ids=file_ids,
            files=files,
            gitlog_archive_file=gitlog_archive_file,
            micro_controller=micro_controller,
            model_name=model_name,
            part_number=part_number,
            private_configurations=private_configurations,
            resumable_gitlog_identifier=resumable_gitlog_identifier,
            resumable_identifiers=resumable_identifiers,
            resumable_session_id=resumable_session_id,
            tags=tags,
            urls=urls,
            vendor=vendor,
            workflow_id=workflow_id,
        )

        digital_twin_creation_payload.additional_properties = d
        return digital_twin_creation_payload

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
