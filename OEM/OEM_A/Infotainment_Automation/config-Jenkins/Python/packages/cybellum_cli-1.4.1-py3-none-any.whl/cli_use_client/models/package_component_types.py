from enum import IntEnum
from typing import Union


class PackageComponentTypes(IntEnum):
    VALUE_1 = 1
    VALUE_2 = 2
    VALUE_3 = 3
    VALUE_4 = 4
    VALUE_5 = 5
    VALUE_6 = 6
    VALUE_7 = 7
    VALUE_8 = 8
    VALUE_9 = 9
    VALUE_10 = 10
    VALUE_11 = 11
    VALUE_12 = 12

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[int, str, "PackageComponentTypes"]) -> "PackageComponentTypes":
        if isinstance(value, PackageComponentTypes):
            return value

        if isinstance(value, str):
            value = value.lower()
            for key in cls.__members__.keys():
                if key.lower() == value:
                    return cls[key]

            # try to convert value to int
            try:
                value = int(value)
            except ValueError:
                pass

        return cls(value)
