from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.errors_for_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item import (
        ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItem,
    )
    from ..models.errors_for_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_remove_object_fix import (
        ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemRemoveObjectFix,
    )


T = TypeVar("T", bound="ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItem")


@attr.s(auto_attribs=True)
class ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItem:
    """
    Attributes:
        errors (Union[Unset,
            List['ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItem']]):
        location (Union[Unset, str]):
        name (Union[Unset, str]):
        remove_object_fix (Union[Unset,
            ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemRemoveObjectFix]):
        type (Union[Unset, str]): "package" or "cpe"
        version (Union[Unset, str]):
    """

    errors: Union[Unset, List["ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItem"]] = (
        UNSET
    )
    location: Union[Unset, str] = UNSET
    name: Union[Unset, str] = UNSET
    remove_object_fix: Union[
        Unset, "ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemRemoveObjectFix"
    ] = UNSET
    type: Union[Unset, str] = UNSET
    version: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        errors: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.errors, Unset):
            errors = []
            for errors_item_data in self.errors:
                errors_item = errors_item_data.to_dict()

                errors.append(errors_item)

        location = self.location
        name = self.name
        remove_object_fix: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.remove_object_fix, Unset):
            remove_object_fix = self.remove_object_fix.to_dict()

        type = self.type
        version = self.version

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if errors is not UNSET:
            field_dict["errors"] = errors
        if location is not UNSET:
            field_dict["location"] = location
        if name is not UNSET:
            field_dict["name"] = name
        if remove_object_fix is not UNSET:
            field_dict["remove_object_fix"] = remove_object_fix
        if type is not UNSET:
            field_dict["type"] = type
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.errors_for_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item import (
            ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItem,
        )
        from ..models.errors_for_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_remove_object_fix import (
            ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemRemoveObjectFix,
        )

        d = src_dict.copy()
        _errors = d.pop("errors", UNSET)
        if (_errors) is UNSET:
            errors = UNSET
        else:
            if _errors:
                errors = []
                for errors_item_data in _errors:
                    errors_item = (
                        ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItem.from_dict(
                            errors_item_data
                        )
                    )

                    errors.append(errors_item)
            else:
                errors = []

        location = d.pop("location", UNSET)

        name = d.pop("name", UNSET)

        _remove_object_fix = d.pop("remove_object_fix", UNSET)
        remove_object_fix: Union[
            Unset, ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemRemoveObjectFix
        ]
        if isinstance(_remove_object_fix, Unset):
            remove_object_fix = UNSET
        else:
            remove_object_fix = (
                ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemRemoveObjectFix.from_dict(
                    _remove_object_fix
                )
            )

        type = d.pop("type", UNSET)

        version = d.pop("version", UNSET)

        errors_for_an_sbom_document_analysis_document_analysis_result_invalid_objects_item = cls(
            errors=errors,
            location=location,
            name=name,
            remove_object_fix=remove_object_fix,
            type=type,
            version=version,
        )

        errors_for_an_sbom_document_analysis_document_analysis_result_invalid_objects_item.additional_properties = d
        return errors_for_an_sbom_document_analysis_document_analysis_result_invalid_objects_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
