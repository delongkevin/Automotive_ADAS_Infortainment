from typing import Any, Dict, List, Type, TypeVar

import attr

T = TypeVar("T", bound="SendMessageToConversationJsonBody")


@attr.s(auto_attribs=True)
class SendMessageToConversationJsonBody:
    """
    Attributes:
        conversation_id (str): ID
        message (str): The content of the message being sent to the conversation.
    """

    conversation_id: str
    message: str
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        conversation_id = self.conversation_id
        message = self.message

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "conversation_id": conversation_id,
                "message": message,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        conversation_id = d.pop("conversation_id")

        message = d.pop("message")

        send_message_to_conversation_json_body = cls(
            conversation_id=conversation_id,
            message=message,
        )

        send_message_to_conversation_json_body.additional_properties = d
        return send_message_to_conversation_json_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
