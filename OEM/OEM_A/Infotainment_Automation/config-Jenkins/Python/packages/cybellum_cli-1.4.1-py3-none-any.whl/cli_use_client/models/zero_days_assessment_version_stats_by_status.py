from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar

import attr

if TYPE_CHECKING:
    from ..models.zero_days_assessment_version_stats_by_status_additional_property import (
        ZeroDaysAssessmentVersionStatsByStatusAdditionalProperty,
    )


T = TypeVar("T", bound="ZeroDaysAssessmentVersionStatsByStatus")


@attr.s(auto_attribs=True)
class ZeroDaysAssessmentVersionStatsByStatus:
    """A dictionary of status - severity seperation of the vulnerabilities of the assessment version"""

    additional_properties: Dict[str, "ZeroDaysAssessmentVersionStatsByStatusAdditionalProperty"] = attr.ib(
        init=False, factory=dict
    )

    def to_dict(self) -> Dict[str, Any]:
        pass

        field_dict: Dict[str, Any] = {}
        for prop_name, prop in self.additional_properties.items():
            field_dict[prop_name] = prop.to_dict()

        field_dict.update({})

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.zero_days_assessment_version_stats_by_status_additional_property import (
            ZeroDaysAssessmentVersionStatsByStatusAdditionalProperty,
        )

        d = src_dict.copy()
        zero_days_assessment_version_stats_by_status = cls()

        additional_properties = {}
        for prop_name, prop_dict in d.items():
            additional_property = ZeroDaysAssessmentVersionStatsByStatusAdditionalProperty.from_dict(prop_dict)

            additional_properties[prop_name] = additional_property

        zero_days_assessment_version_stats_by_status.additional_properties = additional_properties
        return zero_days_assessment_version_stats_by_status

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> "ZeroDaysAssessmentVersionStatsByStatusAdditionalProperty":
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: "ZeroDaysAssessmentVersionStatsByStatusAdditionalProperty") -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
