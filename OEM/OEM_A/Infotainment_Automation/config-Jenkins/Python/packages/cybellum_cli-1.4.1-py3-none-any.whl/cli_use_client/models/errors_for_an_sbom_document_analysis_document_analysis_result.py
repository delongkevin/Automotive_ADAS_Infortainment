from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.errors_for_an_sbom_document_analysis_document_analysis_result_invalid_objects_item import (
        ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItem,
    )


T = TypeVar("T", bound="ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResult")


@attr.s(auto_attribs=True)
class ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResult:
    """
    Attributes:
        invalid_objects (Union[Unset, List['ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItem']]):
    """

    invalid_objects: Union[Unset, List["ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItem"]] = (
        UNSET
    )
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        invalid_objects: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.invalid_objects, Unset):
            invalid_objects = []
            for invalid_objects_item_data in self.invalid_objects:
                invalid_objects_item = invalid_objects_item_data.to_dict()

                invalid_objects.append(invalid_objects_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if invalid_objects is not UNSET:
            field_dict["invalid_objects"] = invalid_objects

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.errors_for_an_sbom_document_analysis_document_analysis_result_invalid_objects_item import (
            ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItem,
        )

        d = src_dict.copy()
        _invalid_objects = d.pop("invalid_objects", UNSET)
        if (_invalid_objects) is UNSET:
            invalid_objects = UNSET
        else:
            if _invalid_objects:
                invalid_objects = []
                for invalid_objects_item_data in _invalid_objects:
                    invalid_objects_item = (
                        ErrorsForAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItem.from_dict(
                            invalid_objects_item_data
                        )
                    )

                    invalid_objects.append(invalid_objects_item)
            else:
                invalid_objects = []

        errors_for_an_sbom_document_analysis_document_analysis_result = cls(
            invalid_objects=invalid_objects,
        )

        errors_for_an_sbom_document_analysis_document_analysis_result.additional_properties = d
        return errors_for_an_sbom_document_analysis_document_analysis_result

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
