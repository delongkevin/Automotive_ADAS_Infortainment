import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Type, TypeVar, Union, cast

import attr
from dateutil.parser import isoparse

from ..models.assessment_status import AssessmentStatus
from ..models.dt_user_permissions_item import DtUserPermissionsItem
from ..models.virtual_analyst_execution import VirtualAnalystExecution
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin import DigitalTwin
    from ..models.virtual_analyst_execution_metadata import VirtualAnalystExecutionMetadata
    from ..models.vulnerabilities_assessment_version import VulnerabilitiesAssessmentVersion
    from ..models.vulnerabilities_assessment_virtual_analyst_profile import (
        VulnerabilitiesAssessmentVirtualAnalystProfile,
    )


T = TypeVar("T", bound="VulnerabilitiesAssessment")


@attr.s(auto_attribs=True)
class VulnerabilitiesAssessment:
    """Vulnerabilities assessment

    Attributes:
        created_by (str): Assessment creator user id
        created_on (datetime.datetime): Assessment creation date
        dt_id (str): ID
        id (str): ID
        last_modified_on (str): Last time assessment was modified
        name (str): Assessment name
        cna_priority (Union[Unset, List[str]]):
        default_assessment_version (Union[Unset, None, VulnerabilitiesAssessmentVersion]): Vulnerabilities assessment
            version
        description (Union[Unset, str]): Assessment description
        dt (Union[Unset, DigitalTwin]): Digital twin
        dt_version_assessment_version (Optional[VulnerabilitiesAssessmentVersion]): Vulnerabilities assessment version
        end_date (Union[Unset, datetime.datetime]): Assessment end date
        monitored (Union[Unset, bool]): Indicator if the assessment is monitored
        start_date (Union[Unset, datetime.datetime]): Assessment start date
        status (Union[Unset, AssessmentStatus]): Status of the assessment
        status_reason (Union[Unset, str]): Status reason of the assessment
        user_dt_permissions (Union[Unset, List[DtUserPermissionsItem]]): Digital twin permissions Example: ['dt_work'].
        virtual_analyst_execution (Union[Unset, VirtualAnalystExecution]): Virtual analyst execution
        virtual_analyst_execution_metadata (Union[Unset, VirtualAnalystExecutionMetadata]): Virtual analyst execution
            metadata
        virtual_analyst_profile (Union[Unset, VulnerabilitiesAssessmentVirtualAnalystProfile]): Vulnerabilities
            assessment virtual analyst profile
    """

    created_by: str
    created_on: datetime.datetime
    dt_id: str
    id: str
    last_modified_on: str
    name: str
    dt_version_assessment_version: Optional["VulnerabilitiesAssessmentVersion"]
    cna_priority: Union[Unset, List[str]] = UNSET
    default_assessment_version: Union[Unset, None, "VulnerabilitiesAssessmentVersion"] = UNSET
    description: Union[Unset, str] = UNSET
    dt: Union[Unset, "DigitalTwin"] = UNSET
    end_date: Union[Unset, datetime.datetime] = UNSET
    monitored: Union[Unset, bool] = UNSET
    start_date: Union[Unset, datetime.datetime] = UNSET
    status: Union[Unset, AssessmentStatus] = UNSET
    status_reason: Union[Unset, str] = UNSET
    user_dt_permissions: Union[Unset, List[DtUserPermissionsItem]] = UNSET
    virtual_analyst_execution: Union[Unset, VirtualAnalystExecution] = UNSET
    virtual_analyst_execution_metadata: Union[Unset, "VirtualAnalystExecutionMetadata"] = UNSET
    virtual_analyst_profile: Union[Unset, "VulnerabilitiesAssessmentVirtualAnalystProfile"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        created_by = self.created_by
        created_on = self.created_on.isoformat()

        dt_id = self.dt_id
        id = self.id
        last_modified_on = self.last_modified_on
        name = self.name
        cna_priority: Union[Unset, List[str]] = UNSET
        if not isinstance(self.cna_priority, Unset):
            cna_priority = self.cna_priority

        default_assessment_version: Union[Unset, None, Dict[str, Any]] = UNSET
        if not isinstance(self.default_assessment_version, Unset):
            default_assessment_version = (
                self.default_assessment_version.to_dict() if self.default_assessment_version else None
            )

        description = self.description
        dt: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.dt, Unset):
            dt = self.dt.to_dict()

        dt_version_assessment_version = (
            self.dt_version_assessment_version.to_dict() if self.dt_version_assessment_version else None
        )

        end_date: Union[Unset, str] = UNSET
        if not isinstance(self.end_date, Unset):
            end_date = self.end_date.isoformat()

        monitored = self.monitored
        start_date: Union[Unset, str] = UNSET
        if not isinstance(self.start_date, Unset):
            start_date = self.start_date.isoformat()

        status: Union[Unset, str] = UNSET
        if not isinstance(self.status, Unset):
            status = AssessmentStatus.from_val(self.status).value

        status_reason = self.status_reason
        user_dt_permissions: Union[Unset, List[str]] = UNSET
        if not isinstance(self.user_dt_permissions, Unset):
            user_dt_permissions = []
            for componentsschemasdt_user_permissions_item_data in self.user_dt_permissions:
                componentsschemasdt_user_permissions_item = DtUserPermissionsItem.from_val(
                    componentsschemasdt_user_permissions_item_data
                ).value

                user_dt_permissions.append(componentsschemasdt_user_permissions_item)

        virtual_analyst_execution: Union[Unset, str] = UNSET
        if not isinstance(self.virtual_analyst_execution, Unset):
            virtual_analyst_execution = VirtualAnalystExecution.from_val(self.virtual_analyst_execution).value

        virtual_analyst_execution_metadata: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.virtual_analyst_execution_metadata, Unset):
            virtual_analyst_execution_metadata = self.virtual_analyst_execution_metadata.to_dict()

        virtual_analyst_profile: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.virtual_analyst_profile, Unset):
            virtual_analyst_profile = self.virtual_analyst_profile.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "created_by": created_by,
                "created_on": created_on,
                "dt_id": dt_id,
                "id": id,
                "last_modified_on": last_modified_on,
                "name": name,
                "dt_version_assessment_version": dt_version_assessment_version,
            }
        )
        if cna_priority is not UNSET:
            field_dict["cna_priority"] = cna_priority
        if default_assessment_version is not UNSET:
            field_dict["default_assessment_version"] = default_assessment_version
        if description is not UNSET:
            field_dict["description"] = description
        if dt is not UNSET:
            field_dict["dt"] = dt
        if end_date is not UNSET:
            field_dict["end_date"] = end_date
        if monitored is not UNSET:
            field_dict["monitored"] = monitored
        if start_date is not UNSET:
            field_dict["start_date"] = start_date
        if status is not UNSET:
            field_dict["status"] = status
        if status_reason is not UNSET:
            field_dict["status_reason"] = status_reason
        if user_dt_permissions is not UNSET:
            field_dict["user_dt_permissions"] = user_dt_permissions
        if virtual_analyst_execution is not UNSET:
            field_dict["virtual_analyst_execution"] = virtual_analyst_execution
        if virtual_analyst_execution_metadata is not UNSET:
            field_dict["virtual_analyst_execution_metadata"] = virtual_analyst_execution_metadata
        if virtual_analyst_profile is not UNSET:
            field_dict["virtual_analyst_profile"] = virtual_analyst_profile

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin import DigitalTwin
        from ..models.virtual_analyst_execution_metadata import VirtualAnalystExecutionMetadata
        from ..models.vulnerabilities_assessment_version import VulnerabilitiesAssessmentVersion
        from ..models.vulnerabilities_assessment_virtual_analyst_profile import (
            VulnerabilitiesAssessmentVirtualAnalystProfile,
        )

        d = src_dict.copy()
        created_by = d.pop("created_by")

        created_on = isoparse(d.pop("created_on"))

        dt_id = d.pop("dt_id")

        id = d.pop("id")

        last_modified_on = d.pop("last_modified_on")

        name = d.pop("name")

        cna_priority = cast(List[str], d.pop("cna_priority", UNSET))

        _default_assessment_version = d.pop("default_assessment_version", UNSET)
        default_assessment_version: Union[Unset, None, VulnerabilitiesAssessmentVersion]
        if _default_assessment_version is None:
            default_assessment_version = None
        elif isinstance(_default_assessment_version, Unset):
            default_assessment_version = UNSET
        else:
            default_assessment_version = VulnerabilitiesAssessmentVersion.from_dict(_default_assessment_version)

        description = d.pop("description", UNSET)

        _dt = d.pop("dt", UNSET)
        dt: Union[Unset, DigitalTwin]
        if isinstance(_dt, Unset):
            dt = UNSET
        else:
            dt = DigitalTwin.from_dict(_dt)

        _dt_version_assessment_version = d.pop("dt_version_assessment_version")
        dt_version_assessment_version: Optional[VulnerabilitiesAssessmentVersion]
        if _dt_version_assessment_version is None:
            dt_version_assessment_version = None
        else:
            dt_version_assessment_version = VulnerabilitiesAssessmentVersion.from_dict(_dt_version_assessment_version)

        _end_date = d.pop("end_date", UNSET)
        end_date: Union[Unset, datetime.datetime]
        if isinstance(_end_date, Unset):
            end_date = UNSET
        else:
            end_date = isoparse(_end_date)

        monitored = d.pop("monitored", UNSET)

        _start_date = d.pop("start_date", UNSET)
        start_date: Union[Unset, datetime.datetime]
        if isinstance(_start_date, Unset):
            start_date = UNSET
        else:
            start_date = isoparse(_start_date)

        _status = d.pop("status", UNSET)
        status: Union[Unset, AssessmentStatus]
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = AssessmentStatus.from_val(_status)

        status_reason = d.pop("status_reason", UNSET)

        _user_dt_permissions = d.pop("user_dt_permissions", UNSET)
        if (_user_dt_permissions) is UNSET:
            user_dt_permissions = UNSET
        else:
            if _user_dt_permissions:
                user_dt_permissions = []
                for componentsschemasdt_user_permissions_item_data in _user_dt_permissions:
                    componentsschemasdt_user_permissions_item = DtUserPermissionsItem.from_val(
                        componentsschemasdt_user_permissions_item_data
                    )

                    user_dt_permissions.append(componentsschemasdt_user_permissions_item)
            else:
                user_dt_permissions = []

        _virtual_analyst_execution = d.pop("virtual_analyst_execution", UNSET)
        virtual_analyst_execution: Union[Unset, VirtualAnalystExecution]
        if isinstance(_virtual_analyst_execution, Unset):
            virtual_analyst_execution = UNSET
        else:
            virtual_analyst_execution = VirtualAnalystExecution.from_val(_virtual_analyst_execution)

        _virtual_analyst_execution_metadata = d.pop("virtual_analyst_execution_metadata", UNSET)
        virtual_analyst_execution_metadata: Union[Unset, VirtualAnalystExecutionMetadata]
        if isinstance(_virtual_analyst_execution_metadata, Unset):
            virtual_analyst_execution_metadata = UNSET
        else:
            virtual_analyst_execution_metadata = VirtualAnalystExecutionMetadata.from_dict(
                _virtual_analyst_execution_metadata
            )

        _virtual_analyst_profile = d.pop("virtual_analyst_profile", UNSET)
        virtual_analyst_profile: Union[Unset, VulnerabilitiesAssessmentVirtualAnalystProfile]
        if isinstance(_virtual_analyst_profile, Unset):
            virtual_analyst_profile = UNSET
        else:
            virtual_analyst_profile = VulnerabilitiesAssessmentVirtualAnalystProfile.from_dict(_virtual_analyst_profile)

        vulnerabilities_assessment = cls(
            created_by=created_by,
            created_on=created_on,
            dt_id=dt_id,
            id=id,
            last_modified_on=last_modified_on,
            name=name,
            cna_priority=cna_priority,
            default_assessment_version=default_assessment_version,
            description=description,
            dt=dt,
            dt_version_assessment_version=dt_version_assessment_version,
            end_date=end_date,
            monitored=monitored,
            start_date=start_date,
            status=status,
            status_reason=status_reason,
            user_dt_permissions=user_dt_permissions,
            virtual_analyst_execution=virtual_analyst_execution,
            virtual_analyst_execution_metadata=virtual_analyst_execution_metadata,
            virtual_analyst_profile=virtual_analyst_profile,
        )

        vulnerabilities_assessment.additional_properties = d
        return vulnerabilities_assessment

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
