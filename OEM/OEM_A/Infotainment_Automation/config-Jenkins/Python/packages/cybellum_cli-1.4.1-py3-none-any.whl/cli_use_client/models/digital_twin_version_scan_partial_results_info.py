from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin_version_scan_partial_results_info_partial_info_types import (
        DigitalTwinVersionScanPartialResultsInfoPartialInfoTypes,
    )


T = TypeVar("T", bound="DigitalTwinVersionScanPartialResultsInfo")


@attr.s(auto_attribs=True)
class DigitalTwinVersionScanPartialResultsInfo:
    """partial results information in case the scan didn't return full results

    Attributes:
        partial_info_types (Union[Unset, DigitalTwinVersionScanPartialResultsInfoPartialInfoTypes]): the partial results
            for each information type
    """

    partial_info_types: Union[Unset, "DigitalTwinVersionScanPartialResultsInfoPartialInfoTypes"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        partial_info_types: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.partial_info_types, Unset):
            partial_info_types = self.partial_info_types.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if partial_info_types is not UNSET:
            field_dict["partial_info_types"] = partial_info_types

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin_version_scan_partial_results_info_partial_info_types import (
            DigitalTwinVersionScanPartialResultsInfoPartialInfoTypes,
        )

        d = src_dict.copy()
        _partial_info_types = d.pop("partial_info_types", UNSET)
        partial_info_types: Union[Unset, DigitalTwinVersionScanPartialResultsInfoPartialInfoTypes]
        if isinstance(_partial_info_types, Unset):
            partial_info_types = UNSET
        else:
            partial_info_types = DigitalTwinVersionScanPartialResultsInfoPartialInfoTypes.from_dict(_partial_info_types)

        digital_twin_version_scan_partial_results_info = cls(
            partial_info_types=partial_info_types,
        )

        digital_twin_version_scan_partial_results_info.additional_properties = d
        return digital_twin_version_scan_partial_results_info

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
