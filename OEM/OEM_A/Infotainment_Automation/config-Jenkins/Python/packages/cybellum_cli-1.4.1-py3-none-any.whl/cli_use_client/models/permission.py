from enum import Enum
from typing import Union


class Permission(str, Enum):
    PRODUCT_WORK = "product_work"

    PRODUCT_MANAGE = "product_manage"

    PRODUCT_VIEW = "product_view"

    PRODUCT_DELETE = "product_delete"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "Permission"]) -> "Permission":
        if isinstance(value, Permission):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return Permission(value)
