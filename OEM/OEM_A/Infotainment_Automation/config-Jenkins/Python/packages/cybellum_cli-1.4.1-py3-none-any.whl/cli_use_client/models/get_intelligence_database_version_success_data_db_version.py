import datetime
from typing import Any, Dict, List, Type, TypeVar

import attr
from dateutil.parser import isoparse

T = TypeVar("T", bound="GetIntelligenceDatabaseVersionSuccessDataDbVersion")


@attr.s(auto_attribs=True)
class GetIntelligenceDatabaseVersionSuccessDataDbVersion:
    """Database version

    Attributes:
        schema (str): The schema of the database
        version (datetime.date): A YYYY/MM/DD formatted version of the database
    """

    schema: str
    version: datetime.date
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        schema = self.schema
        version = self.version.isoformat()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "schema": schema,
                "version": version,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        schema = d.pop("schema")

        version = isoparse(d.pop("version")).date()

        get_intelligence_database_version_success_data_db_version = cls(
            schema=schema,
            version=version,
        )

        get_intelligence_database_version_success_data_db_version.additional_properties = d
        return get_intelligence_database_version_success_data_db_version

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
