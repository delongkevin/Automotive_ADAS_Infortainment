from enum import Enum
from typing import Union


class ScanSubState(str, Enum):
    PENDING_DEPENDENT_SCANS = "pending_dependent_scans"

    WAIT_MACHINE = "wait_machine"

    WAIT_ON_MACHINE = "wait_on_machine"

    EXTRACTING = "extracting"

    ANALYZING = "analyzing"

    PROCESSING = "processing"

    SUCCESS = "success"

    FAILURE = "failure"

    CANCELLED = "cancelled"

    PENDING_ANALYSIS = "pending_analysis"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "ScanSubState"]) -> "ScanSubState":
        if isinstance(value, ScanSubState):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return ScanSubState(value)
