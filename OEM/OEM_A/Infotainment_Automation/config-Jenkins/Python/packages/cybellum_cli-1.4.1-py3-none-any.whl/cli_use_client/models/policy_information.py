from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.policy_configuration_source import PolicyConfigurationSource
from ..types import UNSET, Unset

T = TypeVar("T", bound="PolicyInformation")


@attr.s(auto_attribs=True)
class PolicyInformation:
    """Policy information

    Attributes:
        category (str): Policy category
        id (str): Policy id
        name (str): Policy name
        configuration_source (Union[Unset, PolicyConfigurationSource]): Policy configuration source
        description (Union[Unset, str]): Policy description
    """

    category: str
    id: str
    name: str
    configuration_source: Union[Unset, PolicyConfigurationSource] = UNSET
    description: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        category = self.category
        id = self.id
        name = self.name
        configuration_source: Union[Unset, str] = UNSET
        if not isinstance(self.configuration_source, Unset):
            configuration_source = PolicyConfigurationSource.from_val(self.configuration_source).value

        description = self.description

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "category": category,
                "id": id,
                "name": name,
            }
        )
        if configuration_source is not UNSET:
            field_dict["configuration_source"] = configuration_source
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        category = d.pop("category")

        id = d.pop("id")

        name = d.pop("name")

        _configuration_source = d.pop("configuration_source", UNSET)
        configuration_source: Union[Unset, PolicyConfigurationSource]
        if isinstance(_configuration_source, Unset):
            configuration_source = UNSET
        else:
            configuration_source = PolicyConfigurationSource.from_val(_configuration_source)

        description = d.pop("description", UNSET)

        policy_information = cls(
            category=category,
            id=id,
            name=name,
            configuration_source=configuration_source,
            description=description,
        )

        policy_information.additional_properties = d
        return policy_information

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
