from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="AnalyzeDocumentJsonBody")


@attr.s(auto_attribs=True)
class AnalyzeDocumentJsonBody:
    """
    Attributes:
        file_id (str): ID
        autofix (Union[Unset, bool]): Apply all of the default fixes
    """

    file_id: str
    autofix: Union[Unset, bool] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        file_id = self.file_id
        autofix = self.autofix

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "file_id": file_id,
            }
        )
        if autofix is not UNSET:
            field_dict["autofix"] = autofix

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        file_id = d.pop("file_id")

        autofix = d.pop("autofix", UNSET)

        analyze_document_json_body = cls(
            file_id=file_id,
            autofix=autofix,
        )

        analyze_document_json_body.additional_properties = d
        return analyze_document_json_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
