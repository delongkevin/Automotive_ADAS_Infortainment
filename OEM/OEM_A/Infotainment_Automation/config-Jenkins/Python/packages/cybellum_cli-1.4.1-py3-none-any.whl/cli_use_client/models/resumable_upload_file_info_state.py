from enum import Enum
from typing import Union


class ResumableUploadFileInfoState(str, Enum):
    QUEUED = "queued"

    IN_PROGRESS = "in_progress"

    COMPLETED = "completed"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "ResumableUploadFileInfoState"]) -> "ResumableUploadFileInfoState":
        if isinstance(value, ResumableUploadFileInfoState):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return ResumableUploadFileInfoState(value)
