from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.propagation_strategy import PropagationStrategy
from ..types import UNSET, Unset

T = TypeVar("T", bound="InformationPropagationSbom")


@attr.s(auto_attribs=True)
class InformationPropagationSbom:
    """SBOM propagation configurations

    Attributes:
        strategy (Union[Unset, PropagationStrategy]): Propagation strategy
    """

    strategy: Union[Unset, PropagationStrategy] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        strategy: Union[Unset, str] = UNSET
        if not isinstance(self.strategy, Unset):
            strategy = PropagationStrategy.from_val(self.strategy).value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if strategy is not UNSET:
            field_dict["strategy"] = strategy

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _strategy = d.pop("strategy", UNSET)
        strategy: Union[Unset, PropagationStrategy]
        if isinstance(_strategy, Unset):
            strategy = UNSET
        else:
            strategy = PropagationStrategy.from_val(_strategy)

        information_propagation_sbom = cls(
            strategy=strategy,
        )

        information_propagation_sbom.additional_properties = d
        return information_propagation_sbom

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
