from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.resumable_upload_file_info_data_integration_data import ResumableUploadFileInfoDataIntegrationData


T = TypeVar("T", bound="ResumableUploadFileInfoData")


@attr.s(auto_attribs=True)
class ResumableUploadFileInfoData:
    """Resumable upload file info data

    Attributes:
        file_name (Union[Unset, str]): Resumable upload file name
        file_type (Union[Unset, str]): Resumable upload file type
        integration_data (Union[Unset, ResumableUploadFileInfoDataIntegrationData]): Resumable upload file integration
            data
        original_file_name (Union[Unset, str]): Resumable upload file original name
        original_file_url (Union[Unset, str]): Resumable upload file url
    """

    file_name: Union[Unset, str] = UNSET
    file_type: Union[Unset, str] = UNSET
    integration_data: Union[Unset, "ResumableUploadFileInfoDataIntegrationData"] = UNSET
    original_file_name: Union[Unset, str] = UNSET
    original_file_url: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        file_name = self.file_name
        file_type = self.file_type
        integration_data: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.integration_data, Unset):
            integration_data = self.integration_data.to_dict()

        original_file_name = self.original_file_name
        original_file_url = self.original_file_url

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if file_name is not UNSET:
            field_dict["file_name"] = file_name
        if file_type is not UNSET:
            field_dict["file_type"] = file_type
        if integration_data is not UNSET:
            field_dict["integration_data"] = integration_data
        if original_file_name is not UNSET:
            field_dict["original_file_name"] = original_file_name
        if original_file_url is not UNSET:
            field_dict["original_file_url"] = original_file_url

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.resumable_upload_file_info_data_integration_data import ResumableUploadFileInfoDataIntegrationData

        d = src_dict.copy()
        file_name = d.pop("file_name", UNSET)

        file_type = d.pop("file_type", UNSET)

        _integration_data = d.pop("integration_data", UNSET)
        integration_data: Union[Unset, ResumableUploadFileInfoDataIntegrationData]
        if isinstance(_integration_data, Unset):
            integration_data = UNSET
        else:
            integration_data = ResumableUploadFileInfoDataIntegrationData.from_dict(_integration_data)

        original_file_name = d.pop("original_file_name", UNSET)

        original_file_url = d.pop("original_file_url", UNSET)

        resumable_upload_file_info_data = cls(
            file_name=file_name,
            file_type=file_type,
            integration_data=integration_data,
            original_file_name=original_file_name,
            original_file_url=original_file_url,
        )

        resumable_upload_file_info_data.additional_properties = d
        return resumable_upload_file_info_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
