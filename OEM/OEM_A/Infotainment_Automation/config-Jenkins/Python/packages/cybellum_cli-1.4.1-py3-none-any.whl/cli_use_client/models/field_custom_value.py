import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..models.field_custom_value_entity import FieldCustomValueEntity
from ..models.field_custom_value_field import FieldCustomValueField
from ..models.field_custom_value_source import FieldCustomValueSource
from ..types import UNSET, Unset

T = TypeVar("T", bound="FieldCustomValue")


@attr.s(auto_attribs=True)
class FieldCustomValue:
    """Field Custom Value

    Attributes:
        created_by_user_id (Union[Unset, str]): The id of the user that created custom field if source is user
        created_on (Union[Unset, datetime.datetime]): The date when the field was created
        default (Union[Unset, bool]): Is the value default for the field
        entity (Union[Unset, FieldCustomValueEntity]): Field Custom Value Entity
        field (Union[Unset, FieldCustomValueField]): Field Custom Value Field
        id (Union[Unset, str]): Field ID
        source (Union[Unset, FieldCustomValueSource]): Field Custom Value Source
        value (Union[Unset, str]): Field Custom Value
    """

    created_by_user_id: Union[Unset, str] = UNSET
    created_on: Union[Unset, datetime.datetime] = UNSET
    default: Union[Unset, bool] = UNSET
    entity: Union[Unset, FieldCustomValueEntity] = UNSET
    field: Union[Unset, FieldCustomValueField] = UNSET
    id: Union[Unset, str] = UNSET
    source: Union[Unset, FieldCustomValueSource] = UNSET
    value: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        created_by_user_id = self.created_by_user_id
        created_on: Union[Unset, str] = UNSET
        if not isinstance(self.created_on, Unset):
            created_on = self.created_on.isoformat()

        default = self.default
        entity: Union[Unset, str] = UNSET
        if not isinstance(self.entity, Unset):
            entity = FieldCustomValueEntity.from_val(self.entity).value

        field: Union[Unset, str] = UNSET
        if not isinstance(self.field, Unset):
            field = FieldCustomValueField.from_val(self.field).value

        id = self.id
        source: Union[Unset, str] = UNSET
        if not isinstance(self.source, Unset):
            source = FieldCustomValueSource.from_val(self.source).value

        value = self.value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if created_by_user_id is not UNSET:
            field_dict["created_by_user_id"] = created_by_user_id
        if created_on is not UNSET:
            field_dict["created_on"] = created_on
        if default is not UNSET:
            field_dict["default"] = default
        if entity is not UNSET:
            field_dict["entity"] = entity
        if field is not UNSET:
            field_dict["field"] = field
        if id is not UNSET:
            field_dict["id"] = id
        if source is not UNSET:
            field_dict["source"] = source
        if value is not UNSET:
            field_dict["value"] = value

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        created_by_user_id = d.pop("created_by_user_id", UNSET)

        _created_on = d.pop("created_on", UNSET)
        created_on: Union[Unset, datetime.datetime]
        if isinstance(_created_on, Unset):
            created_on = UNSET
        else:
            created_on = isoparse(_created_on)

        default = d.pop("default", UNSET)

        _entity = d.pop("entity", UNSET)
        entity: Union[Unset, FieldCustomValueEntity]
        if isinstance(_entity, Unset):
            entity = UNSET
        else:
            entity = FieldCustomValueEntity.from_val(_entity)

        _field = d.pop("field", UNSET)
        field: Union[Unset, FieldCustomValueField]
        if isinstance(_field, Unset):
            field = UNSET
        else:
            field = FieldCustomValueField.from_val(_field)

        id = d.pop("id", UNSET)

        _source = d.pop("source", UNSET)
        source: Union[Unset, FieldCustomValueSource]
        if isinstance(_source, Unset):
            source = UNSET
        else:
            source = FieldCustomValueSource.from_val(_source)

        value = d.pop("value", UNSET)

        field_custom_value = cls(
            created_by_user_id=created_by_user_id,
            created_on=created_on,
            default=default,
            entity=entity,
            field=field,
            id=id,
            source=source,
            value=value,
        )

        field_custom_value.additional_properties = d
        return field_custom_value

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
