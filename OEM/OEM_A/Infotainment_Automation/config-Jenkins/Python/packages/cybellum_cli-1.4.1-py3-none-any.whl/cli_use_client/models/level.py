from enum import Enum
from typing import Union


class Level(str, Enum):
    PRODUCT = "product"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "Level"]) -> "Level":
        if isinstance(value, Level):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return Level(value)
