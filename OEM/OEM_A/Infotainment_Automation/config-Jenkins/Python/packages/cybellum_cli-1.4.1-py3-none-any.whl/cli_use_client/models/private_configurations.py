from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.information_propagation import InformationPropagation
    from ..models.private_configurations_scan_config import PrivateConfigurationsScanConfig


T = TypeVar("T", bound="PrivateConfigurations")


@attr.s(auto_attribs=True)
class PrivateConfigurations:
    """Private configurations

    Attributes:
        dt_mark (Union[Unset, bool]): Digital twin mark internal indicator
        information_propagation (Union[Unset, InformationPropagation]): Information propagation
        scan_config (Union[Unset, PrivateConfigurationsScanConfig]):
    """

    dt_mark: Union[Unset, bool] = UNSET
    information_propagation: Union[Unset, "InformationPropagation"] = UNSET
    scan_config: Union[Unset, "PrivateConfigurationsScanConfig"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        dt_mark = self.dt_mark
        information_propagation: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.information_propagation, Unset):
            information_propagation = self.information_propagation.to_dict()

        scan_config: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.scan_config, Unset):
            scan_config = self.scan_config.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if dt_mark is not UNSET:
            field_dict["dt_mark"] = dt_mark
        if information_propagation is not UNSET:
            field_dict["information propagation"] = information_propagation
        if scan_config is not UNSET:
            field_dict["scan_config"] = scan_config

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.information_propagation import InformationPropagation
        from ..models.private_configurations_scan_config import PrivateConfigurationsScanConfig

        d = src_dict.copy()
        dt_mark = d.pop("dt_mark", UNSET)

        _information_propagation = d.pop("information propagation", UNSET)
        information_propagation: Union[Unset, InformationPropagation]
        if isinstance(_information_propagation, Unset):
            information_propagation = UNSET
        else:
            information_propagation = InformationPropagation.from_dict(_information_propagation)

        _scan_config = d.pop("scan_config", UNSET)
        scan_config: Union[Unset, PrivateConfigurationsScanConfig]
        if isinstance(_scan_config, Unset):
            scan_config = UNSET
        else:
            scan_config = PrivateConfigurationsScanConfig.from_dict(_scan_config)

        private_configurations = cls(
            dt_mark=dt_mark,
            information_propagation=information_propagation,
            scan_config=scan_config,
        )

        private_configurations.additional_properties = d
        return private_configurations

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
