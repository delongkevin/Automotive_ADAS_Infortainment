from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.zero_days_assessment import ZeroDaysAssessment


T = TypeVar("T", bound="GetZeroDaysAssessmentsResponse200Data")


@attr.s(auto_attribs=True)
class GetZeroDaysAssessmentsResponse200Data:
    """
    Attributes:
        assessments (Union[Unset, List['ZeroDaysAssessment']]): Zero days assessments
    """

    assessments: Union[Unset, List["ZeroDaysAssessment"]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        assessments: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.assessments, Unset):
            assessments = []
            for assessments_item_data in self.assessments:
                assessments_item = assessments_item_data.to_dict()

                assessments.append(assessments_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if assessments is not UNSET:
            field_dict["assessments"] = assessments

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.zero_days_assessment import ZeroDaysAssessment

        d = src_dict.copy()
        _assessments = d.pop("assessments", UNSET)
        if (_assessments) is UNSET:
            assessments = UNSET
        else:
            if _assessments:
                assessments = []
                for assessments_item_data in _assessments:
                    assessments_item = ZeroDaysAssessment.from_dict(assessments_item_data)

                    assessments.append(assessments_item)
            else:
                assessments = []

        get_zero_days_assessments_response_200_data = cls(
            assessments=assessments,
        )

        get_zero_days_assessments_response_200_data.additional_properties = d
        return get_zero_days_assessments_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
