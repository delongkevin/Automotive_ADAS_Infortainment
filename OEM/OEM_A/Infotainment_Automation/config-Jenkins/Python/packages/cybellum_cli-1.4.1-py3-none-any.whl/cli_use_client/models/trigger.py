from enum import Enum
from typing import Union


class Trigger(str, Enum):
    DT_VERSION_CREATED = "dt_version_created"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "Trigger"]) -> "Trigger":
        if isinstance(value, Trigger):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return Trigger(value)
