from enum import Enum
from typing import Union


class DigitalTwinVersionScanState(str, Enum):
    QUEUED = "queued"

    RUNNING = "running"

    COMPLETED = "completed"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "DigitalTwinVersionScanState"]) -> "DigitalTwinVersionScanState":
        if isinstance(value, DigitalTwinVersionScanState):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return DigitalTwinVersionScanState(value)
