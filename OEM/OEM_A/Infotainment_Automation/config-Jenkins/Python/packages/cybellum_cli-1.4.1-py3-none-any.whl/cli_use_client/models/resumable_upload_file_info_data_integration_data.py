from typing import Any, Dict, List, Type, TypeVar

import attr

T = TypeVar("T", bound="ResumableUploadFileInfoDataIntegrationData")


@attr.s(auto_attribs=True)
class ResumableUploadFileInfoDataIntegrationData:
    """Resumable upload file integration data"""

    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        resumable_upload_file_info_data_integration_data = cls()

        resumable_upload_file_info_data_integration_data.additional_properties = d
        return resumable_upload_file_info_data_integration_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
