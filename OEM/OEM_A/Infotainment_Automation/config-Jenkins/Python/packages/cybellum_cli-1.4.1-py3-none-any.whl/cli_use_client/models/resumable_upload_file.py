from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.resumable_upload_file_info_state import ResumableUploadFileInfoState
from ..models.resumable_upload_file_type import ResumableUploadFileType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.resumable_upload_file_current_progress import ResumableUploadFileCurrentProgress
    from ..models.resumable_upload_file_info import ResumableUploadFileInfo
    from ..models.resumable_upload_file_info_data import ResumableUploadFileInfoData
    from ..models.resumable_upload_file_info_error import ResumableUploadFileInfoError
    from ..models.resumable_upload_file_info_progress import ResumableUploadFileInfoProgress


T = TypeVar("T", bound="ResumableUploadFile")


@attr.s(auto_attribs=True)
class ResumableUploadFile:
    """Resumable upload file

    Attributes:
        current_progress (Union[Unset, ResumableUploadFileCurrentProgress]): Resumable upload file current progress
        data (Union[Unset, ResumableUploadFileInfoData]): Resumable upload file info data
        error (Union[Unset, ResumableUploadFileInfoError]): Resumable upload file info error
        id (Union[Unset, str]): File id
        info (Union[Unset, ResumableUploadFileInfo]): Resumable upload file info
        progress (Union[Unset, ResumableUploadFileInfoProgress]): Resumable upload file info progress
        session_id (Union[Unset, str]): Session id
        state (Union[Unset, ResumableUploadFileInfoState]): Resumable upload file info state
        sub_state (Union[Unset, str]): Resumable upload file info sub state
        type (Union[Unset, ResumableUploadFileType]): File type
    """

    current_progress: Union[Unset, "ResumableUploadFileCurrentProgress"] = UNSET
    data: Union[Unset, "ResumableUploadFileInfoData"] = UNSET
    error: Union[Unset, "ResumableUploadFileInfoError"] = UNSET
    id: Union[Unset, str] = UNSET
    info: Union[Unset, "ResumableUploadFileInfo"] = UNSET
    progress: Union[Unset, "ResumableUploadFileInfoProgress"] = UNSET
    session_id: Union[Unset, str] = UNSET
    state: Union[Unset, ResumableUploadFileInfoState] = UNSET
    sub_state: Union[Unset, str] = UNSET
    type: Union[Unset, ResumableUploadFileType] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        current_progress: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.current_progress, Unset):
            current_progress = self.current_progress.to_dict()

        data: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.data, Unset):
            data = self.data.to_dict()

        error: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.error, Unset):
            error = self.error.to_dict()

        id = self.id
        info: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.info, Unset):
            info = self.info.to_dict()

        progress: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.progress, Unset):
            progress = self.progress.to_dict()

        session_id = self.session_id
        state: Union[Unset, str] = UNSET
        if not isinstance(self.state, Unset):
            state = ResumableUploadFileInfoState.from_val(self.state).value

        sub_state = self.sub_state
        type: Union[Unset, str] = UNSET
        if not isinstance(self.type, Unset):
            type = ResumableUploadFileType.from_val(self.type).value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if current_progress is not UNSET:
            field_dict["current_progress"] = current_progress
        if data is not UNSET:
            field_dict["data"] = data
        if error is not UNSET:
            field_dict["error"] = error
        if id is not UNSET:
            field_dict["id"] = id
        if info is not UNSET:
            field_dict["info"] = info
        if progress is not UNSET:
            field_dict["progress"] = progress
        if session_id is not UNSET:
            field_dict["session_id"] = session_id
        if state is not UNSET:
            field_dict["state"] = state
        if sub_state is not UNSET:
            field_dict["sub_state"] = sub_state
        if type is not UNSET:
            field_dict["type"] = type

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.resumable_upload_file_current_progress import ResumableUploadFileCurrentProgress
        from ..models.resumable_upload_file_info import ResumableUploadFileInfo
        from ..models.resumable_upload_file_info_data import ResumableUploadFileInfoData
        from ..models.resumable_upload_file_info_error import ResumableUploadFileInfoError
        from ..models.resumable_upload_file_info_progress import ResumableUploadFileInfoProgress

        d = src_dict.copy()
        _current_progress = d.pop("current_progress", UNSET)
        current_progress: Union[Unset, ResumableUploadFileCurrentProgress]
        if isinstance(_current_progress, Unset):
            current_progress = UNSET
        else:
            current_progress = ResumableUploadFileCurrentProgress.from_dict(_current_progress)

        _data = d.pop("data", UNSET)
        data: Union[Unset, ResumableUploadFileInfoData]
        if isinstance(_data, Unset):
            data = UNSET
        else:
            data = ResumableUploadFileInfoData.from_dict(_data)

        _error = d.pop("error", UNSET)
        error: Union[Unset, ResumableUploadFileInfoError]
        if isinstance(_error, Unset):
            error = UNSET
        else:
            error = ResumableUploadFileInfoError.from_dict(_error)

        id = d.pop("id", UNSET)

        _info = d.pop("info", UNSET)
        info: Union[Unset, ResumableUploadFileInfo]
        if isinstance(_info, Unset):
            info = UNSET
        else:
            info = ResumableUploadFileInfo.from_dict(_info)

        _progress = d.pop("progress", UNSET)
        progress: Union[Unset, ResumableUploadFileInfoProgress]
        if isinstance(_progress, Unset):
            progress = UNSET
        else:
            progress = ResumableUploadFileInfoProgress.from_dict(_progress)

        session_id = d.pop("session_id", UNSET)

        _state = d.pop("state", UNSET)
        state: Union[Unset, ResumableUploadFileInfoState]
        if isinstance(_state, Unset):
            state = UNSET
        else:
            state = ResumableUploadFileInfoState.from_val(_state)

        sub_state = d.pop("sub_state", UNSET)

        _type = d.pop("type", UNSET)
        type: Union[Unset, ResumableUploadFileType]
        if isinstance(_type, Unset):
            type = UNSET
        else:
            type = ResumableUploadFileType.from_val(_type)

        resumable_upload_file = cls(
            current_progress=current_progress,
            data=data,
            error=error,
            id=id,
            info=info,
            progress=progress,
            session_id=session_id,
            state=state,
            sub_state=sub_state,
            type=type,
        )

        resumable_upload_file.additional_properties = d
        return resumable_upload_file

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
