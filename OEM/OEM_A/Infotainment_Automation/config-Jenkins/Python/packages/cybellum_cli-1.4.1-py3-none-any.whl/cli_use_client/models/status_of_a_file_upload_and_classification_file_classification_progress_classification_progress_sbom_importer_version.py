import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar(
    "T", bound="StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressSbomImporterVersion"
)


@attr.s(auto_attribs=True)
class StatusOfAFileUploadAndClassificationFileClassificationProgressClassificationProgressSbomImporterVersion:
    """
    Attributes:
        commit (Union[Unset, str]):
        date (Union[Unset, datetime.datetime]):
        name (Union[Unset, str]):
        version (Union[Unset, str]):
    """

    commit: Union[Unset, str] = UNSET
    date: Union[Unset, datetime.datetime] = UNSET
    name: Union[Unset, str] = UNSET
    version: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        commit = self.commit
        date: Union[Unset, str] = UNSET
        if not isinstance(self.date, Unset):
            date = self.date.isoformat()

        name = self.name
        version = self.version

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if commit is not UNSET:
            field_dict["commit"] = commit
        if date is not UNSET:
            field_dict["date"] = date
        if name is not UNSET:
            field_dict["name"] = name
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        commit = d.pop("commit", UNSET)

        _date = d.pop("date", UNSET)
        date: Union[Unset, datetime.datetime]
        if isinstance(_date, Unset):
            date = UNSET
        else:
            date = isoparse(_date)

        name = d.pop("name", UNSET)

        version = d.pop("version", UNSET)

        status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_sbom_importer_version = cls(
            commit=commit,
            date=date,
            name=name,
            version=version,
        )

        status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_sbom_importer_version.additional_properties = (
            d
        )
        return status_of_a_file_upload_and_classification_file_classification_progress_classification_progress_sbom_importer_version

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
