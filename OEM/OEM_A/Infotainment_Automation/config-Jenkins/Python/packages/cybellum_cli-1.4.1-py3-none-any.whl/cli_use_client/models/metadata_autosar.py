from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.the_autosar_package_type import TheAutosarPackageType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.metadata_autosar_configurations import MetadataAutosarConfigurations


T = TypeVar("T", bound="MetadataAutosar")


@attr.s(auto_attribs=True)
class MetadataAutosar:
    """
    Attributes:
        category (Union[Unset, str]): Autosar category (relevant for modules)
        configurations (Union[Unset, None, MetadataAutosarConfigurations]): Autosar module configurations
        stack (Union[Unset, str]): Autosar stack technology name
        type (Union[Unset, TheAutosarPackageType]): The autosar package type
        vendor (Union[Unset, None, str]): Autosar module vendor
    """

    category: Union[Unset, str] = UNSET
    configurations: Union[Unset, None, "MetadataAutosarConfigurations"] = UNSET
    stack: Union[Unset, str] = UNSET
    type: Union[Unset, TheAutosarPackageType] = UNSET
    vendor: Union[Unset, None, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        category = self.category
        configurations: Union[Unset, None, Dict[str, Any]] = UNSET
        if not isinstance(self.configurations, Unset):
            configurations = self.configurations.to_dict() if self.configurations else None

        stack = self.stack
        type: Union[Unset, str] = UNSET
        if not isinstance(self.type, Unset):
            type = TheAutosarPackageType.from_val(self.type).value

        vendor = self.vendor

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if category is not UNSET:
            field_dict["category"] = category
        if configurations is not UNSET:
            field_dict["configurations"] = configurations
        if stack is not UNSET:
            field_dict["stack"] = stack
        if type is not UNSET:
            field_dict["type"] = type
        if vendor is not UNSET:
            field_dict["vendor"] = vendor

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.metadata_autosar_configurations import MetadataAutosarConfigurations

        d = src_dict.copy()
        category = d.pop("category", UNSET)

        _configurations = d.pop("configurations", UNSET)
        configurations: Union[Unset, None, MetadataAutosarConfigurations]
        if _configurations is None:
            configurations = None
        elif isinstance(_configurations, Unset):
            configurations = UNSET
        else:
            configurations = MetadataAutosarConfigurations.from_dict(_configurations)

        stack = d.pop("stack", UNSET)

        _type = d.pop("type", UNSET)
        type: Union[Unset, TheAutosarPackageType]
        if isinstance(_type, Unset):
            type = UNSET
        else:
            type = TheAutosarPackageType.from_val(_type)

        vendor = d.pop("vendor", UNSET)

        metadata_autosar = cls(
            category=category,
            configurations=configurations,
            stack=stack,
            type=type,
            vendor=vendor,
        )

        metadata_autosar.additional_properties = d
        return metadata_autosar

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
