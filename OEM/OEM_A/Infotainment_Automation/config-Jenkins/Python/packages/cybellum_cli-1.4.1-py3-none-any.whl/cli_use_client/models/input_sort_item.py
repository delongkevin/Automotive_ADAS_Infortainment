from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.input_sort_item_direction import InputSortItemDirection
from ..types import UNSET, Unset

T = TypeVar("T", bound="InputSortItem")


@attr.s(auto_attribs=True)
class InputSortItem:
    """
    Attributes:
        direction (InputSortItemDirection): Whether sorting should be ascending or descending
        key (str): Name of the field that records should be sorted by
        custom_field (Union[Unset, bool]):
    """

    direction: InputSortItemDirection
    key: str
    custom_field: Union[Unset, bool] = False
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        direction = InputSortItemDirection.from_val(self.direction).value

        key = self.key
        custom_field = self.custom_field

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "direction": direction,
                "key": key,
            }
        )
        if custom_field is not UNSET:
            field_dict["custom_field"] = custom_field

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        direction = InputSortItemDirection.from_val(d.pop("direction"))

        key = d.pop("key")

        custom_field = d.pop("custom_field", UNSET)

        input_sort_item = cls(
            direction=direction,
            key=key,
            custom_field=custom_field,
        )

        input_sort_item.additional_properties = d
        return input_sort_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
