from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin_version_scan_partial_results_info_partial_info_types_credentials import (
        DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentials,
    )


T = TypeVar("T", bound="DigitalTwinVersionScanPartialResultsInfoPartialInfoTypes")


@attr.s(auto_attribs=True)
class DigitalTwinVersionScanPartialResultsInfoPartialInfoTypes:
    """the partial results for each information type

    Attributes:
        credentials (Union[Unset, DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentials]): credentails
            information type
    """

    credentials: Union[Unset, "DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentials"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        credentials: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.credentials, Unset):
            credentials = self.credentials.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if credentials is not UNSET:
            field_dict["credentials"] = credentials

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin_version_scan_partial_results_info_partial_info_types_credentials import (
            DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentials,
        )

        d = src_dict.copy()
        _credentials = d.pop("credentials", UNSET)
        credentials: Union[Unset, DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentials]
        if isinstance(_credentials, Unset):
            credentials = UNSET
        else:
            credentials = DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentials.from_dict(_credentials)

        digital_twin_version_scan_partial_results_info_partial_info_types = cls(
            credentials=credentials,
        )

        digital_twin_version_scan_partial_results_info_partial_info_types.additional_properties = d
        return digital_twin_version_scan_partial_results_info_partial_info_types

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
