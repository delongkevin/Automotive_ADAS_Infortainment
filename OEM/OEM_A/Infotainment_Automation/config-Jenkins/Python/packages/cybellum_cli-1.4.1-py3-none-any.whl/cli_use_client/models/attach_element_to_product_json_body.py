from typing import Any, Dict, List, Type, TypeVar

import attr

from ..models.element_type import ElementType

T = TypeVar("T", bound="AttachElementToProductJsonBody")


@attr.s(auto_attribs=True)
class AttachElementToProductJsonBody:
    """
    Attributes:
        element_id (str): Element id
        element_type (ElementType): Element type
        product_id (str): Product id to attach to
    """

    element_id: str
    element_type: ElementType
    product_id: str
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        element_id = self.element_id
        element_type = ElementType.from_val(self.element_type).value

        product_id = self.product_id

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "element_id": element_id,
                "element_type": element_type,
                "product_id": product_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        element_id = d.pop("element_id")

        element_type = ElementType.from_val(d.pop("element_type"))

        product_id = d.pop("product_id")

        attach_element_to_product_json_body = cls(
            element_id=element_id,
            element_type=element_type,
            product_id=product_id,
        )

        attach_element_to_product_json_body.additional_properties = d
        return attach_element_to_product_json_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
