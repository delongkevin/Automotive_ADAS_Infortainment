from enum import Enum
from typing import Union


class ZeroDaysAssessementScanType(str, Enum):
    INITIAL = "initial"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "ZeroDaysAssessementScanType"]) -> "ZeroDaysAssessementScanType":
        if isinstance(value, ZeroDaysAssessementScanType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return ZeroDaysAssessementScanType(value)
