from io import BytesIO
from typing import TYPE_CHECKING, Any, Dict, List, Tuple, Type, TypeVar, Union, cast

import attr

from ..client import flatten_params
from ..models.dt_creation_types import DtCreationTypes
from ..types import UNSET, File, FileJsonType, Unset

if TYPE_CHECKING:
    from ..models.create_digital_twin_version_multipart_data_operating_systems_item import (
        CreateDigitalTwinVersionMultipartDataOperatingSystemsItem,
    )
    from ..models.hardware import Hardware
    from ..models.private_configurations import PrivateConfigurations
    from ..models.sbom_metadata import SbomMetadata


T = TypeVar("T", bound="CreateDigitalTwinVersionMultipartData")


@attr.s(auto_attribs=True)
class CreateDigitalTwinVersionMultipartData:
    """
    Attributes:
        dt_id (str): ID
        name (str): the name of the digital twin version
        auto_fix_import_issues (Union[Unset, bool]): Automatically fix errors when importing from an SBOM format file
            (CycloneDX, SPDX or CPE CVEs)
        creation_type (Union[Unset, DtCreationTypes]): The creation type of the digital twin version.  For
            "create_from_firmware" you can specify multiple files via the "urls", "files", "file_ids" or
            "resumable_identifiers" parameters.  For "create_manually" you should not specify any files and for all other
            creation types you should specify exactly one file.  You can use "import_from_sbom_file" to create a DT version
            from either a CycloneDX, SPDX or "CPE CVEs" list.  You can use "import_based_on_file_classification" to create a
            DT version from either a single binary/firmware file or from an SBOM format file (CycloneDX, SPDX or "CPE CVEs"
            list). You can use "create_from_source_code" you can specify multiple source code sources via the "urls",
            "files", "file_ids" or "resumable_identifiers" parameters.
        date (Union[Unset, str]): the date of the digital twin - if not set will be defaulted to the current time
        description (Union[Unset, str]): the dt description
        external_id (Union[Unset, str]): the external id that will be supplied by the customer
        file_ids (Union[Unset, List[str]]): Each entry in the list is a unique identifier for an uploaded file. This
            value should match the identifier used for the file upload, either the "resumableIdentifier" value used for
            "Upload a resumable file", or the "file_id" value used for "Upload file from URL".
        files (Union[File, List[File], Unset]): files to upload for the DT created version
        gitlog_archive_file (Union[Unset, File]): the git log archive file
        hardware (Union[Unset, Hardware]): digital twin hardware
        is_root (Union[Unset, bool]): root version will be created from scratch without propagation
        make_default (Union[Unset, bool]): newly created version will be marked as the default
        micro_controller (Union[Unset, bool]): is it micro_controller
        operating_systems (Union[Unset, List['CreateDigitalTwinVersionMultipartDataOperatingSystemsItem']]): operating
            systems of the digital twin version
        parent_id (Union[Unset, str]): ID
        private_configurations (Union[Unset, PrivateConfigurations]): Private configurations
        production_phase (Union[Unset, str]): Component Production Phase
        resumable_gitlog_identifier (Union[Unset, str]): resumable upload gitlog file identifier
        resumable_identifiers (Union[Unset, List[str]]): resumable upload file identifiers
        resumable_session_id (Union[Unset, str]): resumable upload session id
        sbom_metadata (Union[Unset, SbomMetadata]): sbom metadata from intermediate sbom
        sbom_phase (Union[Unset, str]):
        urls (Union[Unset, List[str]]): files to upload from a URL to the DT - in case this field is set the system will
            ignore the 'files' parameter. otherwise it will look for the files in the 'files' parameter
    """

    dt_id: str
    name: str
    auto_fix_import_issues: Union[Unset, bool] = UNSET
    creation_type: Union[Unset, DtCreationTypes] = UNSET
    date: Union[Unset, str] = UNSET
    description: Union[Unset, str] = UNSET
    external_id: Union[Unset, str] = UNSET
    file_ids: Union[Unset, List[str]] = UNSET
    files: Union[File, List[File], Unset] = UNSET
    gitlog_archive_file: Union[Unset, File] = UNSET
    hardware: Union[Unset, "Hardware"] = UNSET
    is_root: Union[Unset, bool] = UNSET
    make_default: Union[Unset, bool] = UNSET
    micro_controller: Union[Unset, bool] = UNSET
    operating_systems: Union[Unset, List["CreateDigitalTwinVersionMultipartDataOperatingSystemsItem"]] = UNSET
    parent_id: Union[Unset, str] = UNSET
    private_configurations: Union[Unset, "PrivateConfigurations"] = UNSET
    production_phase: Union[Unset, str] = UNSET
    resumable_gitlog_identifier: Union[Unset, str] = UNSET
    resumable_identifiers: Union[Unset, List[str]] = UNSET
    resumable_session_id: Union[Unset, str] = UNSET
    sbom_metadata: Union[Unset, "SbomMetadata"] = UNSET
    sbom_phase: Union[Unset, str] = UNSET
    urls: Union[Unset, List[str]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        dt_id = self.dt_id
        name = self.name
        auto_fix_import_issues = self.auto_fix_import_issues
        creation_type: Union[Unset, str] = UNSET
        if not isinstance(self.creation_type, Unset):
            creation_type = DtCreationTypes.from_val(self.creation_type).value

        date = self.date
        description = self.description
        external_id = self.external_id
        file_ids: Union[Unset, List[str]] = UNSET
        if not isinstance(self.file_ids, Unset):
            file_ids = self.file_ids

        files: Union[FileJsonType, List[FileJsonType], Unset]
        if isinstance(self.files, Unset):
            files = UNSET

        elif isinstance(self.files, File):
            files = UNSET
            if not isinstance(self.files, Unset):
                files = self.files.to_tuple()

        else:
            files = UNSET
            if not isinstance(self.files, Unset):
                files = []
                for files_type_1_item_data in self.files:
                    files_type_1_item = files_type_1_item_data.to_tuple()

                    files.append(files_type_1_item)

        gitlog_archive_file: Union[Unset, FileJsonType] = UNSET
        if not isinstance(self.gitlog_archive_file, Unset):
            gitlog_archive_file = self.gitlog_archive_file.to_tuple()

        hardware: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.hardware, Unset):
            hardware = self.hardware.to_dict()

        is_root = self.is_root
        make_default = self.make_default
        micro_controller = self.micro_controller
        operating_systems: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.operating_systems, Unset):
            operating_systems = []
            for operating_systems_item_data in self.operating_systems:
                operating_systems_item = operating_systems_item_data.to_dict()

                operating_systems.append(operating_systems_item)

        parent_id = self.parent_id
        private_configurations: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.private_configurations, Unset):
            private_configurations = self.private_configurations.to_dict()

        production_phase = self.production_phase
        resumable_gitlog_identifier = self.resumable_gitlog_identifier
        resumable_identifiers: Union[Unset, List[str]] = UNSET
        if not isinstance(self.resumable_identifiers, Unset):
            resumable_identifiers = self.resumable_identifiers

        resumable_session_id = self.resumable_session_id
        sbom_metadata: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.sbom_metadata, Unset):
            sbom_metadata = self.sbom_metadata.to_dict()

        sbom_phase = self.sbom_phase
        urls: Union[Unset, List[str]] = UNSET
        if not isinstance(self.urls, Unset):
            urls = self.urls

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "dt_id": dt_id,
                "name": name,
            }
        )
        if auto_fix_import_issues is not UNSET:
            field_dict["auto_fix_import_issues"] = auto_fix_import_issues
        if creation_type is not UNSET:
            field_dict["creation_type"] = creation_type
        if date is not UNSET:
            field_dict["date"] = date
        if description is not UNSET:
            field_dict["description"] = description
        if external_id is not UNSET:
            field_dict["external_id"] = external_id
        if file_ids is not UNSET:
            field_dict["file_ids"] = file_ids
        if files is not UNSET:
            field_dict["files"] = files
        if gitlog_archive_file is not UNSET:
            field_dict["gitlog_archive_file"] = gitlog_archive_file
        if hardware is not UNSET:
            field_dict["hardware"] = hardware
        if is_root is not UNSET:
            field_dict["is_root"] = is_root
        if make_default is not UNSET:
            field_dict["make_default"] = make_default
        if micro_controller is not UNSET:
            field_dict["micro_controller"] = micro_controller
        if operating_systems is not UNSET:
            field_dict["operating systems"] = operating_systems
        if parent_id is not UNSET:
            field_dict["parent_id"] = parent_id
        if private_configurations is not UNSET:
            field_dict["private_configurations"] = private_configurations
        if production_phase is not UNSET:
            field_dict["production_phase"] = production_phase
        if resumable_gitlog_identifier is not UNSET:
            field_dict["resumable_gitlog_identifier"] = resumable_gitlog_identifier
        if resumable_identifiers is not UNSET:
            field_dict["resumable_identifiers"] = resumable_identifiers
        if resumable_session_id is not UNSET:
            field_dict["resumable_session_id"] = resumable_session_id
        if sbom_metadata is not UNSET:
            field_dict["sbom_metadata"] = sbom_metadata
        if sbom_phase is not UNSET:
            field_dict["sbom_phase"] = sbom_phase
        if urls is not UNSET:
            field_dict["urls"] = urls

        return field_dict

    def to_multipart(self) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        self_dict = self.to_dict()
        self_dict = flatten_params(self_dict)
        data = {
            key: value
            for key, value in self_dict.items()
            if value is not None and value is not UNSET and not isinstance(value, File) and not isinstance(value, Tuple)
        }
        files = {
            key: value.to_tuple() if isinstance(value, File) else value
            for key, value in self_dict.items()
            if value is not None and value is not UNSET and (isinstance(value, File) or isinstance(value, Tuple))
        }
        return (data, files)

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.create_digital_twin_version_multipart_data_operating_systems_item import (
            CreateDigitalTwinVersionMultipartDataOperatingSystemsItem,
        )
        from ..models.hardware import Hardware
        from ..models.private_configurations import PrivateConfigurations
        from ..models.sbom_metadata import SbomMetadata

        d = src_dict.copy()
        dt_id = d.pop("dt_id")

        name = d.pop("name")

        auto_fix_import_issues = d.pop("auto_fix_import_issues", UNSET)

        _creation_type = d.pop("creation_type", UNSET)
        creation_type: Union[Unset, DtCreationTypes]
        if isinstance(_creation_type, Unset):
            creation_type = UNSET
        else:
            creation_type = DtCreationTypes.from_val(_creation_type)

        date = d.pop("date", UNSET)

        description = d.pop("description", UNSET)

        external_id = d.pop("external_id", UNSET)

        file_ids = cast(List[str], d.pop("file_ids", UNSET))

        def _parse_files(data: object) -> Union[File, List[File], Unset]:
            if isinstance(data, Unset):
                return data
            try:
                if not (isinstance(data, bytes) or isinstance(data, File)):
                    raise TypeError()
                _files_type_0 = data
                files_type_0: Union[Unset, File]

                if isinstance(_files_type_0, Unset):
                    files_type_0 = UNSET
                elif isinstance(_files_type_0, File):
                    files_type_0 = _files_type_0
                else:
                    files_type_0 = File(payload=BytesIO(_files_type_0))

                return files_type_0
            except:  # noqa: E722
                pass
            if not isinstance(data, list):
                raise TypeError()
            _files_type_1 = data
            if (_files_type_1) is UNSET:
                files_type_1 = UNSET
            else:
                if _files_type_1:
                    files_type_1 = []
                    for files_type_1_item_data in _files_type_1:
                        _files_type_1_item = files_type_1_item_data
                        files_type_1_item: File

                        if isinstance(_files_type_1_item, File):
                            files_type_1_item = _files_type_1_item
                        else:
                            files_type_1_item = File(payload=BytesIO(_files_type_1_item))

                        files_type_1.append(files_type_1_item)
                else:
                    files_type_1 = UNSET

            return files_type_1

        files = _parse_files(d.pop("files", UNSET))

        _gitlog_archive_file = d.pop("gitlog_archive_file", UNSET)
        gitlog_archive_file: Union[Unset, File]

        if isinstance(_gitlog_archive_file, Unset):
            gitlog_archive_file = UNSET
        elif isinstance(_gitlog_archive_file, File):
            gitlog_archive_file = _gitlog_archive_file
        else:
            gitlog_archive_file = File(payload=BytesIO(_gitlog_archive_file))

        _hardware = d.pop("hardware", UNSET)
        hardware: Union[Unset, Hardware]
        if isinstance(_hardware, Unset):
            hardware = UNSET
        else:
            hardware = Hardware.from_dict(_hardware)

        is_root = d.pop("is_root", UNSET)

        make_default = d.pop("make_default", UNSET)

        micro_controller = d.pop("micro_controller", UNSET)

        _operating_systems = d.pop("operating systems", UNSET)
        if (_operating_systems) is UNSET:
            operating_systems = UNSET
        else:
            if _operating_systems:
                operating_systems = []
                for operating_systems_item_data in _operating_systems:
                    operating_systems_item = CreateDigitalTwinVersionMultipartDataOperatingSystemsItem.from_dict(
                        operating_systems_item_data
                    )

                    operating_systems.append(operating_systems_item)
            else:
                operating_systems = []

        parent_id = d.pop("parent_id", UNSET)

        _private_configurations = d.pop("private_configurations", UNSET)
        private_configurations: Union[Unset, PrivateConfigurations]
        if isinstance(_private_configurations, Unset):
            private_configurations = UNSET
        else:
            private_configurations = PrivateConfigurations.from_dict(_private_configurations)

        production_phase = d.pop("production_phase", UNSET)

        resumable_gitlog_identifier = d.pop("resumable_gitlog_identifier", UNSET)

        resumable_identifiers = cast(List[str], d.pop("resumable_identifiers", UNSET))

        resumable_session_id = d.pop("resumable_session_id", UNSET)

        _sbom_metadata = d.pop("sbom_metadata", UNSET)
        sbom_metadata: Union[Unset, SbomMetadata]
        if isinstance(_sbom_metadata, Unset):
            sbom_metadata = UNSET
        else:
            sbom_metadata = SbomMetadata.from_dict(_sbom_metadata)

        sbom_phase = d.pop("sbom_phase", UNSET)

        urls = cast(List[str], d.pop("urls", UNSET))

        create_digital_twin_version_multipart_data = cls(
            dt_id=dt_id,
            name=name,
            auto_fix_import_issues=auto_fix_import_issues,
            creation_type=creation_type,
            date=date,
            description=description,
            external_id=external_id,
            file_ids=file_ids,
            files=files,
            gitlog_archive_file=gitlog_archive_file,
            hardware=hardware,
            is_root=is_root,
            make_default=make_default,
            micro_controller=micro_controller,
            operating_systems=operating_systems,
            parent_id=parent_id,
            private_configurations=private_configurations,
            production_phase=production_phase,
            resumable_gitlog_identifier=resumable_gitlog_identifier,
            resumable_identifiers=resumable_identifiers,
            resumable_session_id=resumable_session_id,
            sbom_metadata=sbom_metadata,
            sbom_phase=sbom_phase,
            urls=urls,
        )

        create_digital_twin_version_multipart_data.additional_properties = d
        return create_digital_twin_version_multipart_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
