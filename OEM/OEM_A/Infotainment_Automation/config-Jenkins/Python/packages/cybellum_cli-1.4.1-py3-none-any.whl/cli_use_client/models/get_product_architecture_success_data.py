from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.get_product_architecture_success_data_product_architecture import (
        GetProductArchitectureSuccessDataProductArchitecture,
    )


T = TypeVar("T", bound="GetProductArchitectureSuccessData")


@attr.s(auto_attribs=True)
class GetProductArchitectureSuccessData:
    """
    Attributes:
        product_architecture (Union[Unset, GetProductArchitectureSuccessDataProductArchitecture]):
    """

    product_architecture: Union[Unset, "GetProductArchitectureSuccessDataProductArchitecture"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        product_architecture: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.product_architecture, Unset):
            product_architecture = self.product_architecture.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if product_architecture is not UNSET:
            field_dict["product_architecture"] = product_architecture

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.get_product_architecture_success_data_product_architecture import (
            GetProductArchitectureSuccessDataProductArchitecture,
        )

        d = src_dict.copy()
        _product_architecture = d.pop("product_architecture", UNSET)
        product_architecture: Union[Unset, GetProductArchitectureSuccessDataProductArchitecture]
        if isinstance(_product_architecture, Unset):
            product_architecture = UNSET
        else:
            product_architecture = GetProductArchitectureSuccessDataProductArchitecture.from_dict(_product_architecture)

        get_product_architecture_success_data = cls(
            product_architecture=product_architecture,
        )

        get_product_architecture_success_data.additional_properties = d
        return get_product_architecture_success_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
