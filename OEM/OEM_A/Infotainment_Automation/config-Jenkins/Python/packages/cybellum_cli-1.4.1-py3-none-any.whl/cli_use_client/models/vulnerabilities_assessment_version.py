from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.vulnerabilities_assessment_version_scan import VulnerabilitiesAssessmentVersionScan
    from ..models.vulnerabilities_assessment_version_stats import VulnerabilitiesAssessmentVersionStats


T = TypeVar("T", bound="VulnerabilitiesAssessmentVersion")


@attr.s(auto_attribs=True)
class VulnerabilitiesAssessmentVersion:
    """Vulnerabilities assessment version

    Attributes:
        dt_version_id (str): ID
        id (str): ID
        created_by (Union[Unset, str]): Creator user id
        created_on (Union[Unset, str]): Creation date of the assessment
        inherit_from_previous_version (Union[Unset, bool]): Inherit from previous assessment version
        last_modified_on (Union[Unset, str]): Last modified date
        latest_scan (Union[Unset, VulnerabilitiesAssessmentVersionScan]): Vulnerabilities assessment version scan
        prev_assessment_version_id (Union[Unset, str]): ID
        risk_score (Union[Unset, float]): Assessment risk score Example: 7.5.
        sbom_revision (Union[Unset, int]): SBOM revision
        vulnerabilities_stats (Union[Unset, VulnerabilitiesAssessmentVersionStats]): Vulnerabilities assessment version
            stats
    """

    dt_version_id: str
    id: str
    created_by: Union[Unset, str] = UNSET
    created_on: Union[Unset, str] = UNSET
    inherit_from_previous_version: Union[Unset, bool] = UNSET
    last_modified_on: Union[Unset, str] = UNSET
    latest_scan: Union[Unset, "VulnerabilitiesAssessmentVersionScan"] = UNSET
    prev_assessment_version_id: Union[Unset, str] = UNSET
    risk_score: Union[Unset, float] = UNSET
    sbom_revision: Union[Unset, int] = UNSET
    vulnerabilities_stats: Union[Unset, "VulnerabilitiesAssessmentVersionStats"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        dt_version_id = self.dt_version_id
        id = self.id
        created_by = self.created_by
        created_on = self.created_on
        inherit_from_previous_version = self.inherit_from_previous_version
        last_modified_on = self.last_modified_on
        latest_scan: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.latest_scan, Unset):
            latest_scan = self.latest_scan.to_dict()

        prev_assessment_version_id = self.prev_assessment_version_id
        risk_score = self.risk_score
        sbom_revision = self.sbom_revision
        vulnerabilities_stats: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.vulnerabilities_stats, Unset):
            vulnerabilities_stats = self.vulnerabilities_stats.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "dt_version_id": dt_version_id,
                "id": id,
            }
        )
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if created_on is not UNSET:
            field_dict["created_on"] = created_on
        if inherit_from_previous_version is not UNSET:
            field_dict["inherit_from_previous_version"] = inherit_from_previous_version
        if last_modified_on is not UNSET:
            field_dict["last_modified_on"] = last_modified_on
        if latest_scan is not UNSET:
            field_dict["latest_scan"] = latest_scan
        if prev_assessment_version_id is not UNSET:
            field_dict["prev_assessment_version_id"] = prev_assessment_version_id
        if risk_score is not UNSET:
            field_dict["risk_score"] = risk_score
        if sbom_revision is not UNSET:
            field_dict["sbom_revision"] = sbom_revision
        if vulnerabilities_stats is not UNSET:
            field_dict["vulnerabilities_stats"] = vulnerabilities_stats

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.vulnerabilities_assessment_version_scan import VulnerabilitiesAssessmentVersionScan
        from ..models.vulnerabilities_assessment_version_stats import VulnerabilitiesAssessmentVersionStats

        d = src_dict.copy()
        dt_version_id = d.pop("dt_version_id")

        id = d.pop("id")

        created_by = d.pop("created_by", UNSET)

        created_on = d.pop("created_on", UNSET)

        inherit_from_previous_version = d.pop("inherit_from_previous_version", UNSET)

        last_modified_on = d.pop("last_modified_on", UNSET)

        _latest_scan = d.pop("latest_scan", UNSET)
        latest_scan: Union[Unset, VulnerabilitiesAssessmentVersionScan]
        if isinstance(_latest_scan, Unset):
            latest_scan = UNSET
        else:
            latest_scan = VulnerabilitiesAssessmentVersionScan.from_dict(_latest_scan)

        prev_assessment_version_id = d.pop("prev_assessment_version_id", UNSET)

        risk_score = d.pop("risk_score", UNSET)

        sbom_revision = d.pop("sbom_revision", UNSET)

        _vulnerabilities_stats = d.pop("vulnerabilities_stats", UNSET)
        vulnerabilities_stats: Union[Unset, VulnerabilitiesAssessmentVersionStats]
        if isinstance(_vulnerabilities_stats, Unset):
            vulnerabilities_stats = UNSET
        else:
            vulnerabilities_stats = VulnerabilitiesAssessmentVersionStats.from_dict(_vulnerabilities_stats)

        vulnerabilities_assessment_version = cls(
            dt_version_id=dt_version_id,
            id=id,
            created_by=created_by,
            created_on=created_on,
            inherit_from_previous_version=inherit_from_previous_version,
            last_modified_on=last_modified_on,
            latest_scan=latest_scan,
            prev_assessment_version_id=prev_assessment_version_id,
            risk_score=risk_score,
            sbom_revision=sbom_revision,
            vulnerabilities_stats=vulnerabilities_stats,
        )

        vulnerabilities_assessment_version.additional_properties = d
        return vulnerabilities_assessment_version

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
