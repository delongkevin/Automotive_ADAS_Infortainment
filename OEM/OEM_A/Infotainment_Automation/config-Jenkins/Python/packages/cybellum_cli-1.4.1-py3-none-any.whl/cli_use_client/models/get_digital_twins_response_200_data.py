from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin import DigitalTwin


T = TypeVar("T", bound="GetDigitalTwinsResponse200Data")


@attr.s(auto_attribs=True)
class GetDigitalTwinsResponse200Data:
    """
    Attributes:
        dts (Union[Unset, List['DigitalTwin']]):
    """

    dts: Union[Unset, List["DigitalTwin"]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        dts: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.dts, Unset):
            dts = []
            for dts_item_data in self.dts:
                dts_item = dts_item_data.to_dict()

                dts.append(dts_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if dts is not UNSET:
            field_dict["dts"] = dts

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin import DigitalTwin

        d = src_dict.copy()
        _dts = d.pop("dts", UNSET)
        if (_dts) is UNSET:
            dts = UNSET
        else:
            if _dts:
                dts = []
                for dts_item_data in _dts:
                    dts_item = DigitalTwin.from_dict(dts_item_data)

                    dts.append(dts_item)
            else:
                dts = []

        get_digital_twins_response_200_data = cls(
            dts=dts,
        )

        get_digital_twins_response_200_data.additional_properties = d
        return get_digital_twins_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
