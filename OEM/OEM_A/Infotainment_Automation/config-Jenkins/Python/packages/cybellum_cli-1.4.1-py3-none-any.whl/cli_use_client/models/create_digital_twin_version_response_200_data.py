from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin_version import DigitalTwinVersion


T = TypeVar("T", bound="CreateDigitalTwinVersionResponse200Data")


@attr.s(auto_attribs=True)
class CreateDigitalTwinVersionResponse200Data:
    """
    Attributes:
        dt_version (Union[Unset, DigitalTwinVersion]): Digital Twin Version
    """

    dt_version: Union[Unset, "DigitalTwinVersion"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        dt_version: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.dt_version, Unset):
            dt_version = self.dt_version.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if dt_version is not UNSET:
            field_dict["dt_version"] = dt_version

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin_version import DigitalTwinVersion

        d = src_dict.copy()
        _dt_version = d.pop("dt_version", UNSET)
        dt_version: Union[Unset, DigitalTwinVersion]
        if isinstance(_dt_version, Unset):
            dt_version = UNSET
        else:
            dt_version = DigitalTwinVersion.from_dict(_dt_version)

        create_digital_twin_version_response_200_data = cls(
            dt_version=dt_version,
        )

        create_digital_twin_version_response_200_data.additional_properties = d
        return create_digital_twin_version_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
