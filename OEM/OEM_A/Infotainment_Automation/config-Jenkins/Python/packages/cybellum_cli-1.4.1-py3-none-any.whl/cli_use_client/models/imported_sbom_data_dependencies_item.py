from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="ImportedSBOMDataDependenciesItem")


@attr.s(auto_attribs=True)
class ImportedSBOMDataDependenciesItem:
    """
    Attributes:
        source_id (str):
        target_id (str):
        type (str): Allowed values: "DEPENDS_ON", "VARIANT_OF", "COPY_OF", "PATCH_FOR", "TEST_DEPENDENCY_OF",
            "CONTAINED_BY", "DATA_FILE_OF", "OPTIONAL_COMPONENT_OF", "ANCESTOR_OF", "GENERATES", "CONTAINS",
            "OPTIONAL_DEPENDENCY_OF", "FILE_ADDED", "REQUIREMENT_DESCRIPTION_FOR", "DEV_DEPENDENCY_OF", "DEPENDENCY_OF",
            "BUILD_DEPENDENCY_OF", "DESCRIBES", "PREREQUISITE_FOR", "HAS_PREREQUISITE", "PROVIDED_DEPENDENCY_OF",
            "DYNAMIC_LINK", "DESCRIBED_BY", "METAFILE_OF", "DEPENDENCY_MANIFEST_OF", "PATCH_APPLIED",
            "RUNTIME_DEPENDENCY_OF", "TEST_OF", "TEST_TOOL_OF", "SPECIFICATION_FOR", "FILE_MODIFIED",
            "DISTRIBUTION_ARTIFACT", "AMENDS", "DOCUMENTATION_OF", "GENERATED_FROM", "STATIC_LINK", "OTHER",
            "BUILD_TOOL_OF", "TEST_CASE_OF", "PACKAGE_OF", "DESCENDANT_OF", "FILE_DELETED", "EXPANDED_FROM_ARCHIVE",
            "DEV_TOOL_OF", "EXAMPLE_OF"
        comment (Union[Unset, str]):
    """

    source_id: str
    target_id: str
    type: str
    comment: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        source_id = self.source_id
        target_id = self.target_id
        type = self.type
        comment = self.comment

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "source_id": source_id,
                "target_id": target_id,
                "type": type,
            }
        )
        if comment is not UNSET:
            field_dict["comment"] = comment

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        source_id = d.pop("source_id")

        target_id = d.pop("target_id")

        type = d.pop("type")

        comment = d.pop("comment", UNSET)

        imported_sbom_data_dependencies_item = cls(
            source_id=source_id,
            target_id=target_id,
            type=type,
            comment=comment,
        )

        imported_sbom_data_dependencies_item.additional_properties = d
        return imported_sbom_data_dependencies_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
