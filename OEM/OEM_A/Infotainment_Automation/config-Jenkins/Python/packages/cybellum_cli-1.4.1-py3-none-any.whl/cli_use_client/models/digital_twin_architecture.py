from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="DigitalTwinArchitecture")


@attr.s(auto_attribs=True)
class DigitalTwinArchitecture:
    """digital twin architecture

    Attributes:
        architecture_code (Union[Unset, str]): architecture code
        cpu (Union[Unset, str]): CPU name
        cpu_bit_size (Union[Unset, int]): CPU bit size
        cpu_family (Union[Unset, str]): CPU family
        cpu_model (Union[Unset, str]): CPU model
        cpu_vendor (Union[Unset, str]): CPU vendor
    """

    architecture_code: Union[Unset, str] = UNSET
    cpu: Union[Unset, str] = UNSET
    cpu_bit_size: Union[Unset, int] = UNSET
    cpu_family: Union[Unset, str] = UNSET
    cpu_model: Union[Unset, str] = UNSET
    cpu_vendor: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        architecture_code = self.architecture_code
        cpu = self.cpu
        cpu_bit_size = self.cpu_bit_size
        cpu_family = self.cpu_family
        cpu_model = self.cpu_model
        cpu_vendor = self.cpu_vendor

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if architecture_code is not UNSET:
            field_dict["architecture_code"] = architecture_code
        if cpu is not UNSET:
            field_dict["cpu"] = cpu
        if cpu_bit_size is not UNSET:
            field_dict["cpu_bit_size"] = cpu_bit_size
        if cpu_family is not UNSET:
            field_dict["cpu_family"] = cpu_family
        if cpu_model is not UNSET:
            field_dict["cpu_model"] = cpu_model
        if cpu_vendor is not UNSET:
            field_dict["cpu_vendor"] = cpu_vendor

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        architecture_code = d.pop("architecture_code", UNSET)

        cpu = d.pop("cpu", UNSET)

        cpu_bit_size = d.pop("cpu_bit_size", UNSET)

        cpu_family = d.pop("cpu_family", UNSET)

        cpu_model = d.pop("cpu_model", UNSET)

        cpu_vendor = d.pop("cpu_vendor", UNSET)

        digital_twin_architecture = cls(
            architecture_code=architecture_code,
            cpu=cpu,
            cpu_bit_size=cpu_bit_size,
            cpu_family=cpu_family,
            cpu_model=cpu_model,
            cpu_vendor=cpu_vendor,
        )

        digital_twin_architecture.additional_properties = d
        return digital_twin_architecture

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
