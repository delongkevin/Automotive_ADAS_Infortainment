from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.policies_assessment_version_stats_requirement_by_status import (
        PoliciesAssessmentVersionStatsRequirementByStatus,
    )


T = TypeVar("T", bound="PoliciesAssessmentVersionStats")


@attr.s(auto_attribs=True)
class PoliciesAssessmentVersionStats:
    """Policies assessment version stats

    Attributes:
        requirement_by_status (Union[Unset, PoliciesAssessmentVersionStatsRequirementByStatus]): A dictionary of
            requirement status and number of requiremnts that hold this status
    """

    requirement_by_status: Union[Unset, "PoliciesAssessmentVersionStatsRequirementByStatus"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        requirement_by_status: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.requirement_by_status, Unset):
            requirement_by_status = self.requirement_by_status.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if requirement_by_status is not UNSET:
            field_dict["requirement_by_status"] = requirement_by_status

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.policies_assessment_version_stats_requirement_by_status import (
            PoliciesAssessmentVersionStatsRequirementByStatus,
        )

        d = src_dict.copy()
        _requirement_by_status = d.pop("requirement_by_status", UNSET)
        requirement_by_status: Union[Unset, PoliciesAssessmentVersionStatsRequirementByStatus]
        if isinstance(_requirement_by_status, Unset):
            requirement_by_status = UNSET
        else:
            requirement_by_status = PoliciesAssessmentVersionStatsRequirementByStatus.from_dict(_requirement_by_status)

        policies_assessment_version_stats = cls(
            requirement_by_status=requirement_by_status,
        )

        policies_assessment_version_stats.additional_properties = d
        return policies_assessment_version_stats

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
