from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.status_of_a_file_upload_and_classification_file_classification_progress_upload_progress_loaded import (
        StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressLoaded,
    )
    from ..models.status_of_a_file_upload_and_classification_file_classification_progress_upload_progress_total import (
        StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressTotal,
    )


T = TypeVar("T", bound="StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgress")


@attr.s(auto_attribs=True)
class StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgress:
    """The status (and eventually result) of the file upload

    Attributes:
        bytes_total (Union[Unset, int]):
        bytes_uploaded (Union[Unset, int]):
        completed (Union[Unset, bool]): True when the file has finished uploading, otherwise False
        error (Union[Unset, str]):
        loaded (Union[Unset, StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressLoaded]):
        progress (Union[Unset, int]):
        retry (Union[Unset, bool]):
        size (Union[Unset, int]):
        total (Union[Unset, StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressTotal]):
        uploading (Union[Unset, bool]):
    """

    bytes_total: Union[Unset, int] = UNSET
    bytes_uploaded: Union[Unset, int] = UNSET
    completed: Union[Unset, bool] = UNSET
    error: Union[Unset, str] = UNSET
    loaded: Union[Unset, "StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressLoaded"] = UNSET
    progress: Union[Unset, int] = UNSET
    retry: Union[Unset, bool] = UNSET
    size: Union[Unset, int] = UNSET
    total: Union[Unset, "StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressTotal"] = UNSET
    uploading: Union[Unset, bool] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        bytes_total = self.bytes_total
        bytes_uploaded = self.bytes_uploaded
        completed = self.completed
        error = self.error
        loaded: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.loaded, Unset):
            loaded = self.loaded.to_dict()

        progress = self.progress
        retry = self.retry
        size = self.size
        total: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.total, Unset):
            total = self.total.to_dict()

        uploading = self.uploading

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if bytes_total is not UNSET:
            field_dict["bytes_total"] = bytes_total
        if bytes_uploaded is not UNSET:
            field_dict["bytes_uploaded"] = bytes_uploaded
        if completed is not UNSET:
            field_dict["completed"] = completed
        if error is not UNSET:
            field_dict["error"] = error
        if loaded is not UNSET:
            field_dict["loaded"] = loaded
        if progress is not UNSET:
            field_dict["progress"] = progress
        if retry is not UNSET:
            field_dict["retry"] = retry
        if size is not UNSET:
            field_dict["size"] = size
        if total is not UNSET:
            field_dict["total"] = total
        if uploading is not UNSET:
            field_dict["uploading"] = uploading

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.status_of_a_file_upload_and_classification_file_classification_progress_upload_progress_loaded import (
            StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressLoaded,
        )
        from ..models.status_of_a_file_upload_and_classification_file_classification_progress_upload_progress_total import (
            StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressTotal,
        )

        d = src_dict.copy()
        bytes_total = d.pop("bytes_total", UNSET)

        bytes_uploaded = d.pop("bytes_uploaded", UNSET)

        completed = d.pop("completed", UNSET)

        error = d.pop("error", UNSET)

        _loaded = d.pop("loaded", UNSET)
        loaded: Union[Unset, StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressLoaded]
        if isinstance(_loaded, Unset):
            loaded = UNSET
        else:
            loaded = StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressLoaded.from_dict(
                _loaded
            )

        progress = d.pop("progress", UNSET)

        retry = d.pop("retry", UNSET)

        size = d.pop("size", UNSET)

        _total = d.pop("total", UNSET)
        total: Union[Unset, StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressTotal]
        if isinstance(_total, Unset):
            total = UNSET
        else:
            total = StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressTotal.from_dict(_total)

        uploading = d.pop("uploading", UNSET)

        status_of_a_file_upload_and_classification_file_classification_progress_upload_progress = cls(
            bytes_total=bytes_total,
            bytes_uploaded=bytes_uploaded,
            completed=completed,
            error=error,
            loaded=loaded,
            progress=progress,
            retry=retry,
            size=size,
            total=total,
            uploading=uploading,
        )

        status_of_a_file_upload_and_classification_file_classification_progress_upload_progress.additional_properties = (
            d
        )
        return status_of_a_file_upload_and_classification_file_classification_progress_upload_progress

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
