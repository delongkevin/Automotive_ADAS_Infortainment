from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.trigger import Trigger
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin_version_created_workflow import DigitalTwinVersionCreatedWorkflow


T = TypeVar("T", bound="Workflow")


@attr.s(auto_attribs=True)
class Workflow:
    """Workflow

    Attributes:
        created_by (str): Creation user
        created_on (str): Creation date
        id (str): ID
        name (str): Workflow name
        trigger (Trigger): Trigger
        configurations (Union[Unset, DigitalTwinVersionCreatedWorkflow]): Digital twin version created workflow
        is_default (Union[Unset, bool]): Indicator if this workflow is default
        is_enabled (Union[Unset, bool]): Indicator if enabled
    """

    created_by: str
    created_on: str
    id: str
    name: str
    trigger: Trigger
    configurations: Union[Unset, "DigitalTwinVersionCreatedWorkflow"] = UNSET
    is_default: Union[Unset, bool] = UNSET
    is_enabled: Union[Unset, bool] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        created_by = self.created_by
        created_on = self.created_on
        id = self.id
        name = self.name
        trigger = Trigger.from_val(self.trigger).value

        configurations: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.configurations, Unset):
            configurations = self.configurations.to_dict()

        is_default = self.is_default
        is_enabled = self.is_enabled

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "created_by": created_by,
                "created_on": created_on,
                "id": id,
                "name": name,
                "trigger": trigger,
            }
        )
        if configurations is not UNSET:
            field_dict["configurations"] = configurations
        if is_default is not UNSET:
            field_dict["is_default"] = is_default
        if is_enabled is not UNSET:
            field_dict["is_enabled"] = is_enabled

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin_version_created_workflow import DigitalTwinVersionCreatedWorkflow

        d = src_dict.copy()
        created_by = d.pop("created_by")

        created_on = d.pop("created_on")

        id = d.pop("id")

        name = d.pop("name")

        trigger = Trigger.from_val(d.pop("trigger"))

        _configurations = d.pop("configurations", UNSET)
        configurations: Union[Unset, DigitalTwinVersionCreatedWorkflow]
        if isinstance(_configurations, Unset):
            configurations = UNSET
        else:
            configurations = DigitalTwinVersionCreatedWorkflow.from_dict(_configurations)

        is_default = d.pop("is_default", UNSET)

        is_enabled = d.pop("is_enabled", UNSET)

        workflow = cls(
            created_by=created_by,
            created_on=created_on,
            id=id,
            name=name,
            trigger=trigger,
            configurations=configurations,
            is_default=is_default,
            is_enabled=is_enabled,
        )

        workflow.additional_properties = d
        return workflow

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
