from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar(
    "T", bound="StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemValidationCheck"
)


@attr.s(auto_attribs=True)
class StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultInvalidObjectsItemErrorsItemValidationCheck:
    """
    Attributes:
        allow_empty (Union[Unset, bool]):
        max_length (Union[Unset, int]):
        regex (Union[Unset, str]):
    """

    allow_empty: Union[Unset, bool] = False
    max_length: Union[Unset, int] = UNSET
    regex: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        allow_empty = self.allow_empty
        max_length = self.max_length
        regex = self.regex

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if allow_empty is not UNSET:
            field_dict["allow_empty"] = allow_empty
        if max_length is not UNSET:
            field_dict["max_length"] = max_length
        if regex is not UNSET:
            field_dict["regex"] = regex

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        allow_empty = d.pop("allow_empty", UNSET)

        max_length = d.pop("max_length", UNSET)

        regex = d.pop("regex", UNSET)

        status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item_validation_check = cls(
            allow_empty=allow_empty,
            max_length=max_length,
            regex=regex,
        )

        status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item_validation_check.additional_properties = (
            d
        )
        return status_of_an_sbom_document_analysis_document_analysis_result_invalid_objects_item_errors_item_validation_check

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
