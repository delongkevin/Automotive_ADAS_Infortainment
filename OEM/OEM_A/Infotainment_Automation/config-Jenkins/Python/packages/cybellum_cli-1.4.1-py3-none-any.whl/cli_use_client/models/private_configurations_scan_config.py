from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="PrivateConfigurationsScanConfig")


@attr.s(auto_attribs=True)
class PrivateConfigurationsScanConfig:
    """
    Attributes:
        advanced_autosar_identification (Union[Unset, bool]): Indicator if the advanced autosar identification logic is
            on - requires more computational power
        multi_architecture_scan (Union[Unset, bool]): Indicator if the multi architecture scan flag is on
    """

    advanced_autosar_identification: Union[Unset, bool] = False
    multi_architecture_scan: Union[Unset, bool] = False
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        advanced_autosar_identification = self.advanced_autosar_identification
        multi_architecture_scan = self.multi_architecture_scan

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if advanced_autosar_identification is not UNSET:
            field_dict["advanced_autosar_identification"] = advanced_autosar_identification
        if multi_architecture_scan is not UNSET:
            field_dict["multi_architecture_scan"] = multi_architecture_scan

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        advanced_autosar_identification = d.pop("advanced_autosar_identification", UNSET)

        multi_architecture_scan = d.pop("multi_architecture_scan", UNSET)

        private_configurations_scan_config = cls(
            advanced_autosar_identification=advanced_autosar_identification,
            multi_architecture_scan=multi_architecture_scan,
        )

        private_configurations_scan_config.additional_properties = d
        return private_configurations_scan_config

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
