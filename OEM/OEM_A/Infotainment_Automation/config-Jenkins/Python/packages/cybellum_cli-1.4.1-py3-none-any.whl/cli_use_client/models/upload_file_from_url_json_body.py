from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="UploadFileFromUrlJsonBody")


@attr.s(auto_attribs=True)
class UploadFileFromUrlJsonBody:
    """
    Attributes:
        file_id (str): ID
        session_id (str): Unique identifier for the upload session
        url (str): The URL to download from
        file_name (Union[Unset, str]): The filename to use for the downloaded file If not specified, the filename will
            be derived from the URL
    """

    file_id: str
    session_id: str
    url: str
    file_name: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        file_id = self.file_id
        session_id = self.session_id
        url = self.url
        file_name = self.file_name

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "file_id": file_id,
                "sessionId": session_id,
                "url": url,
            }
        )
        if file_name is not UNSET:
            field_dict["file_name"] = file_name

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        file_id = d.pop("file_id")

        session_id = d.pop("sessionId")

        url = d.pop("url")

        file_name = d.pop("file_name", UNSET)

        upload_file_from_url_json_body = cls(
            file_id=file_id,
            session_id=session_id,
            url=url,
            file_name=file_name,
        )

        upload_file_from_url_json_body.additional_properties = d
        return upload_file_from_url_json_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
