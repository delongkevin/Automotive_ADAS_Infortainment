from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="VulnerabilitiesAssessmentVirtualAnalystProfile")


@attr.s(auto_attribs=True)
class VulnerabilitiesAssessmentVirtualAnalystProfile:
    """Vulnerabilities assessment virtual analyst profile

    Attributes:
        auto_start (Union[Unset, bool]): Inficator if the virtual analyst should start automatically
        name (Union[Unset, str]): Used virtual analyst profile name
    """

    auto_start: Union[Unset, bool] = False
    name: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        auto_start = self.auto_start
        name = self.name

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if auto_start is not UNSET:
            field_dict["auto_start"] = auto_start
        if name is not UNSET:
            field_dict["name"] = name

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        auto_start = d.pop("auto_start", UNSET)

        name = d.pop("name", UNSET)

        vulnerabilities_assessment_virtual_analyst_profile = cls(
            auto_start=auto_start,
            name=name,
        )

        vulnerabilities_assessment_virtual_analyst_profile.additional_properties = d
        return vulnerabilities_assessment_virtual_analyst_profile

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
