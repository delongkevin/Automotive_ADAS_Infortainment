from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="AttachedElementsVirtualDt")


@attr.s(auto_attribs=True)
class AttachedElementsVirtualDt:
    """
    Attributes:
        id (str): Virtual digital twin id
        name (str): Virtual digital twin name
        parent_id (str): ID
        risk (float): Risk
        type (str): Virtual digital twin type
        weight (Union[Unset, float]): The weight of the attached elements in terms of risk
    """

    id: str
    name: str
    parent_id: str
    risk: float
    type: str
    weight: Union[Unset, float] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        id = self.id
        name = self.name
        parent_id = self.parent_id
        risk = self.risk
        type = self.type
        weight = self.weight

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "parent_id": parent_id,
                "risk": risk,
                "type": type,
            }
        )
        if weight is not UNSET:
            field_dict["weight"] = weight

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        id = d.pop("id")

        name = d.pop("name")

        parent_id = d.pop("parent_id")

        risk = d.pop("risk")

        type = d.pop("type")

        weight = d.pop("weight", UNSET)

        attached_elements_virtual_dt = cls(
            id=id,
            name=name,
            parent_id=parent_id,
            risk=risk,
            type=type,
            weight=weight,
        )

        attached_elements_virtual_dt.additional_properties = d
        return attached_elements_virtual_dt

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
