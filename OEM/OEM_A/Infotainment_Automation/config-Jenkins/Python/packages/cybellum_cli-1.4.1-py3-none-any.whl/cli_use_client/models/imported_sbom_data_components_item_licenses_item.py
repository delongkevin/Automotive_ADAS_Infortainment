from typing import Any, Dict, List, Type, TypeVar, Union, cast

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="ImportedSBOMDataComponentsItemLicensesItem")


@attr.s(auto_attribs=True)
class ImportedSBOMDataComponentsItemLicensesItem:
    """
    Attributes:
        string_type (str): Allowed values: "ID", "EXPRESSION", "NAME", "REFERENCE", "EXCEPTION"
        extracted_from_expression (Union[Unset, bool]):
        license_sources (Union[Unset, List[str]]):
        license_string (Union[Unset, str]):
        text_reference (Union[Unset, str]):
    """

    string_type: str
    extracted_from_expression: Union[Unset, bool] = UNSET
    license_sources: Union[Unset, List[str]] = UNSET
    license_string: Union[Unset, str] = UNSET
    text_reference: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        string_type = self.string_type
        extracted_from_expression = self.extracted_from_expression
        license_sources: Union[Unset, List[str]] = UNSET
        if not isinstance(self.license_sources, Unset):
            license_sources = self.license_sources

        license_string = self.license_string
        text_reference = self.text_reference

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "string_type": string_type,
            }
        )
        if extracted_from_expression is not UNSET:
            field_dict["extracted_from_expression"] = extracted_from_expression
        if license_sources is not UNSET:
            field_dict["license_sources"] = license_sources
        if license_string is not UNSET:
            field_dict["license_string"] = license_string
        if text_reference is not UNSET:
            field_dict["text_reference"] = text_reference

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        string_type = d.pop("string_type")

        extracted_from_expression = d.pop("extracted_from_expression", UNSET)

        license_sources = cast(List[str], d.pop("license_sources", UNSET))

        license_string = d.pop("license_string", UNSET)

        text_reference = d.pop("text_reference", UNSET)

        imported_sbom_data_components_item_licenses_item = cls(
            string_type=string_type,
            extracted_from_expression=extracted_from_expression,
            license_sources=license_sources,
            license_string=license_string,
            text_reference=text_reference,
        )

        imported_sbom_data_components_item_licenses_item.additional_properties = d
        return imported_sbom_data_components_item_licenses_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
