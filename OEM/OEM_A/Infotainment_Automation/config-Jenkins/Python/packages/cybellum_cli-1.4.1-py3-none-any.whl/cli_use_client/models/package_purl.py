from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="PackagePURL")


@attr.s(auto_attribs=True)
class PackagePURL:
    """Package PURL

    Attributes:
        primary (Union[Unset, bool]): Is PURL primary
        product (Union[Unset, str]): PURL product
        text (Union[Unset, str]): PURL full text
        type (Union[Unset, str]): Package type or package protocol such as "maven", "npm", "nuget", "gem", "pypi", etc.
        vendor (Union[Unset, str]): PURL vendor
    """

    primary: Union[Unset, bool] = UNSET
    product: Union[Unset, str] = UNSET
    text: Union[Unset, str] = UNSET
    type: Union[Unset, str] = UNSET
    vendor: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        primary = self.primary
        product = self.product
        text = self.text
        type = self.type
        vendor = self.vendor

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if primary is not UNSET:
            field_dict["primary"] = primary
        if product is not UNSET:
            field_dict["product"] = product
        if text is not UNSET:
            field_dict["text"] = text
        if type is not UNSET:
            field_dict["type"] = type
        if vendor is not UNSET:
            field_dict["vendor"] = vendor

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        primary = d.pop("primary", UNSET)

        product = d.pop("product", UNSET)

        text = d.pop("text", UNSET)

        type = d.pop("type", UNSET)

        vendor = d.pop("vendor", UNSET)

        package_purl = cls(
            primary=primary,
            product=product,
            text=text,
            type=type,
            vendor=vendor,
        )

        package_purl.additional_properties = d
        return package_purl

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
