from enum import Enum
from typing import Union


class PropagationStrategy(str, Enum):
    REGULAR = "regular"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "PropagationStrategy"]) -> "PropagationStrategy":
        if isinstance(value, PropagationStrategy):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return PropagationStrategy(value)
