import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

import attr
from dateutil.parser import isoparse

from ..models.dt_user_permissions_item import DtUserPermissionsItem
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin_custom_fields import DigitalTwinCustomFields
    from ..models.digital_twin_version_base import DigitalTwinVersionBase


T = TypeVar("T", bound="DigitalTwin")


@attr.s(auto_attribs=True)
class DigitalTwin:
    """Digital twin

    Attributes:
        component_category (str): the component category of the digital twin

            for Vehicle Edition - the default possible values are:

            - adas
            - gateway
            - infotainment
            - power_steering
            - telecommunication
            - telematics
            - transmission_control_unit
            - key_fob
            - mobile_application_automotive
            - obd2_dongle
            - connected_ecu

            for Medical Edition - the default possible values are:

            - home_care_device
            - medical_imaging_system
            - other_medical_device
            - implantable_device
            - defibrillator
            - pacemaker
            - ventricular_assist_device
            - brain_stimulator
            - dialysis_device
            - infusion_insulin_pump
            - mobile_application_medical

            for IOT Edition - the default possible values are:

            - smart_home_device
            - smart_meter
            - energy_control_system
            - ip_camera
            - industrial_robot
            - mobile_application_iot
            - network_device
            - other_iot_device
            - storage_device
            - server
            - printer
            - pbx

            for Scanner - the default possible values are:

            - connected_component

            for all editions values can be customized by configuration
        created_by (str): the id of the user which created the digital twin
        created_on (datetime.datetime): the digital twin creation datetime
        dt_versions (List['DigitalTwinVersionBase']): the digital twin versions
        id (str): ID
        last_modified_on (datetime.datetime): the time when the digital twin was last modified
        name (str): the digital twin name
        user_dt_permissions (List[DtUserPermissionsItem]): Digital twin permissions Example: ['dt_work'].
        cal (Union[Unset, int]): Cybersecurity Assurance Level
        custom_fields (Union[Unset, DigitalTwinCustomFields]): Custom Fields
        description (Union[Unset, str]): the digital twin description
        micro_controller (Union[Unset, bool]): indicator if the digital twin is a micro controller
        model_name (Union[Unset, str]): the digital twin model name
        part_number (Union[Unset, str]): the digital twin part number
        tags (Union[Unset, List[str]]): the digital twin tags
        vendor (Union[Unset, str]): the digital twin vendor
        workflow_id (Union[Unset, str]): ID
    """

    component_category: str
    created_by: str
    created_on: datetime.datetime
    dt_versions: List["DigitalTwinVersionBase"]
    id: str
    last_modified_on: datetime.datetime
    name: str
    user_dt_permissions: List[DtUserPermissionsItem]
    cal: Union[Unset, int] = UNSET
    custom_fields: Union[Unset, "DigitalTwinCustomFields"] = UNSET
    description: Union[Unset, str] = UNSET
    micro_controller: Union[Unset, bool] = UNSET
    model_name: Union[Unset, str] = UNSET
    part_number: Union[Unset, str] = UNSET
    tags: Union[Unset, List[str]] = UNSET
    vendor: Union[Unset, str] = UNSET
    workflow_id: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        component_category = self.component_category
        created_by = self.created_by
        created_on = self.created_on.isoformat()

        dt_versions = []
        for dt_versions_item_data in self.dt_versions:
            dt_versions_item = dt_versions_item_data.to_dict()

            dt_versions.append(dt_versions_item)

        id = self.id
        last_modified_on = self.last_modified_on.isoformat()

        name = self.name
        user_dt_permissions = []
        for componentsschemasdt_user_permissions_item_data in self.user_dt_permissions:
            componentsschemasdt_user_permissions_item = DtUserPermissionsItem.from_val(
                componentsschemasdt_user_permissions_item_data
            ).value

            user_dt_permissions.append(componentsschemasdt_user_permissions_item)

        cal = self.cal
        custom_fields: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        description = self.description
        micro_controller = self.micro_controller
        model_name = self.model_name
        part_number = self.part_number
        tags: Union[Unset, List[str]] = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        vendor = self.vendor
        workflow_id = self.workflow_id

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "component_category": component_category,
                "created_by": created_by,
                "created_on": created_on,
                "dt_versions": dt_versions,
                "id": id,
                "last_modified_on": last_modified_on,
                "name": name,
                "user_dt_permissions": user_dt_permissions,
            }
        )
        if cal is not UNSET:
            field_dict["cal"] = cal
        if custom_fields is not UNSET:
            field_dict["custom_fields"] = custom_fields
        if description is not UNSET:
            field_dict["description"] = description
        if micro_controller is not UNSET:
            field_dict["micro_controller"] = micro_controller
        if model_name is not UNSET:
            field_dict["model_name"] = model_name
        if part_number is not UNSET:
            field_dict["part_number"] = part_number
        if tags is not UNSET:
            field_dict["tags"] = tags
        if vendor is not UNSET:
            field_dict["vendor"] = vendor
        if workflow_id is not UNSET:
            field_dict["workflow_id"] = workflow_id

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin_custom_fields import DigitalTwinCustomFields
        from ..models.digital_twin_version_base import DigitalTwinVersionBase

        d = src_dict.copy()
        component_category = d.pop("component_category")

        created_by = d.pop("created_by")

        created_on = isoparse(d.pop("created_on"))

        _dt_versions = d.pop("dt_versions")
        dt_versions = []
        for dt_versions_item_data in _dt_versions:
            dt_versions_item = DigitalTwinVersionBase.from_dict(dt_versions_item_data)

            dt_versions.append(dt_versions_item)

        id = d.pop("id")

        last_modified_on = isoparse(d.pop("last_modified_on"))

        name = d.pop("name")

        _user_dt_permissions = d.pop("user_dt_permissions")
        user_dt_permissions = []
        for componentsschemasdt_user_permissions_item_data in _user_dt_permissions:
            componentsschemasdt_user_permissions_item = DtUserPermissionsItem.from_val(
                componentsschemasdt_user_permissions_item_data
            )

            user_dt_permissions.append(componentsschemasdt_user_permissions_item)

        cal = d.pop("cal", UNSET)

        _custom_fields = d.pop("custom_fields", UNSET)
        custom_fields: Union[Unset, DigitalTwinCustomFields]
        if isinstance(_custom_fields, Unset):
            custom_fields = UNSET
        else:
            custom_fields = DigitalTwinCustomFields.from_dict(_custom_fields)

        description = d.pop("description", UNSET)

        micro_controller = d.pop("micro_controller", UNSET)

        model_name = d.pop("model_name", UNSET)

        part_number = d.pop("part_number", UNSET)

        tags = cast(List[str], d.pop("tags", UNSET))

        vendor = d.pop("vendor", UNSET)

        workflow_id = d.pop("workflow_id", UNSET)

        digital_twin = cls(
            component_category=component_category,
            created_by=created_by,
            created_on=created_on,
            dt_versions=dt_versions,
            id=id,
            last_modified_on=last_modified_on,
            name=name,
            user_dt_permissions=user_dt_permissions,
            cal=cal,
            custom_fields=custom_fields,
            description=description,
            micro_controller=micro_controller,
            model_name=model_name,
            part_number=part_number,
            tags=tags,
            vendor=vendor,
            workflow_id=workflow_id,
        )

        digital_twin.additional_properties = d
        return digital_twin

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
