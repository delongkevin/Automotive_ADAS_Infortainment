from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar

import attr

if TYPE_CHECKING:
    from ..models.get_global_packages_database_version_response_200_data_db_version import (
        GetGlobalPackagesDatabaseVersionResponse200DataDbVersion,
    )
    from ..models.get_global_packages_database_version_response_200_data_metadata_db_version import (
        GetGlobalPackagesDatabaseVersionResponse200DataMetadataDbVersion,
    )


T = TypeVar("T", bound="GetGlobalPackagesDatabaseVersionResponse200Data")


@attr.s(auto_attribs=True)
class GetGlobalPackagesDatabaseVersionResponse200Data:
    """
    Attributes:
        db_version (GetGlobalPackagesDatabaseVersionResponse200DataDbVersion): Database version object
        metadata_db_version (GetGlobalPackagesDatabaseVersionResponse200DataMetadataDbVersion): Metadata database
            version
    """

    db_version: "GetGlobalPackagesDatabaseVersionResponse200DataDbVersion"
    metadata_db_version: "GetGlobalPackagesDatabaseVersionResponse200DataMetadataDbVersion"
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        db_version = self.db_version.to_dict()

        metadata_db_version = self.metadata_db_version.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "db_version": db_version,
                "metadata_db_version": metadata_db_version,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.get_global_packages_database_version_response_200_data_db_version import (
            GetGlobalPackagesDatabaseVersionResponse200DataDbVersion,
        )
        from ..models.get_global_packages_database_version_response_200_data_metadata_db_version import (
            GetGlobalPackagesDatabaseVersionResponse200DataMetadataDbVersion,
        )

        d = src_dict.copy()
        db_version = GetGlobalPackagesDatabaseVersionResponse200DataDbVersion.from_dict(d.pop("db_version"))

        metadata_db_version = GetGlobalPackagesDatabaseVersionResponse200DataMetadataDbVersion.from_dict(
            d.pop("metadata_db_version")
        )

        get_global_packages_database_version_response_200_data = cls(
            db_version=db_version,
            metadata_db_version=metadata_db_version,
        )

        get_global_packages_database_version_response_200_data.additional_properties = d
        return get_global_packages_database_version_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
