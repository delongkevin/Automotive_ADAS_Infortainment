from enum import Enum
from typing import Union


class SBOMPackageInfoConfidenceLevel(str, Enum):
    LOW = "low"

    MEDIUM = "medium"

    HIGH = "high"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "SBOMPackageInfoConfidenceLevel"]) -> "SBOMPackageInfoConfidenceLevel":
        if isinstance(value, SBOMPackageInfoConfidenceLevel):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return SBOMPackageInfoConfidenceLevel(value)
