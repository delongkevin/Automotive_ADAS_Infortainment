from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.get_vulnerabilities_database_version_response_200_data_db_version import (
        GetVulnerabilitiesDatabaseVersionResponse200DataDbVersion,
    )


T = TypeVar("T", bound="GetVulnerabilitiesDatabaseVersionResponse200Data")


@attr.s(auto_attribs=True)
class GetVulnerabilitiesDatabaseVersionResponse200Data:
    """
    Attributes:
        db_version (Union[Unset, GetVulnerabilitiesDatabaseVersionResponse200DataDbVersion]): Database version
    """

    db_version: Union[Unset, "GetVulnerabilitiesDatabaseVersionResponse200DataDbVersion"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        db_version: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.db_version, Unset):
            db_version = self.db_version.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if db_version is not UNSET:
            field_dict["db_version"] = db_version

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.get_vulnerabilities_database_version_response_200_data_db_version import (
            GetVulnerabilitiesDatabaseVersionResponse200DataDbVersion,
        )

        d = src_dict.copy()
        _db_version = d.pop("db_version", UNSET)
        db_version: Union[Unset, GetVulnerabilitiesDatabaseVersionResponse200DataDbVersion]
        if isinstance(_db_version, Unset):
            db_version = UNSET
        else:
            db_version = GetVulnerabilitiesDatabaseVersionResponse200DataDbVersion.from_dict(_db_version)

        get_vulnerabilities_database_version_response_200_data = cls(
            db_version=db_version,
        )

        get_vulnerabilities_database_version_response_200_data.additional_properties = d
        return get_vulnerabilities_database_version_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
