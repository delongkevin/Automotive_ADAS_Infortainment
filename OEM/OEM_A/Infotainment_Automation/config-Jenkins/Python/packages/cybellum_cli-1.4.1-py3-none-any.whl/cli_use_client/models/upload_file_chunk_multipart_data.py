from io import BytesIO
from typing import Any, Dict, List, Tuple, Type, TypeVar

import attr

from ..client import flatten_params
from ..types import UNSET, File

T = TypeVar("T", bound="UploadFileChunkMultipartData")


@attr.s(auto_attribs=True)
class UploadFileChunkMultipartData:
    """
    Attributes:
        file (File): The chunk of file
        resumable_chunk_number (float): Resumable chunk number
        resumable_current_chunk_size (float): Resumable current chunk size
        resumable_file_name (str): Resumable file name
        resumable_identifier (str): Resumable identifier
        resumable_total_chunks (float): Resumable total chunks
        resumable_total_size (float): Resumable total size
        session_id (str): ID
    """

    file: File
    resumable_chunk_number: float
    resumable_current_chunk_size: float
    resumable_file_name: str
    resumable_identifier: str
    resumable_total_chunks: float
    resumable_total_size: float
    session_id: str
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        file = self.file.to_tuple()

        resumable_chunk_number = self.resumable_chunk_number
        resumable_current_chunk_size = self.resumable_current_chunk_size
        resumable_file_name = self.resumable_file_name
        resumable_identifier = self.resumable_identifier
        resumable_total_chunks = self.resumable_total_chunks
        resumable_total_size = self.resumable_total_size
        session_id = self.session_id

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "file": file,
                "resumable_chunk_number": resumable_chunk_number,
                "resumable_current_chunk_size": resumable_current_chunk_size,
                "resumable_file_name": resumable_file_name,
                "resumable_identifier": resumable_identifier,
                "resumable_total_chunks": resumable_total_chunks,
                "resumable_total_size": resumable_total_size,
                "session_id": session_id,
            }
        )

        return field_dict

    def to_multipart(self) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        self_dict = self.to_dict()
        self_dict = flatten_params(self_dict)
        data = {
            key: value
            for key, value in self_dict.items()
            if value is not None and value is not UNSET and not isinstance(value, File) and not isinstance(value, Tuple)
        }
        files = {
            key: value.to_tuple() if isinstance(value, File) else value
            for key, value in self_dict.items()
            if value is not None and value is not UNSET and (isinstance(value, File) or isinstance(value, Tuple))
        }
        return (data, files)

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _file = d.pop("file")
        file: File

        if isinstance(_file, File):
            file = _file
        else:
            file = File(payload=BytesIO(_file))

        resumable_chunk_number = d.pop("resumable_chunk_number")

        resumable_current_chunk_size = d.pop("resumable_current_chunk_size")

        resumable_file_name = d.pop("resumable_file_name")

        resumable_identifier = d.pop("resumable_identifier")

        resumable_total_chunks = d.pop("resumable_total_chunks")

        resumable_total_size = d.pop("resumable_total_size")

        session_id = d.pop("session_id")

        upload_file_chunk_multipart_data = cls(
            file=file,
            resumable_chunk_number=resumable_chunk_number,
            resumable_current_chunk_size=resumable_current_chunk_size,
            resumable_file_name=resumable_file_name,
            resumable_identifier=resumable_identifier,
            resumable_total_chunks=resumable_total_chunks,
            resumable_total_size=resumable_total_size,
            session_id=session_id,
        )

        upload_file_chunk_multipart_data.additional_properties = d
        return upload_file_chunk_multipart_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
