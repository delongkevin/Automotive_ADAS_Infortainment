from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="ImportedSBOMDataPrimaryComponentSwid")


@attr.s(auto_attribs=True)
class ImportedSBOMDataPrimaryComponentSwid:
    """
    Attributes:
        name (str):
        tag_id (str): alias="tagId"
        patch (Union[Unset, bool]):
        tag_version (Union[Unset, int]): alias="tagVersion"
        text (Union[Unset, str]):
        url (Union[Unset, str]):
        version (Union[Unset, str]):
    """

    name: str
    tag_id: str
    patch: Union[Unset, bool] = UNSET
    tag_version: Union[Unset, int] = UNSET
    text: Union[Unset, str] = UNSET
    url: Union[Unset, str] = UNSET
    version: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        name = self.name
        tag_id = self.tag_id
        patch = self.patch
        tag_version = self.tag_version
        text = self.text
        url = self.url
        version = self.version

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "tag_id": tag_id,
            }
        )
        if patch is not UNSET:
            field_dict["patch"] = patch
        if tag_version is not UNSET:
            field_dict["tag_version"] = tag_version
        if text is not UNSET:
            field_dict["text"] = text
        if url is not UNSET:
            field_dict["url"] = url
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        name = d.pop("name")

        tag_id = d.pop("tag_id")

        patch = d.pop("patch", UNSET)

        tag_version = d.pop("tag_version", UNSET)

        text = d.pop("text", UNSET)

        url = d.pop("url", UNSET)

        version = d.pop("version", UNSET)

        imported_sbom_data_primary_component_swid = cls(
            name=name,
            tag_id=tag_id,
            patch=patch,
            tag_version=tag_version,
            text=text,
            url=url,
            version=version,
        )

        imported_sbom_data_primary_component_swid.additional_properties = d
        return imported_sbom_data_primary_component_swid

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
