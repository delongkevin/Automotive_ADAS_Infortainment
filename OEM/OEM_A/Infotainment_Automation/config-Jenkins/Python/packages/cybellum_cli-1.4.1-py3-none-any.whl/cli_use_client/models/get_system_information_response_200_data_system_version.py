import datetime
from typing import Any, Dict, List, Type, TypeVar

import attr
from dateutil.parser import isoparse

T = TypeVar("T", bound="GetSystemInformationResponse200DataSystemVersion")


@attr.s(auto_attribs=True)
class GetSystemInformationResponse200DataSystemVersion:
    """System version

    Attributes:
        commit (str): Version commit
        date (datetime.datetime): Date time Example: 2023-04-01T00:00:00Z.
        version (str): Version name
    """

    commit: str
    date: datetime.datetime
    version: str
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        commit = self.commit
        date = self.date.isoformat()

        version = self.version

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "commit": commit,
                "date": date,
                "version": version,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        commit = d.pop("commit")

        date = isoparse(d.pop("date"))

        version = d.pop("version")

        get_system_information_response_200_data_system_version = cls(
            commit=commit,
            date=date,
            version=version,
        )

        get_system_information_response_200_data_system_version.additional_properties = d
        return get_system_information_response_200_data_system_version

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
