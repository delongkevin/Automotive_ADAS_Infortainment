""" Contains shared errors types that can be raised from API functions """


class DependencyCheckError(Exception): ...


class EndpointNotConfigured(Exception):
    """Raised by the client when endpoint base url can not be determined"""

    ...


class UnauthenticatedClient(Exception):
    """Raised by the api functions when the passed client is not authenticated in an attempt to call a secure endpoint"""

    ...


class UnexpectedStatus(Exception):
    """Raised by api functions when the response status an undocumented status and Client.raise_on_unexpected_status is True"""

    ...


class FailedStatus(Exception):
    """Raised by api functions when the response status is a failed status and Client.raise_on_failed_status is True"""

    def __init__(self, message, response=None, status_code=None):
        self.message = message
        self.response = response
        self.status_code = status_code

    def __str__(self):
        return self.message


class ParseError(Exception):
    """Raised by api functions when the response content does not manage to be parsed"""

    def __init__(self, message, response, exception):
        self.message = message
        self.response = response
        self.exception = exception

    def __str__(self):
        return self.message


__all__ = ["UnexpectedStatus"]
