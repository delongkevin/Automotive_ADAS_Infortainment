from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.status_of_an_sbom_document_analysis_document_analysis_result_score_package_information import (
        StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScorePackageInformation,
    )


T = TypeVar("T", bound="StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScore")


@attr.s(auto_attribs=True)
class StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScore:
    """SBOMScore

    Attributes:
        compliant (Union[Unset, str]): "passed" or "failed"
        package_information (Union[Unset, StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScorePackageInformation]):
        score (Union[Unset, int]):
        score_level (Union[Unset, str]): "poor", "fair", "good" or "excellent"
    """

    compliant: Union[Unset, str] = UNSET
    package_information: Union[Unset, "StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScorePackageInformation"] = (
        UNSET
    )
    score: Union[Unset, int] = UNSET
    score_level: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        compliant = self.compliant
        package_information: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.package_information, Unset):
            package_information = self.package_information.to_dict()

        score = self.score
        score_level = self.score_level

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if compliant is not UNSET:
            field_dict["compliant"] = compliant
        if package_information is not UNSET:
            field_dict["package_information"] = package_information
        if score is not UNSET:
            field_dict["score"] = score
        if score_level is not UNSET:
            field_dict["score_level"] = score_level

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.status_of_an_sbom_document_analysis_document_analysis_result_score_package_information import (
            StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScorePackageInformation,
        )

        d = src_dict.copy()
        compliant = d.pop("compliant", UNSET)

        _package_information = d.pop("package_information", UNSET)
        package_information: Union[Unset, StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScorePackageInformation]
        if isinstance(_package_information, Unset):
            package_information = UNSET
        else:
            package_information = StatusOfAnSBOMDocumentAnalysisDocumentAnalysisResultScorePackageInformation.from_dict(
                _package_information
            )

        score = d.pop("score", UNSET)

        score_level = d.pop("score_level", UNSET)

        status_of_an_sbom_document_analysis_document_analysis_result_score = cls(
            compliant=compliant,
            package_information=package_information,
            score=score,
            score_level=score_level,
        )

        status_of_an_sbom_document_analysis_document_analysis_result_score.additional_properties = d
        return status_of_an_sbom_document_analysis_document_analysis_result_score

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
