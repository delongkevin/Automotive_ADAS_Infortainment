from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar

import attr

from ..models.element_type import ElementType
from ..models.product_connection_type import ProductConnectionType

if TYPE_CHECKING:
    from ..models.properties import Properties


T = TypeVar("T", bound="Connection")


@attr.s(auto_attribs=True)
class Connection:
    """Connection

    Attributes:
        dst_element_id (str): ID
        dst_element_type (ElementType): Element type
        id (str): ID
        properties (Properties): Properties
        src_element_id (str): ID
        src_element_type (ElementType): Element type
        type (ProductConnectionType): Product connection type
    """

    dst_element_id: str
    dst_element_type: ElementType
    id: str
    properties: "Properties"
    src_element_id: str
    src_element_type: ElementType
    type: ProductConnectionType
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        dst_element_id = self.dst_element_id
        dst_element_type = ElementType.from_val(self.dst_element_type).value

        id = self.id
        properties = self.properties.to_dict()

        src_element_id = self.src_element_id
        src_element_type = ElementType.from_val(self.src_element_type).value

        type = ProductConnectionType.from_val(self.type).value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "dst_element_id": dst_element_id,
                "dst_element_type": dst_element_type,
                "id": id,
                "properties": properties,
                "src_element_id": src_element_id,
                "src_element_type": src_element_type,
                "type": type,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.properties import Properties

        d = src_dict.copy()
        dst_element_id = d.pop("dst_element_id")

        dst_element_type = ElementType.from_val(d.pop("dst_element_type"))

        id = d.pop("id")

        properties = Properties.from_dict(d.pop("properties"))

        src_element_id = d.pop("src_element_id")

        src_element_type = ElementType.from_val(d.pop("src_element_type"))

        type = ProductConnectionType.from_val(d.pop("type"))

        connection = cls(
            dst_element_id=dst_element_id,
            dst_element_type=dst_element_type,
            id=id,
            properties=properties,
            src_element_id=src_element_id,
            src_element_type=src_element_type,
            type=type,
        )

        connection.additional_properties = d
        return connection

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
