from enum import Enum
from typing import Union


class ScanState(str, Enum):
    QUEUED = "queued"

    RUNNING = "running"

    COMPLETED = "completed"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "ScanState"]) -> "ScanState":
        if isinstance(value, ScanState):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return ScanState(value)
