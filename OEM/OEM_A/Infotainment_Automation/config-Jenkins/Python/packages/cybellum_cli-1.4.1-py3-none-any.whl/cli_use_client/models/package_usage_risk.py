from enum import Enum
from typing import Union


class PackageUsageRisk(str, Enum):
    HIGH = "high"

    MEDIUM = "medium"

    LOW = "low"

    NO_RISK = "no_risk"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "PackageUsageRisk"]) -> "PackageUsageRisk":
        if isinstance(value, PackageUsageRisk):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return PackageUsageRisk(value)
