from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="OperatingSystem")


@attr.s(auto_attribs=True)
class OperatingSystem:
    """Digital twin operation system

    Attributes:
        kernel (Union[Unset, str]): kernel name
        kernel_version (Union[Unset, str]): kernel version
        name (Union[Unset, str]): operration system name
        patch_level (Union[Unset, str]): operation system patch level
        service_pack (Union[Unset, str]): operation system service pack
        version (Union[Unset, str]): operation system version
    """

    kernel: Union[Unset, str] = UNSET
    kernel_version: Union[Unset, str] = UNSET
    name: Union[Unset, str] = UNSET
    patch_level: Union[Unset, str] = UNSET
    service_pack: Union[Unset, str] = UNSET
    version: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        kernel = self.kernel
        kernel_version = self.kernel_version
        name = self.name
        patch_level = self.patch_level
        service_pack = self.service_pack
        version = self.version

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if kernel is not UNSET:
            field_dict["kernel"] = kernel
        if kernel_version is not UNSET:
            field_dict["kernel_version"] = kernel_version
        if name is not UNSET:
            field_dict["name"] = name
        if patch_level is not UNSET:
            field_dict["patch_level"] = patch_level
        if service_pack is not UNSET:
            field_dict["service_pack"] = service_pack
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        kernel = d.pop("kernel", UNSET)

        kernel_version = d.pop("kernel_version", UNSET)

        name = d.pop("name", UNSET)

        patch_level = d.pop("patch_level", UNSET)

        service_pack = d.pop("service_pack", UNSET)

        version = d.pop("version", UNSET)

        operating_system = cls(
            kernel=kernel,
            kernel_version=kernel_version,
            name=name,
            patch_level=patch_level,
            service_pack=service_pack,
            version=version,
        )

        operating_system.additional_properties = d
        return operating_system

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
