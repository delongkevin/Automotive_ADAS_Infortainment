from enum import Enum
from typing import Union


class ResumableUploadFileType(str, Enum):
    FILE = "file"

    URL = "url"

    INTEGRATION = "integration"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "ResumableUploadFileType"]) -> "ResumableUploadFileType":
        if isinstance(value, ResumableUploadFileType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return ResumableUploadFileType(value)
