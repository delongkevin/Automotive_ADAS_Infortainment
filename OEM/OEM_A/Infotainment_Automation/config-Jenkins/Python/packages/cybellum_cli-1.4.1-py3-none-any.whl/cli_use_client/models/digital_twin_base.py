import datetime
from typing import Any, Dict, List, Type, TypeVar, Union, cast

import attr
from dateutil.parser import isoparse

from ..models.dt_user_permissions_item import DtUserPermissionsItem
from ..types import UNSET, Unset

T = TypeVar("T", bound="DigitalTwinBase")


@attr.s(auto_attribs=True)
class DigitalTwinBase:
    """Digital twin base

    Attributes:
        component_category (Union[Unset, str]): the component category of the digital twin

            for Vehicle Edition - the default possible values are:

            - adas
            - gateway
            - infotainment
            - power_steering
            - telecommunication
            - telematics
            - transmission_control_unit
            - key_fob
            - mobile_application_automotive
            - obd2_dongle
            - connected_ecu

            for Medical Edition - the default possible values are:

            - home_care_device
            - medical_imaging_system
            - other_medical_device
            - implantable_device
            - defibrillator
            - pacemaker
            - ventricular_assist_device
            - brain_stimulator
            - dialysis_device
            - infusion_insulin_pump
            - mobile_application_medical

            for IOT Edition - the default possible values are:

            - smart_home_device
            - smart_meter
            - energy_control_system
            - ip_camera
            - industrial_robot
            - mobile_application_iot
            - network_device
            - other_iot_device
            - storage_device
            - server
            - printer
            - pbx

            for Scanner - the default possible values are:

            - connected_component

            for all editions values can be customized by configuration
        created_by (Union[Unset, str]): the id of the user created the digital twin
        created_on (Union[Unset, datetime.datetime]): digital twin creation time
        description (Union[Unset, str]): digital twin description
        id (Union[Unset, str]): ID
        last_modified_on (Union[Unset, datetime.datetime]): digital twin last modified time
        micro_controller (Union[Unset, bool]): indicator if the digital twin is a micro-controller
        model_name (Union[Unset, str]): digital twin model name
        name (Union[Unset, str]): digital twin name
        parent_id (Union[Unset, str]): ID
        part_number (Union[Unset, str]): digital twin part number
        tags (Union[Unset, List[str]]): digital twin tags
        user_dt_permissions (Union[Unset, List[DtUserPermissionsItem]]): Digital twin permissions Example: ['dt_work'].
        vendor (Union[Unset, str]): digital twin vendor
        workflow_id (Union[Unset, str]): ID
    """

    component_category: Union[Unset, str] = UNSET
    created_by: Union[Unset, str] = UNSET
    created_on: Union[Unset, datetime.datetime] = UNSET
    description: Union[Unset, str] = UNSET
    id: Union[Unset, str] = UNSET
    last_modified_on: Union[Unset, datetime.datetime] = UNSET
    micro_controller: Union[Unset, bool] = UNSET
    model_name: Union[Unset, str] = UNSET
    name: Union[Unset, str] = UNSET
    parent_id: Union[Unset, str] = UNSET
    part_number: Union[Unset, str] = UNSET
    tags: Union[Unset, List[str]] = UNSET
    user_dt_permissions: Union[Unset, List[DtUserPermissionsItem]] = UNSET
    vendor: Union[Unset, str] = UNSET
    workflow_id: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        component_category = self.component_category
        created_by = self.created_by
        created_on: Union[Unset, str] = UNSET
        if not isinstance(self.created_on, Unset):
            created_on = self.created_on.isoformat()

        description = self.description
        id = self.id
        last_modified_on: Union[Unset, str] = UNSET
        if not isinstance(self.last_modified_on, Unset):
            last_modified_on = self.last_modified_on.isoformat()

        micro_controller = self.micro_controller
        model_name = self.model_name
        name = self.name
        parent_id = self.parent_id
        part_number = self.part_number
        tags: Union[Unset, List[str]] = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        user_dt_permissions: Union[Unset, List[str]] = UNSET
        if not isinstance(self.user_dt_permissions, Unset):
            user_dt_permissions = []
            for componentsschemasdt_user_permissions_item_data in self.user_dt_permissions:
                componentsschemasdt_user_permissions_item = DtUserPermissionsItem.from_val(
                    componentsschemasdt_user_permissions_item_data
                ).value

                user_dt_permissions.append(componentsschemasdt_user_permissions_item)

        vendor = self.vendor
        workflow_id = self.workflow_id

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if component_category is not UNSET:
            field_dict["component_category"] = component_category
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if created_on is not UNSET:
            field_dict["created_on"] = created_on
        if description is not UNSET:
            field_dict["description"] = description
        if id is not UNSET:
            field_dict["id"] = id
        if last_modified_on is not UNSET:
            field_dict["last_modified_on"] = last_modified_on
        if micro_controller is not UNSET:
            field_dict["micro_controller"] = micro_controller
        if model_name is not UNSET:
            field_dict["model_name"] = model_name
        if name is not UNSET:
            field_dict["name"] = name
        if parent_id is not UNSET:
            field_dict["parent_id"] = parent_id
        if part_number is not UNSET:
            field_dict["part_number"] = part_number
        if tags is not UNSET:
            field_dict["tags"] = tags
        if user_dt_permissions is not UNSET:
            field_dict["user_dt_permissions"] = user_dt_permissions
        if vendor is not UNSET:
            field_dict["vendor"] = vendor
        if workflow_id is not UNSET:
            field_dict["workflow_id"] = workflow_id

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        component_category = d.pop("component_category", UNSET)

        created_by = d.pop("created_by", UNSET)

        _created_on = d.pop("created_on", UNSET)
        created_on: Union[Unset, datetime.datetime]
        if isinstance(_created_on, Unset):
            created_on = UNSET
        else:
            created_on = isoparse(_created_on)

        description = d.pop("description", UNSET)

        id = d.pop("id", UNSET)

        _last_modified_on = d.pop("last_modified_on", UNSET)
        last_modified_on: Union[Unset, datetime.datetime]
        if isinstance(_last_modified_on, Unset):
            last_modified_on = UNSET
        else:
            last_modified_on = isoparse(_last_modified_on)

        micro_controller = d.pop("micro_controller", UNSET)

        model_name = d.pop("model_name", UNSET)

        name = d.pop("name", UNSET)

        parent_id = d.pop("parent_id", UNSET)

        part_number = d.pop("part_number", UNSET)

        tags = cast(List[str], d.pop("tags", UNSET))

        _user_dt_permissions = d.pop("user_dt_permissions", UNSET)
        if (_user_dt_permissions) is UNSET:
            user_dt_permissions = UNSET
        else:
            if _user_dt_permissions:
                user_dt_permissions = []
                for componentsschemasdt_user_permissions_item_data in _user_dt_permissions:
                    componentsschemasdt_user_permissions_item = DtUserPermissionsItem.from_val(
                        componentsschemasdt_user_permissions_item_data
                    )

                    user_dt_permissions.append(componentsschemasdt_user_permissions_item)
            else:
                user_dt_permissions = []

        vendor = d.pop("vendor", UNSET)

        workflow_id = d.pop("workflow_id", UNSET)

        digital_twin_base = cls(
            component_category=component_category,
            created_by=created_by,
            created_on=created_on,
            description=description,
            id=id,
            last_modified_on=last_modified_on,
            micro_controller=micro_controller,
            model_name=model_name,
            name=name,
            parent_id=parent_id,
            part_number=part_number,
            tags=tags,
            user_dt_permissions=user_dt_permissions,
            vendor=vendor,
            workflow_id=workflow_id,
        )

        digital_twin_base.additional_properties = d
        return digital_twin_base

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
