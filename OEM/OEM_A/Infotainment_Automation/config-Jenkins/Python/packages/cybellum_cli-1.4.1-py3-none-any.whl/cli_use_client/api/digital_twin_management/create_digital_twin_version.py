from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, AuthenticationStatus, Client, ParseResponseBehavior, flatten_params
from ...models.create_digital_twin_version_multipart_data import CreateDigitalTwinVersionMultipartData
from ...models.create_digital_twin_version_response_200 import CreateDigitalTwinVersionResponse200
from ...models.error import Error
from ...types import Response


def _get_kwargs(
    *,
    client: AuthenticatedClient,
    multipart_data: CreateDigitalTwinVersionMultipartData,
) -> Dict[str, Any]:
    url = "{}/dts/create_dt_version".format(client.get_service_url("digital-twins"))

    headers: Dict[str, str] = client.get_headers()
    cookies: Dict[str, Any] = client.get_cookies()

    (multipart_data_data, multipart_data_files) = multipart_data.to_multipart()

    return {
        "method": "post",
        "url": url,
        "headers": headers,
        "cookies": cookies,
        "timeout": client.get_timeout(),
        "data": flatten_params(multipart_data_data),
        "files": multipart_data_files,
    }


def _parse_response(
    *, client: Client, response: httpx.Response
) -> Optional[Union[CreateDigitalTwinVersionResponse200, Error]]:
    if response.status_code == HTTPStatus.OK:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_200 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_200 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_200 = CreateDigitalTwinVersionResponse200.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        return response_200

    if response.status_code == HTTPStatus.BAD_REQUEST:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_400 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_400 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_400 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_400, status_code=response.status_code
            )
        return response_400

    if response.status_code == HTTPStatus.UNAUTHORIZED:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_401 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_401 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_401 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_401, status_code=response.status_code
            )
        return response_401

    if response.status_code == HTTPStatus.FORBIDDEN:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_403 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_403 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_403 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_403, status_code=response.status_code
            )
        return response_403

    if response.status_code == HTTPStatus.NOT_FOUND:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_404 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_404 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_404 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_404, status_code=response.status_code
            )
        return response_404

    if response.status_code == HTTPStatus.METHOD_NOT_ALLOWED:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_405 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_405 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_405 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_405, status_code=response.status_code
            )
        return response_405

    if response.status_code == HTTPStatus.INTERNAL_SERVER_ERROR:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_500 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_500 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_500 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_500, status_code=response.status_code
            )
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(f"Unexpected status code: {response.status_code}")
    else:
        return None


def _build_response(
    *, client: Client, response: httpx.Response
) -> Union[Response[Union[CreateDigitalTwinVersionResponse200, Error]], httpx.Response]:
    if client.parse_response_behavior == ParseResponseBehavior.RAW_RESPONSE:
        return response

    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    multipart_data: CreateDigitalTwinVersionMultipartData,
) -> Union[Response[Union[CreateDigitalTwinVersionResponse200, Error]], httpx.Response]:
    """Create digital twin version

     Creates digital twin version to the supplied digital twin

    Args:
        multipart_data (CreateDigitalTwinVersionMultipartData):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[CreateDigitalTwinVersionResponse200, Error]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
        multipart_data=multipart_data,
    )

    with httpx.Client(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = _client.request(**kwargs)

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    multipart_data: CreateDigitalTwinVersionMultipartData,
) -> Optional[Union[CreateDigitalTwinVersionResponse200, Error]]:
    """Create digital twin version

     Creates digital twin version to the supplied digital twin

    Args:
        multipart_data (CreateDigitalTwinVersionMultipartData):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[CreateDigitalTwinVersionResponse200, Error]]
    """

    return sync_detailed(
        client=client,
        multipart_data=multipart_data,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    multipart_data: CreateDigitalTwinVersionMultipartData,
) -> Union[Response[Union[CreateDigitalTwinVersionResponse200, Error]], httpx.Response]:
    """Create digital twin version

     Creates digital twin version to the supplied digital twin

    Args:
        multipart_data (CreateDigitalTwinVersionMultipartData):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[CreateDigitalTwinVersionResponse200, Error]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
        multipart_data=multipart_data,
    )

    async with httpx.AsyncClient(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = await _client.request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    multipart_data: CreateDigitalTwinVersionMultipartData,
) -> Optional[Union[CreateDigitalTwinVersionResponse200, Error]]:
    """Create digital twin version

     Creates digital twin version to the supplied digital twin

    Args:
        multipart_data (CreateDigitalTwinVersionMultipartData):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[CreateDigitalTwinVersionResponse200, Error]]
    """

    return (
        await asyncio_detailed(
            client=client,
            multipart_data=multipart_data,
        )
    ).parsed
