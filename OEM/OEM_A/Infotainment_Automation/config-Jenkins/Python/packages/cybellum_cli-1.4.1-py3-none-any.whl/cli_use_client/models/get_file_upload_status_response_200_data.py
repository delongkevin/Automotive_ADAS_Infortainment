from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.resumable_upload_file import ResumableUploadFile


T = TypeVar("T", bound="GetFileUploadStatusResponse200Data")


@attr.s(auto_attribs=True)
class GetFileUploadStatusResponse200Data:
    """
    Attributes:
        files (Union[Unset, List['ResumableUploadFile']]):
    """

    files: Union[Unset, List["ResumableUploadFile"]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        files: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.files, Unset):
            files = []
            for files_item_data in self.files:
                files_item = files_item_data.to_dict()

                files.append(files_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if files is not UNSET:
            field_dict["files"] = files

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.resumable_upload_file import ResumableUploadFile

        d = src_dict.copy()
        _files = d.pop("files", UNSET)
        if (_files) is UNSET:
            files = UNSET
        else:
            if _files:
                files = []
                for files_item_data in _files:
                    files_item = ResumableUploadFile.from_dict(files_item_data)

                    files.append(files_item)
            else:
                files = []

        get_file_upload_status_response_200_data = cls(
            files=files,
        )

        get_file_upload_status_response_200_data.additional_properties = d
        return get_file_upload_status_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
