from http import HTTPStatus
from typing import Any, Dict, List, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, AuthenticationStatus, Client, ParseResponseBehavior
from ...models.error import Error
from ...models.list_ai_models_response_200_item import ListAIModelsResponse200Item
from ...types import Response


def _get_kwargs(
    *,
    client: AuthenticatedClient,
) -> Dict[str, Any]:
    url = "{}/ai/models".format(client.get_service_url("ai"))

    headers: Dict[str, str] = client.get_headers()
    cookies: Dict[str, Any] = client.get_cookies()

    return {
        "method": "get",
        "url": url,
        "headers": headers,
        "cookies": cookies,
        "timeout": client.get_timeout(),
    }


def _parse_response(
    *, client: Client, response: httpx.Response
) -> Optional[Union[Error, List["ListAIModelsResponse200Item"]]]:
    if response.status_code == HTTPStatus.OK:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_200 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_200 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                _response_200 = response.json()
                response_200 = []
                for response_200_item_data in _response_200:
                    response_200_item = ListAIModelsResponse200Item.from_dict(response_200_item_data)

                    response_200.append(response_200_item)

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        return response_200

    if response.status_code == HTTPStatus.BAD_REQUEST:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_400 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_400 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_400 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_400, status_code=response.status_code
            )
        return response_400

    if response.status_code == HTTPStatus.INTERNAL_SERVER_ERROR:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_500 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_500 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_500 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_500, status_code=response.status_code
            )
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(f"Unexpected status code: {response.status_code}")
    else:
        return None


def _build_response(
    *, client: Client, response: httpx.Response
) -> Union[Response[Union[Error, List["ListAIModelsResponse200Item"]]], httpx.Response]:
    if client.parse_response_behavior == ParseResponseBehavior.RAW_RESPONSE:
        return response

    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Union[Response[Union[Error, List["ListAIModelsResponse200Item"]]], httpx.Response]:
    """List all available AI models

     Returns a list of all AI models that can be used for conversations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, List['ListAIModelsResponse200Item']]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
    )

    with httpx.Client(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = _client.request(**kwargs)

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> Optional[Union[Error, List["ListAIModelsResponse200Item"]]]:
    """List all available AI models

     Returns a list of all AI models that can be used for conversations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, List['ListAIModelsResponse200Item']]]
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Union[Response[Union[Error, List["ListAIModelsResponse200Item"]]], httpx.Response]:
    """List all available AI models

     Returns a list of all AI models that can be used for conversations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, List['ListAIModelsResponse200Item']]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
    )

    async with httpx.AsyncClient(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = await _client.request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> Optional[Union[Error, List["ListAIModelsResponse200Item"]]]:
    """List all available AI models

     Returns a list of all AI models that can be used for conversations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, List['ListAIModelsResponse200Item']]]
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
