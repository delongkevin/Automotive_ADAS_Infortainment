from typing import Any, Dict, List, Type, TypeVar

import attr

T = TypeVar("T", bound="GetGlobalPackagesDatabaseVersionResponse200DataDbVersion")


@attr.s(auto_attribs=True)
class GetGlobalPackagesDatabaseVersionResponse200DataDbVersion:
    """Database version object

    Attributes:
        bat_count_scheme (str):
        commit_id (str):
        mini_bat (bool):
        version (str): Database version
    """

    bat_count_scheme: str
    commit_id: str
    mini_bat: bool
    version: str
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        bat_count_scheme = self.bat_count_scheme
        commit_id = self.commit_id
        mini_bat = self.mini_bat
        version = self.version

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "bat_count_scheme": bat_count_scheme,
                "commit_id": commit_id,
                "mini_bat": mini_bat,
                "version": version,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        bat_count_scheme = d.pop("bat_count_scheme")

        commit_id = d.pop("commit_id")

        mini_bat = d.pop("mini_bat")

        version = d.pop("version")

        get_global_packages_database_version_response_200_data_db_version = cls(
            bat_count_scheme=bat_count_scheme,
            commit_id=commit_id,
            mini_bat=mini_bat,
            version=version,
        )

        get_global_packages_database_version_response_200_data_db_version.additional_properties = d
        return get_global_packages_database_version_response_200_data_db_version

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
