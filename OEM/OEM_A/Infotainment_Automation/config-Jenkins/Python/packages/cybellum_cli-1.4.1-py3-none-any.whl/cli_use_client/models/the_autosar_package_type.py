from enum import Enum
from typing import Union


class TheAutosarPackageType(str, Enum):
    FRAMEWORK = "framework"

    MODULE = "module"

    VALUE_2 = "3rd_party"

    VENDOR = "vendor"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "TheAutosarPackageType"]) -> "TheAutosarPackageType":
        if isinstance(value, TheAutosarPackageType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return TheAutosarPackageType(value)
