from enum import Enum
from typing import Union


class DigitalTwinVersionStatus(str, Enum):
    ACTIVE = "active"

    ARCHIVED = "archived"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "DigitalTwinVersionStatus"]) -> "DigitalTwinVersionStatus":
        if isinstance(value, DigitalTwinVersionStatus):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return DigitalTwinVersionStatus(value)
