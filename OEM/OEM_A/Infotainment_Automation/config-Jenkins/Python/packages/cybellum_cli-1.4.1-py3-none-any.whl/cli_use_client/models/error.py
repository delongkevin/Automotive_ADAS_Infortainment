from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.error_error import ErrorError


T = TypeVar("T", bound="Error")


@attr.s(auto_attribs=True)
class Error:
    """error

    Attributes:
        error (Union[Unset, ErrorError]):
        status_code (Union[Unset, float]): status_code
    """

    error: Union[Unset, "ErrorError"] = UNSET
    status_code: Union[Unset, float] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        error: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.error, Unset):
            error = self.error.to_dict()

        status_code = self.status_code

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if error is not UNSET:
            field_dict["error"] = error
        if status_code is not UNSET:
            field_dict["status_code"] = status_code

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.error_error import ErrorError

        d = src_dict.copy()
        _error = d.pop("error", UNSET)
        error: Union[Unset, ErrorError]
        if isinstance(_error, Unset):
            error = UNSET
        else:
            error = ErrorError.from_dict(_error)

        status_code = d.pop("status_code", UNSET)

        error = cls(
            error=error,
            status_code=status_code,
        )

        error.additional_properties = d
        return error

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
