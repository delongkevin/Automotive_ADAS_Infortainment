from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="GetAnalysisErrorsAutofixSummaryJsonBodyPagination")


@attr.s(auto_attribs=True)
class GetAnalysisErrorsAutofixSummaryJsonBodyPagination:
    """
    Attributes:
        limit (Union[Unset, int]): The maximum number of errors to return Default: 50.
        offset (Union[Unset, int]): The offset for the batch of errors
    """

    limit: Union[Unset, int] = 50
    offset: Union[Unset, int] = 0
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        limit = self.limit
        offset = self.offset

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if limit is not UNSET:
            field_dict["limit"] = limit
        if offset is not UNSET:
            field_dict["offset"] = offset

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        limit = d.pop("limit", UNSET)

        offset = d.pop("offset", UNSET)

        get_analysis_errors_autofix_summary_json_body_pagination = cls(
            limit=limit,
            offset=offset,
        )

        get_analysis_errors_autofix_summary_json_body_pagination.additional_properties = d
        return get_analysis_errors_autofix_summary_json_body_pagination

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
