from enum import Enum
from typing import Union


class SBOMPackageInfoOriginType(str, Enum):
    CUSTOM = "custom"

    STANDARD = "standard"

    UNMAPPED = "unmapped"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "SBOMPackageInfoOriginType"]) -> "SBOMPackageInfoOriginType":
        if isinstance(value, SBOMPackageInfoOriginType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return SBOMPackageInfoOriginType(value)
