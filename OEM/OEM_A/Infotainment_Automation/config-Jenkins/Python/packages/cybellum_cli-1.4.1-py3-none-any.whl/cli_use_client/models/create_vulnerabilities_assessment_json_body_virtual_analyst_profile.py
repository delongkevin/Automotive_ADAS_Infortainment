from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateVulnerabilitiesAssessmentJsonBodyVirtualAnalystProfile")


@attr.s(auto_attribs=True)
class CreateVulnerabilitiesAssessmentJsonBodyVirtualAnalystProfile:
    """Assessment virtual analyst profile

    Attributes:
        auto_start (Union[Unset, bool]): Indicator if should auto-start the virtual analyst execution based on the
            chosen profile right after the scan
        name (Union[Unset, str]): The name of the global profile (needs to be already configured)
    """

    auto_start: Union[Unset, bool] = UNSET
    name: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        auto_start = self.auto_start
        name = self.name

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if auto_start is not UNSET:
            field_dict["auto_start"] = auto_start
        if name is not UNSET:
            field_dict["name"] = name

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        auto_start = d.pop("auto_start", UNSET)

        name = d.pop("name", UNSET)

        create_vulnerabilities_assessment_json_body_virtual_analyst_profile = cls(
            auto_start=auto_start,
            name=name,
        )

        create_vulnerabilities_assessment_json_body_virtual_analyst_profile.additional_properties = d
        return create_vulnerabilities_assessment_json_body_virtual_analyst_profile

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
