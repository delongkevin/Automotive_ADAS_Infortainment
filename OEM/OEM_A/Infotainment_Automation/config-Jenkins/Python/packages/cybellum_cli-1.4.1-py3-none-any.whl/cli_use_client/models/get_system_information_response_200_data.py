from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar

import attr

from ..models.get_system_information_response_200_data_deployment import GetSystemInformationResponse200DataDeployment

if TYPE_CHECKING:
    from ..models.get_system_information_response_200_data_disk_usage import (
        GetSystemInformationResponse200DataDiskUsage,
    )
    from ..models.get_system_information_response_200_data_system_version import (
        GetSystemInformationResponse200DataSystemVersion,
    )


T = TypeVar("T", bound="GetSystemInformationResponse200Data")


@attr.s(auto_attribs=True)
class GetSystemInformationResponse200Data:
    """
    Attributes:
        deployment (GetSystemInformationResponse200DataDeployment): Deployment type
        disk_usage (GetSystemInformationResponse200DataDiskUsage): Disk usage attributes
        system_version (GetSystemInformationResponse200DataSystemVersion): System version
    """

    deployment: GetSystemInformationResponse200DataDeployment
    disk_usage: "GetSystemInformationResponse200DataDiskUsage"
    system_version: "GetSystemInformationResponse200DataSystemVersion"
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        deployment = GetSystemInformationResponse200DataDeployment.from_val(self.deployment).value

        disk_usage = self.disk_usage.to_dict()

        system_version = self.system_version.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "deployment": deployment,
                "disk_usage": disk_usage,
                "system_version": system_version,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.get_system_information_response_200_data_disk_usage import (
            GetSystemInformationResponse200DataDiskUsage,
        )
        from ..models.get_system_information_response_200_data_system_version import (
            GetSystemInformationResponse200DataSystemVersion,
        )

        d = src_dict.copy()
        deployment = GetSystemInformationResponse200DataDeployment.from_val(d.pop("deployment"))

        disk_usage = GetSystemInformationResponse200DataDiskUsage.from_dict(d.pop("disk_usage"))

        system_version = GetSystemInformationResponse200DataSystemVersion.from_dict(d.pop("system_version"))

        get_system_information_response_200_data = cls(
            deployment=deployment,
            disk_usage=disk_usage,
            system_version=system_version,
        )

        get_system_information_response_200_data.additional_properties = d
        return get_system_information_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
