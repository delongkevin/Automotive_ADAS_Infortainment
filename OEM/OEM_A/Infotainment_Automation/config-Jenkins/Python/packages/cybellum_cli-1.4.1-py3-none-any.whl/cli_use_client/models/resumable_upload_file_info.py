from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.resumable_upload_file_info_state import ResumableUploadFileInfoState
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.resumable_upload_file_info_data import ResumableUploadFileInfoData
    from ..models.resumable_upload_file_info_error import ResumableUploadFileInfoError
    from ..models.resumable_upload_file_info_progress import ResumableUploadFileInfoProgress


T = TypeVar("T", bound="ResumableUploadFileInfo")


@attr.s(auto_attribs=True)
class ResumableUploadFileInfo:
    """Resumable upload file info

    Attributes:
        data (Union[Unset, ResumableUploadFileInfoData]): Resumable upload file info data
        error (Union[Unset, ResumableUploadFileInfoError]): Resumable upload file info error
        progress (Union[Unset, ResumableUploadFileInfoProgress]): Resumable upload file info progress
        state (Union[Unset, ResumableUploadFileInfoState]): Resumable upload file info state
        sub_state (Union[Unset, str]): Resumable upload file info sub state
    """

    data: Union[Unset, "ResumableUploadFileInfoData"] = UNSET
    error: Union[Unset, "ResumableUploadFileInfoError"] = UNSET
    progress: Union[Unset, "ResumableUploadFileInfoProgress"] = UNSET
    state: Union[Unset, ResumableUploadFileInfoState] = UNSET
    sub_state: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        data: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.data, Unset):
            data = self.data.to_dict()

        error: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.error, Unset):
            error = self.error.to_dict()

        progress: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.progress, Unset):
            progress = self.progress.to_dict()

        state: Union[Unset, str] = UNSET
        if not isinstance(self.state, Unset):
            state = ResumableUploadFileInfoState.from_val(self.state).value

        sub_state = self.sub_state

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if data is not UNSET:
            field_dict["data"] = data
        if error is not UNSET:
            field_dict["error"] = error
        if progress is not UNSET:
            field_dict["progress"] = progress
        if state is not UNSET:
            field_dict["state"] = state
        if sub_state is not UNSET:
            field_dict["sub_state"] = sub_state

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.resumable_upload_file_info_data import ResumableUploadFileInfoData
        from ..models.resumable_upload_file_info_error import ResumableUploadFileInfoError
        from ..models.resumable_upload_file_info_progress import ResumableUploadFileInfoProgress

        d = src_dict.copy()
        _data = d.pop("data", UNSET)
        data: Union[Unset, ResumableUploadFileInfoData]
        if isinstance(_data, Unset):
            data = UNSET
        else:
            data = ResumableUploadFileInfoData.from_dict(_data)

        _error = d.pop("error", UNSET)
        error: Union[Unset, ResumableUploadFileInfoError]
        if isinstance(_error, Unset):
            error = UNSET
        else:
            error = ResumableUploadFileInfoError.from_dict(_error)

        _progress = d.pop("progress", UNSET)
        progress: Union[Unset, ResumableUploadFileInfoProgress]
        if isinstance(_progress, Unset):
            progress = UNSET
        else:
            progress = ResumableUploadFileInfoProgress.from_dict(_progress)

        _state = d.pop("state", UNSET)
        state: Union[Unset, ResumableUploadFileInfoState]
        if isinstance(_state, Unset):
            state = UNSET
        else:
            state = ResumableUploadFileInfoState.from_val(_state)

        sub_state = d.pop("sub_state", UNSET)

        resumable_upload_file_info = cls(
            data=data,
            error=error,
            progress=progress,
            state=state,
            sub_state=sub_state,
        )

        resumable_upload_file_info.additional_properties = d
        return resumable_upload_file_info

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
