from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.digital_twin_version_scan_partial_results_info_partial_info_types_credentials_state import (
    DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentialsState,
)
from ..types import UNSET, Unset

T = TypeVar("T", bound="DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentials")


@attr.s(auto_attribs=True)
class DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentials:
    """credentails information type

    Attributes:
        number_of_errors (Union[Unset, float]): number of errors
        state (Union[Unset, DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentialsState]):
    """

    number_of_errors: Union[Unset, float] = UNSET
    state: Union[Unset, DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentialsState] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        number_of_errors = self.number_of_errors
        state: Union[Unset, str] = UNSET
        if not isinstance(self.state, Unset):
            state = DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentialsState.from_val(self.state).value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if number_of_errors is not UNSET:
            field_dict["number_of_errors"] = number_of_errors
        if state is not UNSET:
            field_dict["state"] = state

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        number_of_errors = d.pop("number_of_errors", UNSET)

        _state = d.pop("state", UNSET)
        state: Union[Unset, DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentialsState]
        if isinstance(_state, Unset):
            state = UNSET
        else:
            state = DigitalTwinVersionScanPartialResultsInfoPartialInfoTypesCredentialsState.from_val(_state)

        digital_twin_version_scan_partial_results_info_partial_info_types_credentials = cls(
            number_of_errors=number_of_errors,
            state=state,
        )

        digital_twin_version_scan_partial_results_info_partial_info_types_credentials.additional_properties = d
        return digital_twin_version_scan_partial_results_info_partial_info_types_credentials

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
