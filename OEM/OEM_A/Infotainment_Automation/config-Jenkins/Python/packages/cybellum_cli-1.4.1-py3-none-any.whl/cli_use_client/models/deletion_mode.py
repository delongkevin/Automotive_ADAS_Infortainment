from enum import Enum
from typing import Union


class DeletionMode(str, Enum):
    EXTRACTED_FILES = "extracted_files"

    ALL_FILES = "all_files"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "DeletionMode"]) -> "DeletionMode":
        if isinstance(value, DeletionMode):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return DeletionMode(value)
