from http import HTTPStatus
from io import BytesIO
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, AuthenticationStatus, Client, ParseResponseBehavior, flatten_params
from ...models.error import Error
from ...models.export_conversation_format import ExportConversationFormat
from ...types import UNSET, File, Response, Unset


def _get_kwargs(
    *,
    client: AuthenticatedClient,
    conversation_id: str,
    format_: Union[Unset, None, ExportConversationFormat] = ExportConversationFormat.JSON,
) -> Dict[str, Any]:
    url = "{}/ai/conversations/export".format(client.get_service_url("ai"))

    headers: Dict[str, str] = client.get_headers()
    cookies: Dict[str, Any] = client.get_cookies()

    params: Dict[str, Any] = {}
    params["conversation_id"] = conversation_id

    json_format_: Union[Unset, None, str] = UNSET
    if not isinstance(format_, Unset):
        json_format_ = ExportConversationFormat.from_val(format_).value if format_ else None

    params["format"] = json_format_

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}
    params = flatten_params(params)

    return {
        "method": "get",
        "url": url,
        "headers": headers,
        "cookies": cookies,
        "timeout": client.get_timeout(),
        "params": params,
    }


def _parse_response(*, client: Client, response: httpx.Response) -> Optional[Union[Error, File]]:
    if response.status_code == HTTPStatus.OK:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_200 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_200 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                _response_200 = response.content
                response_200: File

                if isinstance(_response_200, File):
                    response_200 = _response_200
                else:
                    response_200 = File(payload=BytesIO(_response_200))

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        return response_200

    if response.status_code == HTTPStatus.NOT_FOUND:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_404 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_404 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_404 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_404, status_code=response.status_code
            )
        return response_404

    if response.status_code == HTTPStatus.INTERNAL_SERVER_ERROR:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_500 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_500 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_500 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_500, status_code=response.status_code
            )
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(f"Unexpected status code: {response.status_code}")
    else:
        return None


def _build_response(*, client: Client, response: httpx.Response) -> Union[Response[Union[Error, File]], httpx.Response]:
    if client.parse_response_behavior == ParseResponseBehavior.RAW_RESPONSE:
        return response

    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    conversation_id: str,
    format_: Union[Unset, None, ExportConversationFormat] = ExportConversationFormat.JSON,
) -> Union[Response[Union[Error, File]], httpx.Response]:
    """Export a specific conversation's log

     Allows users to retrieve a complete log of a conversation in a specified format.

    Args:
        conversation_id (str): ID of the conversation to be exported.
        format_ (Union[Unset, None, ExportConversationFormat]): Desired format for the exported
            conversation (e.g., "json", "csv", "txt"). Default: ExportConversationFormat.JSON.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, File]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
        conversation_id=conversation_id,
        format_=format_,
    )

    with httpx.Client(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = _client.request(**kwargs)

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    conversation_id: str,
    format_: Union[Unset, None, ExportConversationFormat] = ExportConversationFormat.JSON,
) -> Optional[Union[Error, File]]:
    """Export a specific conversation's log

     Allows users to retrieve a complete log of a conversation in a specified format.

    Args:
        conversation_id (str): ID of the conversation to be exported.
        format_ (Union[Unset, None, ExportConversationFormat]): Desired format for the exported
            conversation (e.g., "json", "csv", "txt"). Default: ExportConversationFormat.JSON.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, File]]
    """

    return sync_detailed(
        client=client,
        conversation_id=conversation_id,
        format_=format_,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    conversation_id: str,
    format_: Union[Unset, None, ExportConversationFormat] = ExportConversationFormat.JSON,
) -> Union[Response[Union[Error, File]], httpx.Response]:
    """Export a specific conversation's log

     Allows users to retrieve a complete log of a conversation in a specified format.

    Args:
        conversation_id (str): ID of the conversation to be exported.
        format_ (Union[Unset, None, ExportConversationFormat]): Desired format for the exported
            conversation (e.g., "json", "csv", "txt"). Default: ExportConversationFormat.JSON.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, File]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
        conversation_id=conversation_id,
        format_=format_,
    )

    async with httpx.AsyncClient(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = await _client.request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    conversation_id: str,
    format_: Union[Unset, None, ExportConversationFormat] = ExportConversationFormat.JSON,
) -> Optional[Union[Error, File]]:
    """Export a specific conversation's log

     Allows users to retrieve a complete log of a conversation in a specified format.

    Args:
        conversation_id (str): ID of the conversation to be exported.
        format_ (Union[Unset, None, ExportConversationFormat]): Desired format for the exported
            conversation (e.g., "json", "csv", "txt"). Default: ExportConversationFormat.JSON.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, File]]
    """

    return (
        await asyncio_detailed(
            client=client,
            conversation_id=conversation_id,
            format_=format_,
        )
    ).parsed
