from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="LinkedPackage")


@attr.s(auto_attribs=True)
class LinkedPackage:
    """Linked package

    Attributes:
        package_id (Union[Unset, str]): Package id
        package_name (Union[Unset, str]): Package name
        version_id (Union[Unset, str]): Version id
        version_name (Union[Unset, str]): Version name
    """

    package_id: Union[Unset, str] = UNSET
    package_name: Union[Unset, str] = UNSET
    version_id: Union[Unset, str] = UNSET
    version_name: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        package_id = self.package_id
        package_name = self.package_name
        version_id = self.version_id
        version_name = self.version_name

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if package_id is not UNSET:
            field_dict["package_id"] = package_id
        if package_name is not UNSET:
            field_dict["package_name"] = package_name
        if version_id is not UNSET:
            field_dict["version_id"] = version_id
        if version_name is not UNSET:
            field_dict["version_name"] = version_name

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        package_id = d.pop("package_id", UNSET)

        package_name = d.pop("package_name", UNSET)

        version_id = d.pop("version_id", UNSET)

        version_name = d.pop("version_name", UNSET)

        linked_package = cls(
            package_id=package_id,
            package_name=package_name,
            version_id=version_id,
            version_name=version_name,
        )

        linked_package.additional_properties = d
        return linked_package

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
