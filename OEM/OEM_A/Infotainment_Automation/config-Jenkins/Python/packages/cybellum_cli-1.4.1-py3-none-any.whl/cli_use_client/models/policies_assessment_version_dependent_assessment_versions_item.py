from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..models.assessment_type import AssessmentType
from ..types import UNSET, Unset

T = TypeVar("T", bound="PoliciesAssessmentVersionDependentAssessmentVersionsItem")


@attr.s(auto_attribs=True)
class PoliciesAssessmentVersionDependentAssessmentVersionsItem:
    """
    Attributes:
        assessment_type (Union[Unset, AssessmentType]): Assessment type
        assessment_version_id (Union[Unset, str]): ID
    """

    assessment_type: Union[Unset, AssessmentType] = UNSET
    assessment_version_id: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        assessment_type: Union[Unset, str] = UNSET
        if not isinstance(self.assessment_type, Unset):
            assessment_type = AssessmentType.from_val(self.assessment_type).value

        assessment_version_id = self.assessment_version_id

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if assessment_type is not UNSET:
            field_dict["assessment_type"] = assessment_type
        if assessment_version_id is not UNSET:
            field_dict["assessment_version_id"] = assessment_version_id

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _assessment_type = d.pop("assessment_type", UNSET)
        assessment_type: Union[Unset, AssessmentType]
        if isinstance(_assessment_type, Unset):
            assessment_type = UNSET
        else:
            assessment_type = AssessmentType.from_val(_assessment_type)

        assessment_version_id = d.pop("assessment_version_id", UNSET)

        policies_assessment_version_dependent_assessment_versions_item = cls(
            assessment_type=assessment_type,
            assessment_version_id=assessment_version_id,
        )

        policies_assessment_version_dependent_assessment_versions_item.additional_properties = d
        return policies_assessment_version_dependent_assessment_versions_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
