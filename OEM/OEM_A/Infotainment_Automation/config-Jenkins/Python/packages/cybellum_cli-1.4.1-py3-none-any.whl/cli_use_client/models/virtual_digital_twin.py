from typing import Any, Dict, List, Type, TypeVar

import attr

T = TypeVar("T", bound="VirtualDigitalTwin")


@attr.s(auto_attribs=True)
class VirtualDigitalTwin:
    """Virtual digital twin

    Attributes:
        id (str): Virtual digital twin id
        name (str): Virtual digital twin name
        parent_id (str): ID
        risk (float): Risk
        type (str): Virtual digital twin type
    """

    id: str
    name: str
    parent_id: str
    risk: float
    type: str
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        id = self.id
        name = self.name
        parent_id = self.parent_id
        risk = self.risk
        type = self.type

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "parent_id": parent_id,
                "risk": risk,
                "type": type,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        id = d.pop("id")

        name = d.pop("name")

        parent_id = d.pop("parent_id")

        risk = d.pop("risk")

        type = d.pop("type")

        virtual_digital_twin = cls(
            id=id,
            name=name,
            parent_id=parent_id,
            risk=risk,
            type=type,
        )

        virtual_digital_twin.additional_properties = d
        return virtual_digital_twin

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
