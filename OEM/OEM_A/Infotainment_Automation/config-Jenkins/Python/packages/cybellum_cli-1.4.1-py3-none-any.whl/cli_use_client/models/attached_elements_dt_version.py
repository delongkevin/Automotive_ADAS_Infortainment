import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..models.deletion_mode import DeletionMode
from ..models.digital_twin_version_status import DigitalTwinVersionStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin_base import DigitalTwinBase
    from ..models.digital_twin_version_base_original_files_item import DigitalTwinVersionBaseOriginalFilesItem
    from ..models.digital_twin_version_base_sbom_component_data import DigitalTwinVersionBaseSbomComponentData
    from ..models.digital_twin_version_scan import DigitalTwinVersionScan
    from ..models.hardware import Hardware
    from ..models.operating_system import OperatingSystem
    from ..models.private_configurations import PrivateConfigurations
    from ..models.sbom_metadata import SbomMetadata


T = TypeVar("T", bound="AttachedElementsDtVersion")


@attr.s(auto_attribs=True)
class AttachedElementsDtVersion:
    """
    Attributes:
        created_by (str): the id of the user which created the digital twin version
        created_on (datetime.datetime): the digital twin creation time
        date (datetime.datetime): the digital twin version date
        id (str): ID
        last_modified_on (datetime.datetime):
        name (str): the digital twin version name
        component_format (Union[Unset, str]):
        external_id (Union[Unset, str]): the external id of the digtial twin
        file_deletion_mode (Union[Unset, None, DeletionMode]): the deletion mode of the digital twin. "all_files" -
            means that all the digital twin uploaded files are removed. "extracted_files" means that just the extracted
            files are removed but the original file is still intact.
        hardware (Union[Unset, Hardware]): digital twin hardware
        micro_controller (Union[Unset, bool]):
        monitor (Union[Unset, bool]): Indicator for PSIRT monitor
        monitor_start_date (Union[Unset, None, datetime.datetime]): Monitor Start Date Example:
            2020-01-01T00:00:00.000Z.
        operating_systems (Union[Unset, List['OperatingSystem']]):
        original_files (Union[Unset, List['DigitalTwinVersionBaseOriginalFilesItem']]): the original files that were
            uploaded to the digital twin version
        parent_id (Union[Unset, str]): ID
        private_configurations (Union[Unset, PrivateConfigurations]): Private configurations
        production_phase (Union[Unset, str]): Component Production Phase
        sbom_approval_status (Union[Unset, str]): Indicator of the SBOM approval status
        sbom_component_data (Union[Unset, DigitalTwinVersionBaseSbomComponentData]):
        sbom_metadata (Union[Unset, SbomMetadata]): sbom metadata from intermediate sbom
        sbom_phase (Union[Unset, str]):
        scan (Union[Unset, DigitalTwinVersionScan]): Digital twin version scan
        scans (Union[Unset, List['DigitalTwinVersionScan']]): List of scans
        status (Union[Unset, DigitalTwinVersionStatus]): Digital twin version status
        dt (Union[Unset, DigitalTwinBase]): Digital twin base
        feasibility (Union[Unset, float]): Feasibility of the attached product in terms of risk
        weight (Union[Unset, float]): The weight of the attached elements in terms of risk
    """

    created_by: str
    created_on: datetime.datetime
    date: datetime.datetime
    id: str
    last_modified_on: datetime.datetime
    name: str
    component_format: Union[Unset, str] = UNSET
    external_id: Union[Unset, str] = UNSET
    file_deletion_mode: Union[Unset, None, DeletionMode] = UNSET
    hardware: Union[Unset, "Hardware"] = UNSET
    micro_controller: Union[Unset, bool] = UNSET
    monitor: Union[Unset, bool] = UNSET
    monitor_start_date: Union[Unset, None, datetime.datetime] = UNSET
    operating_systems: Union[Unset, List["OperatingSystem"]] = UNSET
    original_files: Union[Unset, List["DigitalTwinVersionBaseOriginalFilesItem"]] = UNSET
    parent_id: Union[Unset, str] = UNSET
    private_configurations: Union[Unset, "PrivateConfigurations"] = UNSET
    production_phase: Union[Unset, str] = UNSET
    sbom_approval_status: Union[Unset, str] = UNSET
    sbom_component_data: Union[Unset, "DigitalTwinVersionBaseSbomComponentData"] = UNSET
    sbom_metadata: Union[Unset, "SbomMetadata"] = UNSET
    sbom_phase: Union[Unset, str] = UNSET
    scan: Union[Unset, "DigitalTwinVersionScan"] = UNSET
    scans: Union[Unset, List["DigitalTwinVersionScan"]] = UNSET
    status: Union[Unset, DigitalTwinVersionStatus] = UNSET
    dt: Union[Unset, "DigitalTwinBase"] = UNSET
    feasibility: Union[Unset, float] = UNSET
    weight: Union[Unset, float] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        created_by = self.created_by
        created_on = self.created_on.isoformat()

        date = self.date.isoformat()

        id = self.id
        last_modified_on = self.last_modified_on.isoformat()

        name = self.name
        component_format = self.component_format
        external_id = self.external_id
        file_deletion_mode: Union[Unset, None, str] = UNSET
        if not isinstance(self.file_deletion_mode, Unset):
            file_deletion_mode = (
                DeletionMode.from_val(self.file_deletion_mode).value if self.file_deletion_mode else None
            )

        hardware: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.hardware, Unset):
            hardware = self.hardware.to_dict()

        micro_controller = self.micro_controller
        monitor = self.monitor
        monitor_start_date: Union[Unset, None, str] = UNSET
        if not isinstance(self.monitor_start_date, Unset):
            monitor_start_date = self.monitor_start_date.isoformat() if self.monitor_start_date else None

        operating_systems: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.operating_systems, Unset):
            operating_systems = []
            for operating_systems_item_data in self.operating_systems:
                operating_systems_item = operating_systems_item_data.to_dict()

                operating_systems.append(operating_systems_item)

        original_files: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.original_files, Unset):
            original_files = []
            for original_files_item_data in self.original_files:
                original_files_item = original_files_item_data.to_dict()

                original_files.append(original_files_item)

        parent_id = self.parent_id
        private_configurations: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.private_configurations, Unset):
            private_configurations = self.private_configurations.to_dict()

        production_phase = self.production_phase
        sbom_approval_status = self.sbom_approval_status
        sbom_component_data: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.sbom_component_data, Unset):
            sbom_component_data = self.sbom_component_data.to_dict()

        sbom_metadata: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.sbom_metadata, Unset):
            sbom_metadata = self.sbom_metadata.to_dict()

        sbom_phase = self.sbom_phase
        scan: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.scan, Unset):
            scan = self.scan.to_dict()

        scans: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.scans, Unset):
            scans = []
            for scans_item_data in self.scans:
                scans_item = scans_item_data.to_dict()

                scans.append(scans_item)

        status: Union[Unset, str] = UNSET
        if not isinstance(self.status, Unset):
            status = DigitalTwinVersionStatus.from_val(self.status).value

        dt: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.dt, Unset):
            dt = self.dt.to_dict()

        feasibility = self.feasibility
        weight = self.weight

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "created_by": created_by,
                "created_on": created_on,
                "date": date,
                "id": id,
                "last_modified_on": last_modified_on,
                "name": name,
            }
        )
        if component_format is not UNSET:
            field_dict["component_format"] = component_format
        if external_id is not UNSET:
            field_dict["external_id"] = external_id
        if file_deletion_mode is not UNSET:
            field_dict["file_deletion_mode"] = file_deletion_mode
        if hardware is not UNSET:
            field_dict["hardware"] = hardware
        if micro_controller is not UNSET:
            field_dict["micro_controller"] = micro_controller
        if monitor is not UNSET:
            field_dict["monitor"] = monitor
        if monitor_start_date is not UNSET:
            field_dict["monitor_start_date"] = monitor_start_date
        if operating_systems is not UNSET:
            field_dict["operating_systems"] = operating_systems
        if original_files is not UNSET:
            field_dict["original_files"] = original_files
        if parent_id is not UNSET:
            field_dict["parent_id"] = parent_id
        if private_configurations is not UNSET:
            field_dict["private_configurations"] = private_configurations
        if production_phase is not UNSET:
            field_dict["production_phase"] = production_phase
        if sbom_approval_status is not UNSET:
            field_dict["sbom_approval_status"] = sbom_approval_status
        if sbom_component_data is not UNSET:
            field_dict["sbom_component_data"] = sbom_component_data
        if sbom_metadata is not UNSET:
            field_dict["sbom_metadata"] = sbom_metadata
        if sbom_phase is not UNSET:
            field_dict["sbom_phase"] = sbom_phase
        if scan is not UNSET:
            field_dict["scan"] = scan
        if scans is not UNSET:
            field_dict["scans"] = scans
        if status is not UNSET:
            field_dict["status"] = status
        if dt is not UNSET:
            field_dict["dt"] = dt
        if feasibility is not UNSET:
            field_dict["feasibility"] = feasibility
        if weight is not UNSET:
            field_dict["weight"] = weight

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin_base import DigitalTwinBase
        from ..models.digital_twin_version_base_original_files_item import DigitalTwinVersionBaseOriginalFilesItem
        from ..models.digital_twin_version_base_sbom_component_data import DigitalTwinVersionBaseSbomComponentData
        from ..models.digital_twin_version_scan import DigitalTwinVersionScan
        from ..models.hardware import Hardware
        from ..models.operating_system import OperatingSystem
        from ..models.private_configurations import PrivateConfigurations
        from ..models.sbom_metadata import SbomMetadata

        d = src_dict.copy()
        created_by = d.pop("created_by")

        created_on = isoparse(d.pop("created_on"))

        date = isoparse(d.pop("date"))

        id = d.pop("id")

        last_modified_on = isoparse(d.pop("last_modified_on"))

        name = d.pop("name")

        component_format = d.pop("component_format", UNSET)

        external_id = d.pop("external_id", UNSET)

        _file_deletion_mode = d.pop("file_deletion_mode", UNSET)
        file_deletion_mode: Union[Unset, None, DeletionMode]
        if _file_deletion_mode is None:
            file_deletion_mode = None
        elif isinstance(_file_deletion_mode, Unset):
            file_deletion_mode = UNSET
        else:
            file_deletion_mode = DeletionMode.from_val(_file_deletion_mode)

        _hardware = d.pop("hardware", UNSET)
        hardware: Union[Unset, Hardware]
        if isinstance(_hardware, Unset):
            hardware = UNSET
        else:
            hardware = Hardware.from_dict(_hardware)

        micro_controller = d.pop("micro_controller", UNSET)

        monitor = d.pop("monitor", UNSET)

        _monitor_start_date = d.pop("monitor_start_date", UNSET)
        monitor_start_date: Union[Unset, None, datetime.datetime]
        if _monitor_start_date is None:
            monitor_start_date = None
        elif isinstance(_monitor_start_date, Unset):
            monitor_start_date = UNSET
        else:
            monitor_start_date = isoparse(_monitor_start_date)

        _operating_systems = d.pop("operating_systems", UNSET)
        if (_operating_systems) is UNSET:
            operating_systems = UNSET
        else:
            if _operating_systems:
                operating_systems = []
                for operating_systems_item_data in _operating_systems:
                    operating_systems_item = OperatingSystem.from_dict(operating_systems_item_data)

                    operating_systems.append(operating_systems_item)
            else:
                operating_systems = []

        _original_files = d.pop("original_files", UNSET)
        if (_original_files) is UNSET:
            original_files = UNSET
        else:
            if _original_files:
                original_files = []
                for original_files_item_data in _original_files:
                    original_files_item = DigitalTwinVersionBaseOriginalFilesItem.from_dict(original_files_item_data)

                    original_files.append(original_files_item)
            else:
                original_files = []

        parent_id = d.pop("parent_id", UNSET)

        _private_configurations = d.pop("private_configurations", UNSET)
        private_configurations: Union[Unset, PrivateConfigurations]
        if isinstance(_private_configurations, Unset):
            private_configurations = UNSET
        else:
            private_configurations = PrivateConfigurations.from_dict(_private_configurations)

        production_phase = d.pop("production_phase", UNSET)

        sbom_approval_status = d.pop("sbom_approval_status", UNSET)

        _sbom_component_data = d.pop("sbom_component_data", UNSET)
        sbom_component_data: Union[Unset, DigitalTwinVersionBaseSbomComponentData]
        if isinstance(_sbom_component_data, Unset):
            sbom_component_data = UNSET
        else:
            sbom_component_data = DigitalTwinVersionBaseSbomComponentData.from_dict(_sbom_component_data)

        _sbom_metadata = d.pop("sbom_metadata", UNSET)
        sbom_metadata: Union[Unset, SbomMetadata]
        if isinstance(_sbom_metadata, Unset):
            sbom_metadata = UNSET
        else:
            sbom_metadata = SbomMetadata.from_dict(_sbom_metadata)

        sbom_phase = d.pop("sbom_phase", UNSET)

        _scan = d.pop("scan", UNSET)
        scan: Union[Unset, DigitalTwinVersionScan]
        if isinstance(_scan, Unset):
            scan = UNSET
        else:
            scan = DigitalTwinVersionScan.from_dict(_scan)

        _scans = d.pop("scans", UNSET)
        if (_scans) is UNSET:
            scans = UNSET
        else:
            if _scans:
                scans = []
                for scans_item_data in _scans:
                    scans_item = DigitalTwinVersionScan.from_dict(scans_item_data)

                    scans.append(scans_item)
            else:
                scans = []

        _status = d.pop("status", UNSET)
        status: Union[Unset, DigitalTwinVersionStatus]
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = DigitalTwinVersionStatus.from_val(_status)

        _dt = d.pop("dt", UNSET)
        dt: Union[Unset, DigitalTwinBase]
        if isinstance(_dt, Unset):
            dt = UNSET
        else:
            dt = DigitalTwinBase.from_dict(_dt)

        feasibility = d.pop("feasibility", UNSET)

        weight = d.pop("weight", UNSET)

        attached_elements_dt_version = cls(
            created_by=created_by,
            created_on=created_on,
            date=date,
            id=id,
            last_modified_on=last_modified_on,
            name=name,
            component_format=component_format,
            external_id=external_id,
            file_deletion_mode=file_deletion_mode,
            hardware=hardware,
            micro_controller=micro_controller,
            monitor=monitor,
            monitor_start_date=monitor_start_date,
            operating_systems=operating_systems,
            original_files=original_files,
            parent_id=parent_id,
            private_configurations=private_configurations,
            production_phase=production_phase,
            sbom_approval_status=sbom_approval_status,
            sbom_component_data=sbom_component_data,
            sbom_metadata=sbom_metadata,
            sbom_phase=sbom_phase,
            scan=scan,
            scans=scans,
            status=status,
            dt=dt,
            feasibility=feasibility,
            weight=weight,
        )

        attached_elements_dt_version.additional_properties = d
        return attached_elements_dt_version

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
