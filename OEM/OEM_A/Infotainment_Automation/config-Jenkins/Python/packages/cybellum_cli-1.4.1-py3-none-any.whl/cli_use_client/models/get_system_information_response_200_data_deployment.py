from enum import Enum
from typing import Union


class GetSystemInformationResponse200DataDeployment(str, Enum):
    MULTI_NODE = "multi_node"

    SINGLE_NODE = "single_node"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(
        cls, value: Union[str, "GetSystemInformationResponse200DataDeployment"]
    ) -> "GetSystemInformationResponse200DataDeployment":
        if isinstance(value, GetSystemInformationResponse200DataDeployment):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return GetSystemInformationResponse200DataDeployment(value)
