from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.get_analysis_errors_json_body_pagination import GetAnalysisErrorsJsonBodyPagination
    from ..models.input_sort_item import InputSortItem


T = TypeVar("T", bound="GetAnalysisErrorsJsonBody")


@attr.s(auto_attribs=True)
class GetAnalysisErrorsJsonBody:
    """
    Attributes:
        file_id (str): ID
        pagination (Union[Unset, GetAnalysisErrorsJsonBodyPagination]):
        sort (Union[Unset, List['InputSortItem']]):
    """

    file_id: str
    pagination: Union[Unset, "GetAnalysisErrorsJsonBodyPagination"] = UNSET
    sort: Union[Unset, List["InputSortItem"]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        file_id = self.file_id
        pagination: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.pagination, Unset):
            pagination = self.pagination.to_dict()

        sort: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.sort, Unset):
            sort = []
            for componentsschemasinput_sort_item_data in self.sort:
                componentsschemasinput_sort_item = componentsschemasinput_sort_item_data.to_dict()

                sort.append(componentsschemasinput_sort_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "file_id": file_id,
            }
        )
        if pagination is not UNSET:
            field_dict["pagination"] = pagination
        if sort is not UNSET:
            field_dict["sort"] = sort

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.get_analysis_errors_json_body_pagination import GetAnalysisErrorsJsonBodyPagination
        from ..models.input_sort_item import InputSortItem

        d = src_dict.copy()
        file_id = d.pop("file_id")

        _pagination = d.pop("pagination", UNSET)
        pagination: Union[Unset, GetAnalysisErrorsJsonBodyPagination]
        if isinstance(_pagination, Unset):
            pagination = UNSET
        else:
            pagination = GetAnalysisErrorsJsonBodyPagination.from_dict(_pagination)

        _sort = d.pop("sort", UNSET)
        if (_sort) is UNSET:
            sort = UNSET
        else:
            if _sort:
                sort = []
                for componentsschemasinput_sort_item_data in _sort:
                    componentsschemasinput_sort_item = InputSortItem.from_dict(componentsschemasinput_sort_item_data)

                    sort.append(componentsschemasinput_sort_item)
            else:
                sort = []

        get_analysis_errors_json_body = cls(
            file_id=file_id,
            pagination=pagination,
            sort=sort,
        )

        get_analysis_errors_json_body.additional_properties = d
        return get_analysis_errors_json_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
