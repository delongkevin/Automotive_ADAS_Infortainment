from enum import Enum
from typing import Union


class ProductConnectionType(str, Enum):
    INTERFACE = "interface"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "ProductConnectionType"]) -> "ProductConnectionType":
        if isinstance(value, ProductConnectionType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return ProductConnectionType(value)
