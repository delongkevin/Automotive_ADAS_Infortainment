import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_vulnerabilities_assessment_json_body_cna_priority_item import (
        CreateVulnerabilitiesAssessmentJsonBodyCnaPriorityItem,
    )
    from ..models.create_vulnerabilities_assessment_json_body_virtual_analyst_profile import (
        CreateVulnerabilitiesAssessmentJsonBodyVirtualAnalystProfile,
    )


T = TypeVar("T", bound="CreateVulnerabilitiesAssessmentJsonBody")


@attr.s(auto_attribs=True)
class CreateVulnerabilitiesAssessmentJsonBody:
    """
    Attributes:
        dt_id (str): ID
        dt_version_id (str): ID
        name (str): Assessment name
        cna_priority (Union[Unset, List['CreateVulnerabilitiesAssessmentJsonBodyCnaPriorityItem']]):
        description (Union[Unset, str]): Assessment description
        detached (Union[Unset, bool]): Is assessment detached from previous assessments
        end_date (Union[Unset, datetime.datetime]): Assessment end date
        start_date (Union[Unset, datetime.datetime]): Assessment start date
        virtual_analyst_profile (Union[Unset, CreateVulnerabilitiesAssessmentJsonBodyVirtualAnalystProfile]): Assessment
            virtual analyst profile
    """

    dt_id: str
    dt_version_id: str
    name: str
    cna_priority: Union[Unset, List["CreateVulnerabilitiesAssessmentJsonBodyCnaPriorityItem"]] = UNSET
    description: Union[Unset, str] = UNSET
    detached: Union[Unset, bool] = False
    end_date: Union[Unset, datetime.datetime] = UNSET
    start_date: Union[Unset, datetime.datetime] = UNSET
    virtual_analyst_profile: Union[Unset, "CreateVulnerabilitiesAssessmentJsonBodyVirtualAnalystProfile"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        dt_id = self.dt_id
        dt_version_id = self.dt_version_id
        name = self.name
        cna_priority: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.cna_priority, Unset):
            cna_priority = []
            for cna_priority_item_data in self.cna_priority:
                cna_priority_item = cna_priority_item_data.to_dict()

                cna_priority.append(cna_priority_item)

        description = self.description
        detached = self.detached
        end_date: Union[Unset, str] = UNSET
        if not isinstance(self.end_date, Unset):
            end_date = self.end_date.isoformat()

        start_date: Union[Unset, str] = UNSET
        if not isinstance(self.start_date, Unset):
            start_date = self.start_date.isoformat()

        virtual_analyst_profile: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.virtual_analyst_profile, Unset):
            virtual_analyst_profile = self.virtual_analyst_profile.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "dt_id": dt_id,
                "dt_version_id": dt_version_id,
                "name": name,
            }
        )
        if cna_priority is not UNSET:
            field_dict["cna_priority"] = cna_priority
        if description is not UNSET:
            field_dict["description"] = description
        if detached is not UNSET:
            field_dict["detached"] = detached
        if end_date is not UNSET:
            field_dict["end_date"] = end_date
        if start_date is not UNSET:
            field_dict["start_date"] = start_date
        if virtual_analyst_profile is not UNSET:
            field_dict["virtual_analyst_profile"] = virtual_analyst_profile

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.create_vulnerabilities_assessment_json_body_cna_priority_item import (
            CreateVulnerabilitiesAssessmentJsonBodyCnaPriorityItem,
        )
        from ..models.create_vulnerabilities_assessment_json_body_virtual_analyst_profile import (
            CreateVulnerabilitiesAssessmentJsonBodyVirtualAnalystProfile,
        )

        d = src_dict.copy()
        dt_id = d.pop("dt_id")

        dt_version_id = d.pop("dt_version_id")

        name = d.pop("name")

        _cna_priority = d.pop("cna_priority", UNSET)
        if (_cna_priority) is UNSET:
            cna_priority = UNSET
        else:
            if _cna_priority:
                cna_priority = []
                for cna_priority_item_data in _cna_priority:
                    cna_priority_item = CreateVulnerabilitiesAssessmentJsonBodyCnaPriorityItem.from_dict(
                        cna_priority_item_data
                    )

                    cna_priority.append(cna_priority_item)
            else:
                cna_priority = []

        description = d.pop("description", UNSET)

        detached = d.pop("detached", UNSET)

        _end_date = d.pop("end_date", UNSET)
        end_date: Union[Unset, datetime.datetime]
        if isinstance(_end_date, Unset):
            end_date = UNSET
        else:
            end_date = isoparse(_end_date)

        _start_date = d.pop("start_date", UNSET)
        start_date: Union[Unset, datetime.datetime]
        if isinstance(_start_date, Unset):
            start_date = UNSET
        else:
            start_date = isoparse(_start_date)

        _virtual_analyst_profile = d.pop("virtual_analyst_profile", UNSET)
        virtual_analyst_profile: Union[Unset, CreateVulnerabilitiesAssessmentJsonBodyVirtualAnalystProfile]
        if isinstance(_virtual_analyst_profile, Unset):
            virtual_analyst_profile = UNSET
        else:
            virtual_analyst_profile = CreateVulnerabilitiesAssessmentJsonBodyVirtualAnalystProfile.from_dict(
                _virtual_analyst_profile
            )

        create_vulnerabilities_assessment_json_body = cls(
            dt_id=dt_id,
            dt_version_id=dt_version_id,
            name=name,
            cna_priority=cna_priority,
            description=description,
            detached=detached,
            end_date=end_date,
            start_date=start_date,
            virtual_analyst_profile=virtual_analyst_profile,
        )

        create_vulnerabilities_assessment_json_body.additional_properties = d
        return create_vulnerabilities_assessment_json_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
