from enum import Enum
from typing import Union


class DtUserPermissionsItem(str, Enum):
    DT_WORK = "dt_work"

    DT_VERSION_CREATE = "dt_version_create"

    DT_DELETE = "dt_delete"

    DT_VIEW = "dt_view"

    DT_REMOVE_ASSESSMENT = "dt_remove_assessment"

    DT_CREATE_ASSESSMENT = "dt_create_assessment"

    DT_UPDATE_SBOM = "dt_update_sbom"

    DT_UPDATE_ASSESSMENT = "dt_update_assessment"

    DT_MANAGE = "dt_manage"

    DT_VERSION_DELETE = "dt_version_delete"

    DT_BOM_WORKFLOW_WITHDRAW_APPROVAL = "dt_bom_workflow_withdraw_approval"

    DT_BOM_WORKFLOW_REQUEST_APPROVAL = "dt_bom_workflow_request_approval"

    DT_BOM_WORKFLOW_APPROVE = "dt_bom_workflow_approve"

    DT_BOM_WORKFLOW_REVOKE_APPROVAL = "dt_bom_workflow_revoke_approval"

    DT_BOM_WORKFLOW_REJECT_APPROVAL = "dt_bom_workflow_reject_approval"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "DtUserPermissionsItem"]) -> "DtUserPermissionsItem":
        if isinstance(value, DtUserPermissionsItem):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return DtUserPermissionsItem(value)
