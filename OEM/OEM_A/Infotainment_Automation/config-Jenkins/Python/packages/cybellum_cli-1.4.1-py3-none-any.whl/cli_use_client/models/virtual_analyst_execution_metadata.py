import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..models.virtual_analyst_execution_metadata_context import VirtualAnalystExecutionMetadataContext
from ..types import UNSET, Unset

T = TypeVar("T", bound="VirtualAnalystExecutionMetadata")


@attr.s(auto_attribs=True)
class VirtualAnalystExecutionMetadata:
    """Virtual analyst execution metadata

    Attributes:
        context (Union[Unset, VirtualAnalystExecutionMetadataContext]): Execution context of the virtual analyst
        executed_on (Union[Unset, datetime.datetime]): Execution time of the virtual analyst
    """

    context: Union[Unset, VirtualAnalystExecutionMetadataContext] = UNSET
    executed_on: Union[Unset, datetime.datetime] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        context: Union[Unset, str] = UNSET
        if not isinstance(self.context, Unset):
            context = VirtualAnalystExecutionMetadataContext.from_val(self.context).value

        executed_on: Union[Unset, str] = UNSET
        if not isinstance(self.executed_on, Unset):
            executed_on = self.executed_on.isoformat()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if context is not UNSET:
            field_dict["context"] = context
        if executed_on is not UNSET:
            field_dict["executed_on"] = executed_on

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        _context = d.pop("context", UNSET)
        context: Union[Unset, VirtualAnalystExecutionMetadataContext]
        if isinstance(_context, Unset):
            context = UNSET
        else:
            context = VirtualAnalystExecutionMetadataContext.from_val(_context)

        _executed_on = d.pop("executed_on", UNSET)
        executed_on: Union[Unset, datetime.datetime]
        if isinstance(_executed_on, Unset):
            executed_on = UNSET
        else:
            executed_on = isoparse(_executed_on)

        virtual_analyst_execution_metadata = cls(
            context=context,
            executed_on=executed_on,
        )

        virtual_analyst_execution_metadata.additional_properties = d
        return virtual_analyst_execution_metadata

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
