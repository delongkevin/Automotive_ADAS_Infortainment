from enum import Enum
from typing import Union


class LicenseType(str, Enum):
    COPYLEFT = "copyleft"

    AGPL = "agpl"

    LGPL = "lgpl"

    PERMISSIVE = "permissive"

    PROPRIETARY = "proprietary"

    UNKNOWN = "unknown"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "LicenseType"]) -> "LicenseType":
        if isinstance(value, LicenseType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return LicenseType(value)
