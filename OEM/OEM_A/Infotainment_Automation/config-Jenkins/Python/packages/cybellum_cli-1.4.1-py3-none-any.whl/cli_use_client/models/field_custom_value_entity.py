from enum import Enum
from typing import Union


class FieldCustomValueEntity(str, Enum):
    ASSET = "asset"

    PRODUCT = "product"

    COMPONENT = "component"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "FieldCustomValueEntity"]) -> "FieldCustomValueEntity":
        if isinstance(value, FieldCustomValueEntity):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return FieldCustomValueEntity(value)
