from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.resumable_upload_file_info_progress_phase_name import ResumableUploadFileInfoProgressPhaseName


T = TypeVar("T", bound="ResumableUploadFileInfoProgress")


@attr.s(auto_attribs=True)
class ResumableUploadFileInfoProgress:
    """Resumable upload file info progress

    Attributes:
        phase_name (Union[Unset, ResumableUploadFileInfoProgressPhaseName]): Resumable upload file phase progress
    """

    phase_name: Union[Unset, "ResumableUploadFileInfoProgressPhaseName"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        phase_name: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.phase_name, Unset):
            phase_name = self.phase_name.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if phase_name is not UNSET:
            field_dict["phase_name"] = phase_name

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.resumable_upload_file_info_progress_phase_name import ResumableUploadFileInfoProgressPhaseName

        d = src_dict.copy()
        _phase_name = d.pop("phase_name", UNSET)
        phase_name: Union[Unset, ResumableUploadFileInfoProgressPhaseName]
        if isinstance(_phase_name, Unset):
            phase_name = UNSET
        else:
            phase_name = ResumableUploadFileInfoProgressPhaseName.from_dict(_phase_name)

        resumable_upload_file_info_progress = cls(
            phase_name=phase_name,
        )

        resumable_upload_file_info_progress.additional_properties = d
        return resumable_upload_file_info_progress

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
