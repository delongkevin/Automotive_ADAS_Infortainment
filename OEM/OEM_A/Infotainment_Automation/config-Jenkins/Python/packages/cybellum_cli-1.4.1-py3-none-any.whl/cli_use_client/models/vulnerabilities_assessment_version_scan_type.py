from enum import Enum
from typing import Union


class VulnerabilitiesAssessmentVersionScanType(str, Enum):
    INITIAL = "initial"

    SBOM_CHANGED = "sbom_changed"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(
        cls, value: Union[str, "VulnerabilitiesAssessmentVersionScanType"]
    ) -> "VulnerabilitiesAssessmentVersionScanType":
        if isinstance(value, VulnerabilitiesAssessmentVersionScanType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return VulnerabilitiesAssessmentVersionScanType(value)
