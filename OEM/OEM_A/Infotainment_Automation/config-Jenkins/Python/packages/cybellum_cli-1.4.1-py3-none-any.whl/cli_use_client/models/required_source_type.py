from enum import Enum
from typing import Union


class RequiredSourceType(str, Enum):
    UNKNOWN = "UNKNOWN"

    KNOWN = "KNOWN"

    DIGITAL_TWIN = "DIGITAL_TWIN"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "RequiredSourceType"]) -> "RequiredSourceType":
        if isinstance(value, RequiredSourceType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return RequiredSourceType(value)
