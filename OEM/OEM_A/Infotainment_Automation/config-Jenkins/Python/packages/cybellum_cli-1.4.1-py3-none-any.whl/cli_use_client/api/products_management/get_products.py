from http import HTTPStatus
from typing import Any, Dict, List, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, AuthenticationStatus, Client, ParseResponseBehavior, flatten_params
from ...models.error import Error
from ...models.get_products_success import GetProductsSuccess
from ...models.level import Level
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    client: AuthenticatedClient,
    product_ids: Union[Unset, None, List[str]] = UNSET,
    product_clients: Union[Unset, None, List[str]] = UNSET,
    level: Union[Unset, None, Level] = UNSET,
) -> Dict[str, Any]:
    url = "{}/products".format(client.get_service_url("digital-twins"))

    headers: Dict[str, str] = client.get_headers()
    cookies: Dict[str, Any] = client.get_cookies()

    params: Dict[str, Any] = {}
    json_product_ids: Union[Unset, None, List[str]] = UNSET
    if not isinstance(product_ids, Unset):
        if product_ids is None:
            json_product_ids = None
        else:
            json_product_ids = product_ids

    params["product_ids"] = json_product_ids

    json_product_clients: Union[Unset, None, List[str]] = UNSET
    if not isinstance(product_clients, Unset):
        if product_clients is None:
            json_product_clients = None
        else:
            json_product_clients = product_clients

    params["product_clients"] = json_product_clients

    json_level: Union[Unset, None, str] = UNSET
    if not isinstance(level, Unset):
        json_level = Level.from_val(level).value if level else None

    params["level"] = json_level

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}
    params = flatten_params(params)

    return {
        "method": "get",
        "url": url,
        "headers": headers,
        "cookies": cookies,
        "timeout": client.get_timeout(),
        "params": params,
    }


def _parse_response(*, client: Client, response: httpx.Response) -> Optional[Union[Error, GetProductsSuccess]]:
    if response.status_code == HTTPStatus.OK:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_200 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_200 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_200 = GetProductsSuccess.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        return response_200

    if response.status_code == HTTPStatus.BAD_REQUEST:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_400 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_400 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_400 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_400, status_code=response.status_code
            )
        return response_400

    if response.status_code == HTTPStatus.UNAUTHORIZED:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_401 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_401 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_401 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_401, status_code=response.status_code
            )
        return response_401

    if response.status_code == HTTPStatus.FORBIDDEN:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_403 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_403 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_403 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_403, status_code=response.status_code
            )
        return response_403

    if response.status_code == HTTPStatus.NOT_FOUND:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_404 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_404 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_404 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_404, status_code=response.status_code
            )
        return response_404

    if response.status_code == HTTPStatus.METHOD_NOT_ALLOWED:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_405 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_405 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_405 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_405, status_code=response.status_code
            )
        return response_405

    if response.status_code == HTTPStatus.INTERNAL_SERVER_ERROR:
        if client.parse_response_behavior in [ParseResponseBehavior.NO_PARSING, ParseResponseBehavior.RAW_RESPONSE]:
            response_500 = None
        elif client.parse_response_behavior == ParseResponseBehavior.JSON_PARSING:
            response_500 = response.json() if response.content else None
        else:  # client.parse_response_behavior == ParseResponseBehavior.TYPED_PARSING
            try:
                response_500 = Error.from_dict(response.json())

            except Exception as e:
                raise errors.ParseError(
                    f"Failed to parse response into structured response: {response.content}", response, e
                )

        if client.raise_on_failed_status:
            raise errors.FailedStatus(
                f"Failed status code: {response.status_code}", response_500, status_code=response.status_code
            )
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(f"Unexpected status code: {response.status_code}")
    else:
        return None


def _build_response(
    *, client: Client, response: httpx.Response
) -> Union[Response[Union[Error, GetProductsSuccess]], httpx.Response]:
    if client.parse_response_behavior == ParseResponseBehavior.RAW_RESPONSE:
        return response

    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    product_ids: Union[Unset, None, List[str]] = UNSET,
    product_clients: Union[Unset, None, List[str]] = UNSET,
    level: Union[Unset, None, Level] = UNSET,
) -> Union[Response[Union[Error, GetProductsSuccess]], httpx.Response]:
    """Get products

     Gets products

    Args:
        product_ids (Union[Unset, None, List[str]]): Product ids
        product_clients (Union[Unset, None, List[str]]): Product clients
        level (Union[Unset, None, Level]): Level

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, GetProductsSuccess]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
        product_ids=product_ids,
        product_clients=product_clients,
        level=level,
    )

    with httpx.Client(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = _client.request(**kwargs)

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    product_ids: Union[Unset, None, List[str]] = UNSET,
    product_clients: Union[Unset, None, List[str]] = UNSET,
    level: Union[Unset, None, Level] = UNSET,
) -> Optional[Union[Error, GetProductsSuccess]]:
    """Get products

     Gets products

    Args:
        product_ids (Union[Unset, None, List[str]]): Product ids
        product_clients (Union[Unset, None, List[str]]): Product clients
        level (Union[Unset, None, Level]): Level

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, GetProductsSuccess]]
    """

    return sync_detailed(
        client=client,
        product_ids=product_ids,
        product_clients=product_clients,
        level=level,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    product_ids: Union[Unset, None, List[str]] = UNSET,
    product_clients: Union[Unset, None, List[str]] = UNSET,
    level: Union[Unset, None, Level] = UNSET,
) -> Union[Response[Union[Error, GetProductsSuccess]], httpx.Response]:
    """Get products

     Gets products

    Args:
        product_ids (Union[Unset, None, List[str]]): Product ids
        product_clients (Union[Unset, None, List[str]]): Product clients
        level (Union[Unset, None, Level]): Level

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, GetProductsSuccess]]
    """

    if client.get_authentication_status_sync() == AuthenticationStatus.NOT_AUTHENTICATED:
        raise errors.UnauthenticatedClient()

    kwargs = _get_kwargs(
        client=client,
        product_ids=product_ids,
        product_clients=product_clients,
        level=level,
    )

    async with httpx.AsyncClient(
        verify=client.verify_ssl,
        cert=client.cert,
        mounts=client.mounts,
    ) as _client:
        response = await _client.request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    product_ids: Union[Unset, None, List[str]] = UNSET,
    product_clients: Union[Unset, None, List[str]] = UNSET,
    level: Union[Unset, None, Level] = UNSET,
) -> Optional[Union[Error, GetProductsSuccess]]:
    """Get products

     Gets products

    Args:
        product_ids (Union[Unset, None, List[str]]): Product ids
        product_clients (Union[Unset, None, List[str]]): Product clients
        level (Union[Unset, None, Level]): Level

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, GetProductsSuccess]]
    """

    return (
        await asyncio_detailed(
            client=client,
            product_ids=product_ids,
            product_clients=product_clients,
            level=level,
        )
    ).parsed
