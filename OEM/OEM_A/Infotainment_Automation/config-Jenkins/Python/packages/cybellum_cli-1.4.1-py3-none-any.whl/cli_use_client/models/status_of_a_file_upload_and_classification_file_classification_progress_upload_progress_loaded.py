from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressLoaded")


@attr.s(auto_attribs=True)
class StatusOfAFileUploadAndClassificationFileClassificationProgressUploadProgressLoaded:
    """
    Attributes:
        size (Union[Unset, int]):
        size_label (Union[Unset, str]):
        size_units (Union[Unset, str]):
    """

    size: Union[Unset, int] = UNSET
    size_label: Union[Unset, str] = UNSET
    size_units: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        size = self.size
        size_label = self.size_label
        size_units = self.size_units

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if size is not UNSET:
            field_dict["size"] = size
        if size_label is not UNSET:
            field_dict["sizeLabel"] = size_label
        if size_units is not UNSET:
            field_dict["sizeUnits"] = size_units

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        size = d.pop("size", UNSET)

        size_label = d.pop("sizeLabel", UNSET)

        size_units = d.pop("sizeUnits", UNSET)

        status_of_a_file_upload_and_classification_file_classification_progress_upload_progress_loaded = cls(
            size=size,
            size_label=size_label,
            size_units=size_units,
        )

        status_of_a_file_upload_and_classification_file_classification_progress_upload_progress_loaded.additional_properties = (
            d
        )
        return status_of_a_file_upload_and_classification_file_classification_progress_upload_progress_loaded

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
