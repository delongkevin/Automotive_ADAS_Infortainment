from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.workflow import Workflow


T = TypeVar("T", bound="GetWorkflowsResponse200Data")


@attr.s(auto_attribs=True)
class GetWorkflowsResponse200Data:
    """
    Attributes:
        workflows (Union[Unset, List['Workflow']]):
    """

    workflows: Union[Unset, List["Workflow"]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        workflows: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.workflows, Unset):
            workflows = []
            for workflows_item_data in self.workflows:
                workflows_item = workflows_item_data.to_dict()

                workflows.append(workflows_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if workflows is not UNSET:
            field_dict["workflows"] = workflows

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.workflow import Workflow

        d = src_dict.copy()
        _workflows = d.pop("workflows", UNSET)
        if (_workflows) is UNSET:
            workflows = UNSET
        else:
            if _workflows:
                workflows = []
                for workflows_item_data in _workflows:
                    workflows_item = Workflow.from_dict(workflows_item_data)

                    workflows.append(workflows_item)
            else:
                workflows = []

        get_workflows_response_200_data = cls(
            workflows=workflows,
        )

        get_workflows_response_200_data.additional_properties = d
        return get_workflows_response_200_data

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
