from enum import Enum
from typing import Union


class BOMItemSourceType(str, Enum):
    OPEN_SOURCE = "open_source"

    COMMERCIAL = "commercial"

    PROPRIETARY = "proprietary"

    UNKNOWN = "unknown"

    def __str__(self) -> str:
        return str(self.value)

    @classmethod
    def from_val(cls, value: Union[str, "BOMItemSourceType"]) -> "BOMItemSourceType":
        if isinstance(value, BOMItemSourceType):
            return value

        value = value.lower()

        for enum in cls:
            if enum.value.lower() == value:
                return enum

        return BOMItemSourceType(value)
