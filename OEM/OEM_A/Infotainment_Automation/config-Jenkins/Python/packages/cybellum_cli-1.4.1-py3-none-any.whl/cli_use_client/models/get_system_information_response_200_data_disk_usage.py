from typing import Any, Dict, List, Type, TypeVar

import attr

T = TypeVar("T", bound="GetSystemInformationResponse200DataDiskUsage")


@attr.s(auto_attribs=True)
class GetSystemInformationResponse200DataDiskUsage:
    """Disk usage attributes

    Attributes:
        free_mb (float): Free storage in megabytes
        total_mb (float): Total storage size in megabytes
        used_mb (float): Used storage in megabytes
    """

    free_mb: float
    total_mb: float
    used_mb: float
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        free_mb = self.free_mb
        total_mb = self.total_mb
        used_mb = self.used_mb

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "free_mb": free_mb,
                "total_mb": total_mb,
                "used_mb": used_mb,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        free_mb = d.pop("free_mb")

        total_mb = d.pop("total_mb")

        used_mb = d.pop("used_mb")

        get_system_information_response_200_data_disk_usage = cls(
            free_mb=free_mb,
            total_mb=total_mb,
            used_mb=used_mb,
        )

        get_system_information_response_200_data_disk_usage.additional_properties = d
        return get_system_information_response_200_data_disk_usage

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
