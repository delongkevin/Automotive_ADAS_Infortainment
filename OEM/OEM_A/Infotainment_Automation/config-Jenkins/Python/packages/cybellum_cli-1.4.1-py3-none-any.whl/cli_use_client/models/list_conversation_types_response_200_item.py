from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="ListConversationTypesResponse200Item")


@attr.s(auto_attribs=True)
class ListConversationTypesResponse200Item:
    """
    Attributes:
        arguments (Union[Unset, str]): String representing the arguments required for the conversation type, separated
            by /.
        description (Union[Unset, str]): A brief description of the conversation type.
        type (Union[Unset, str]): The identifier for the conversation type (e.g., "cve", "assessment").
    """

    arguments: Union[Unset, str] = UNSET
    description: Union[Unset, str] = UNSET
    type: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        arguments = self.arguments
        description = self.description
        type = self.type

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if arguments is not UNSET:
            field_dict["arguments"] = arguments
        if description is not UNSET:
            field_dict["description"] = description
        if type is not UNSET:
            field_dict["type"] = type

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        arguments = d.pop("arguments", UNSET)

        description = d.pop("description", UNSET)

        type = d.pop("type", UNSET)

        list_conversation_types_response_200_item = cls(
            arguments=arguments,
            description=description,
            type=type,
        )

        list_conversation_types_response_200_item.additional_properties = d
        return list_conversation_types_response_200_item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
