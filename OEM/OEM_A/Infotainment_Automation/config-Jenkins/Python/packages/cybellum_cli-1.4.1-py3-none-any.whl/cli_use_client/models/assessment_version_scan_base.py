import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..models.scan_state import ScanState
from ..models.scan_sub_state import ScanSubState
from ..types import UNSET, Unset

T = TypeVar("T", bound="AssessmentVersionScanBase")


@attr.s(auto_attribs=True)
class AssessmentVersionScanBase:
    """Assessment version scan

    Attributes:
        id (str): ID
        queued_time (datetime.datetime): Scan queued time
        state (ScanState): Scan state
        sub_state (ScanSubState): Scan sub state
        worker_id (str): Worker id
        finish_time (Union[Unset, None, datetime.datetime]): Scan finish time
        percentage_completed (Union[Unset, float]): Completion percentage of the scan
        start_time (Union[Unset, None, datetime.datetime]): Scan start time
    """

    id: str
    queued_time: datetime.datetime
    state: ScanState
    sub_state: ScanSubState
    worker_id: str
    finish_time: Union[Unset, None, datetime.datetime] = UNSET
    percentage_completed: Union[Unset, float] = UNSET
    start_time: Union[Unset, None, datetime.datetime] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        id = self.id
        queued_time = self.queued_time.isoformat()

        state = ScanState.from_val(self.state).value

        sub_state = ScanSubState.from_val(self.sub_state).value

        worker_id = self.worker_id
        finish_time: Union[Unset, None, str] = UNSET
        if not isinstance(self.finish_time, Unset):
            finish_time = self.finish_time.isoformat() if self.finish_time else None

        percentage_completed = self.percentage_completed
        start_time: Union[Unset, None, str] = UNSET
        if not isinstance(self.start_time, Unset):
            start_time = self.start_time.isoformat() if self.start_time else None

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "queued_time": queued_time,
                "state": state,
                "sub_state": sub_state,
                "worker_id": worker_id,
            }
        )
        if finish_time is not UNSET:
            field_dict["finish_time"] = finish_time
        if percentage_completed is not UNSET:
            field_dict["percentage_completed"] = percentage_completed
        if start_time is not UNSET:
            field_dict["start_time"] = start_time

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        id = d.pop("id")

        queued_time = isoparse(d.pop("queued_time"))

        state = ScanState.from_val(d.pop("state"))

        sub_state = ScanSubState.from_val(d.pop("sub_state"))

        worker_id = d.pop("worker_id")

        _finish_time = d.pop("finish_time", UNSET)
        finish_time: Union[Unset, None, datetime.datetime]
        if _finish_time is None:
            finish_time = None
        elif isinstance(_finish_time, Unset):
            finish_time = UNSET
        else:
            finish_time = isoparse(_finish_time)

        percentage_completed = d.pop("percentage_completed", UNSET)

        _start_time = d.pop("start_time", UNSET)
        start_time: Union[Unset, None, datetime.datetime]
        if _start_time is None:
            start_time = None
        elif isinstance(_start_time, Unset):
            start_time = UNSET
        else:
            start_time = isoparse(_start_time)

        assessment_version_scan_base = cls(
            id=id,
            queued_time=queued_time,
            state=state,
            sub_state=sub_state,
            worker_id=worker_id,
            finish_time=finish_time,
            percentage_completed=percentage_completed,
            start_time=start_time,
        )

        assessment_version_scan_base.additional_properties = d
        return assessment_version_scan_base

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
