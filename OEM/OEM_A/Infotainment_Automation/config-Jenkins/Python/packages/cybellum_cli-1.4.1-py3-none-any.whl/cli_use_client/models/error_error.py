from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.error_error_fields_errors import ErrorErrorFieldsErrors


T = TypeVar("T", bound="ErrorError")


@attr.s(auto_attribs=True)
class ErrorError:
    """
    Attributes:
        error_code (str): Technical error code
        message (str): The descritpion of the error
        fields_errors (Union[Unset, ErrorErrorFieldsErrors]): Presents errors that came from specific parameter fields
    """

    error_code: str
    message: str
    fields_errors: Union[Unset, "ErrorErrorFieldsErrors"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        error_code = self.error_code
        message = self.message
        fields_errors: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.fields_errors, Unset):
            fields_errors = self.fields_errors.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "error_code": error_code,
                "message": message,
            }
        )
        if fields_errors is not UNSET:
            field_dict["fields_errors"] = fields_errors

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.error_error_fields_errors import ErrorErrorFieldsErrors

        d = src_dict.copy()
        error_code = d.pop("error_code")

        message = d.pop("message")

        _fields_errors = d.pop("fields_errors", UNSET)
        fields_errors: Union[Unset, ErrorErrorFieldsErrors]
        if isinstance(_fields_errors, Unset):
            fields_errors = UNSET
        else:
            fields_errors = ErrorErrorFieldsErrors.from_dict(_fields_errors)

        error_error = cls(
            error_code=error_code,
            message=message,
            fields_errors=fields_errors,
        )

        error_error.additional_properties = d
        return error_error

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
