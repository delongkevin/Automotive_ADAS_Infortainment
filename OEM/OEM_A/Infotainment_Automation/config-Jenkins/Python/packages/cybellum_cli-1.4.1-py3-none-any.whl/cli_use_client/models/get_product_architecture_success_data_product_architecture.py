import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

import attr
from dateutil.parser import isoparse

from ..models.level import Level
from ..models.permission import Permission
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.attached_elements import AttachedElements
    from ..models.connection import Connection
    from ..models.product_custom_fields import ProductCustomFields
    from ..models.product_version import ProductVersion


T = TypeVar("T", bound="GetProductArchitectureSuccessDataProductArchitecture")


@attr.s(auto_attribs=True)
class GetProductArchitectureSuccessDataProductArchitecture:
    """
    Attributes:
        created_by (str): Product created by user
        created_on (datetime.datetime): Creation date of the product
        id (str): ID
        last_modified_on (datetime.datetime): Last modified date of the product
        level (Level): Level
        name (str): Product name
        approval_status (Union[Unset, float]): Percentage of approved components
        business_unit (Union[Unset, str]): Product business unit
        cal (Union[Unset, int]): Cybersecurity Assurance Level
        component_category (Union[Unset, str]): the component category of the digital twin

            for Vehicle Edition - the default possible values are:

            - adas
            - gateway
            - infotainment
            - power_steering
            - telecommunication
            - telematics
            - transmission_control_unit
            - key_fob
            - mobile_application_automotive
            - obd2_dongle
            - connected_ecu

            for Medical Edition - the default possible values are:

            - home_care_device
            - medical_imaging_system
            - other_medical_device
            - implantable_device
            - defibrillator
            - pacemaker
            - ventricular_assist_device
            - brain_stimulator
            - dialysis_device
            - infusion_insulin_pump
            - mobile_application_medical

            for IOT Edition - the default possible values are:

            - smart_home_device
            - smart_meter
            - energy_control_system
            - ip_camera
            - industrial_robot
            - mobile_application_iot
            - network_device
            - other_iot_device
            - storage_device
            - server
            - printer
            - pbx

            for Scanner - the default possible values are:

            - connected_component

            for all editions values can be customized by configuration
        custom_fields (Union[Unset, ProductCustomFields]): Custom Fields
        markets (Union[Unset, List[str]]): Product markets
        part_number (Union[Unset, str]): Product part number
        tags (Union[Unset, List[str]]): Product tags
        url (Union[Unset, str]): Product URL
        user_product_permissions (Union[Unset, List[Permission]]): Product user permissions
        variant (Union[Unset, str]): Product variant
        versions (Union[Unset, List['ProductVersion']]): Product versions
        attached_elements (Union[Unset, List['AttachedElements']]):
        connections (Union[Unset, List['Connection']]):
    """

    created_by: str
    created_on: datetime.datetime
    id: str
    last_modified_on: datetime.datetime
    level: Level
    name: str
    approval_status: Union[Unset, float] = UNSET
    business_unit: Union[Unset, str] = UNSET
    cal: Union[Unset, int] = UNSET
    component_category: Union[Unset, str] = UNSET
    custom_fields: Union[Unset, "ProductCustomFields"] = UNSET
    markets: Union[Unset, List[str]] = UNSET
    part_number: Union[Unset, str] = UNSET
    tags: Union[Unset, List[str]] = UNSET
    url: Union[Unset, str] = UNSET
    user_product_permissions: Union[Unset, List[Permission]] = UNSET
    variant: Union[Unset, str] = UNSET
    versions: Union[Unset, List["ProductVersion"]] = UNSET
    attached_elements: Union[Unset, List["AttachedElements"]] = UNSET
    connections: Union[Unset, List["Connection"]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        created_by = self.created_by
        created_on = self.created_on.isoformat()

        id = self.id
        last_modified_on = self.last_modified_on.isoformat()

        level = Level.from_val(self.level).value

        name = self.name
        approval_status = self.approval_status
        business_unit = self.business_unit
        cal = self.cal
        component_category = self.component_category
        custom_fields: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        markets: Union[Unset, List[str]] = UNSET
        if not isinstance(self.markets, Unset):
            markets = self.markets

        part_number = self.part_number
        tags: Union[Unset, List[str]] = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        url = self.url
        user_product_permissions: Union[Unset, List[str]] = UNSET
        if not isinstance(self.user_product_permissions, Unset):
            user_product_permissions = []
            for user_product_permissions_item_data in self.user_product_permissions:
                user_product_permissions_item = Permission.from_val(user_product_permissions_item_data).value

                user_product_permissions.append(user_product_permissions_item)

        variant = self.variant
        versions: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.versions, Unset):
            versions = []
            for versions_item_data in self.versions:
                versions_item = versions_item_data.to_dict()

                versions.append(versions_item)

        attached_elements: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.attached_elements, Unset):
            attached_elements = []
            for attached_elements_item_data in self.attached_elements:
                attached_elements_item = attached_elements_item_data.to_dict()

                attached_elements.append(attached_elements_item)

        connections: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.connections, Unset):
            connections = []
            for connections_item_data in self.connections:
                connections_item = connections_item_data.to_dict()

                connections.append(connections_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "created_by": created_by,
                "created_on": created_on,
                "id": id,
                "last_modified_on": last_modified_on,
                "level": level,
                "name": name,
            }
        )
        if approval_status is not UNSET:
            field_dict["approval_status"] = approval_status
        if business_unit is not UNSET:
            field_dict["business_unit"] = business_unit
        if cal is not UNSET:
            field_dict["cal"] = cal
        if component_category is not UNSET:
            field_dict["component_category"] = component_category
        if custom_fields is not UNSET:
            field_dict["custom_fields"] = custom_fields
        if markets is not UNSET:
            field_dict["markets"] = markets
        if part_number is not UNSET:
            field_dict["part_number"] = part_number
        if tags is not UNSET:
            field_dict["tags"] = tags
        if url is not UNSET:
            field_dict["url"] = url
        if user_product_permissions is not UNSET:
            field_dict["user_product_permissions"] = user_product_permissions
        if variant is not UNSET:
            field_dict["variant"] = variant
        if versions is not UNSET:
            field_dict["versions"] = versions
        if attached_elements is not UNSET:
            field_dict["attached_elements"] = attached_elements
        if connections is not UNSET:
            field_dict["connections"] = connections

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.attached_elements import AttachedElements
        from ..models.connection import Connection
        from ..models.product_custom_fields import ProductCustomFields
        from ..models.product_version import ProductVersion

        d = src_dict.copy()
        created_by = d.pop("created_by")

        created_on = isoparse(d.pop("created_on"))

        id = d.pop("id")

        last_modified_on = isoparse(d.pop("last_modified_on"))

        level = Level.from_val(d.pop("level"))

        name = d.pop("name")

        approval_status = d.pop("approval_status", UNSET)

        business_unit = d.pop("business_unit", UNSET)

        cal = d.pop("cal", UNSET)

        component_category = d.pop("component_category", UNSET)

        _custom_fields = d.pop("custom_fields", UNSET)
        custom_fields: Union[Unset, ProductCustomFields]
        if isinstance(_custom_fields, Unset):
            custom_fields = UNSET
        else:
            custom_fields = ProductCustomFields.from_dict(_custom_fields)

        markets = cast(List[str], d.pop("markets", UNSET))

        part_number = d.pop("part_number", UNSET)

        tags = cast(List[str], d.pop("tags", UNSET))

        url = d.pop("url", UNSET)

        _user_product_permissions = d.pop("user_product_permissions", UNSET)
        if (_user_product_permissions) is UNSET:
            user_product_permissions = UNSET
        else:
            if _user_product_permissions:
                user_product_permissions = []
                for user_product_permissions_item_data in _user_product_permissions:
                    user_product_permissions_item = Permission.from_val(user_product_permissions_item_data)

                    user_product_permissions.append(user_product_permissions_item)
            else:
                user_product_permissions = []

        variant = d.pop("variant", UNSET)

        _versions = d.pop("versions", UNSET)
        if (_versions) is UNSET:
            versions = UNSET
        else:
            if _versions:
                versions = []
                for versions_item_data in _versions:
                    versions_item = ProductVersion.from_dict(versions_item_data)

                    versions.append(versions_item)
            else:
                versions = []

        _attached_elements = d.pop("attached_elements", UNSET)
        if (_attached_elements) is UNSET:
            attached_elements = UNSET
        else:
            if _attached_elements:
                attached_elements = []
                for attached_elements_item_data in _attached_elements:
                    attached_elements_item = AttachedElements.from_dict(attached_elements_item_data)

                    attached_elements.append(attached_elements_item)
            else:
                attached_elements = []

        _connections = d.pop("connections", UNSET)
        if (_connections) is UNSET:
            connections = UNSET
        else:
            if _connections:
                connections = []
                for connections_item_data in _connections:
                    connections_item = Connection.from_dict(connections_item_data)

                    connections.append(connections_item)
            else:
                connections = []

        get_product_architecture_success_data_product_architecture = cls(
            created_by=created_by,
            created_on=created_on,
            id=id,
            last_modified_on=last_modified_on,
            level=level,
            name=name,
            approval_status=approval_status,
            business_unit=business_unit,
            cal=cal,
            component_category=component_category,
            custom_fields=custom_fields,
            markets=markets,
            part_number=part_number,
            tags=tags,
            url=url,
            user_product_permissions=user_product_permissions,
            variant=variant,
            versions=versions,
            attached_elements=attached_elements,
            connections=connections,
        )

        get_product_architecture_success_data_product_architecture.additional_properties = d
        return get_product_architecture_success_data_product_architecture

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
