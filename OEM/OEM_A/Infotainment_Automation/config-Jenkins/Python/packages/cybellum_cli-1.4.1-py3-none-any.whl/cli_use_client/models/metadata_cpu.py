from typing import Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

T = TypeVar("T", bound="MetadataCpu")


@attr.s(auto_attribs=True)
class MetadataCpu:
    """CPU information

    Attributes:
        cpu_bit_size (Union[Unset, str]): CPU bit size
        cpu_family (Union[Unset, str]): CPU famility
    """

    cpu_bit_size: Union[Unset, str] = UNSET
    cpu_family: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        cpu_bit_size = self.cpu_bit_size
        cpu_family = self.cpu_family

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if cpu_bit_size is not UNSET:
            field_dict["cpu_bit_size"] = cpu_bit_size
        if cpu_family is not UNSET:
            field_dict["cpu_family"] = cpu_family

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        cpu_bit_size = d.pop("cpu_bit_size", UNSET)

        cpu_family = d.pop("cpu_family", UNSET)

        metadata_cpu = cls(
            cpu_bit_size=cpu_bit_size,
            cpu_family=cpu_family,
        )

        metadata_cpu.additional_properties = d
        return metadata_cpu

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
