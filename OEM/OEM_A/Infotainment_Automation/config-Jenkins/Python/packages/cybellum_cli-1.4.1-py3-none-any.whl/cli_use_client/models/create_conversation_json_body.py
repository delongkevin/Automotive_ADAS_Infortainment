from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_conversation_json_body_context_arguments_item import (
        CreateConversationJsonBodyContextArgumentsItem,
    )


T = TypeVar("T", bound="CreateConversationJsonBody")


@attr.s(auto_attribs=True)
class CreateConversationJsonBody:
    """
    Attributes:
        context_arguments (Union[Unset, List['CreateConversationJsonBodyContextArgumentsItem']]): A list of JSON
            objects, each containing context arguments.
        conversation_type (Union[Unset, str]): The type of the conversation being created.
        model_name (Union[Unset, str]): (Optional) The ID of the AI model to use for the conversation.
    """

    context_arguments: Union[Unset, List["CreateConversationJsonBodyContextArgumentsItem"]] = UNSET
    conversation_type: Union[Unset, str] = UNSET
    model_name: Union[Unset, str] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        context_arguments: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.context_arguments, Unset):
            context_arguments = []
            for context_arguments_item_data in self.context_arguments:
                context_arguments_item = context_arguments_item_data.to_dict()

                context_arguments.append(context_arguments_item)

        conversation_type = self.conversation_type
        model_name = self.model_name

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if context_arguments is not UNSET:
            field_dict["context_arguments"] = context_arguments
        if conversation_type is not UNSET:
            field_dict["conversation_type"] = conversation_type
        if model_name is not UNSET:
            field_dict["model_name"] = model_name

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.create_conversation_json_body_context_arguments_item import (
            CreateConversationJsonBodyContextArgumentsItem,
        )

        d = src_dict.copy()
        _context_arguments = d.pop("context_arguments", UNSET)
        if (_context_arguments) is UNSET:
            context_arguments = UNSET
        else:
            if _context_arguments:
                context_arguments = []
                for context_arguments_item_data in _context_arguments:
                    context_arguments_item = CreateConversationJsonBodyContextArgumentsItem.from_dict(
                        context_arguments_item_data
                    )

                    context_arguments.append(context_arguments_item)
            else:
                context_arguments = []

        conversation_type = d.pop("conversation_type", UNSET)

        model_name = d.pop("model_name", UNSET)

        create_conversation_json_body = cls(
            context_arguments=context_arguments,
            conversation_type=conversation_type,
            model_name=model_name,
        )

        create_conversation_json_body.additional_properties = d
        return create_conversation_json_body

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
