from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin_version_created_workflow_basic_configuration import (
        DigitalTwinVersionCreatedWorkflowBasicConfiguration,
    )


T = TypeVar("T", bound="DigitalTwinVersionCreatedWorkflow")


@attr.s(auto_attribs=True)
class DigitalTwinVersionCreatedWorkflow:
    """Digital twin version created workflow

    Attributes:
        basic_configuration (Union[Unset, DigitalTwinVersionCreatedWorkflowBasicConfiguration]): Workflow configurations
    """

    basic_configuration: Union[Unset, "DigitalTwinVersionCreatedWorkflowBasicConfiguration"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        basic_configuration: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.basic_configuration, Unset):
            basic_configuration = self.basic_configuration.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if basic_configuration is not UNSET:
            field_dict["basic_configuration"] = basic_configuration

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin_version_created_workflow_basic_configuration import (
            DigitalTwinVersionCreatedWorkflowBasicConfiguration,
        )

        d = src_dict.copy()
        _basic_configuration = d.pop("basic_configuration", UNSET)
        basic_configuration: Union[Unset, DigitalTwinVersionCreatedWorkflowBasicConfiguration]
        if isinstance(_basic_configuration, Unset):
            basic_configuration = UNSET
        else:
            basic_configuration = DigitalTwinVersionCreatedWorkflowBasicConfiguration.from_dict(_basic_configuration)

        digital_twin_version_created_workflow = cls(
            basic_configuration=basic_configuration,
        )

        digital_twin_version_created_workflow.additional_properties = d
        return digital_twin_version_created_workflow

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
