from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

import attr

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.information_propagation_generic_configurations import InformationPropagationGenericConfigurations
    from ..models.information_propagation_sbom import InformationPropagationSbom


T = TypeVar("T", bound="InformationPropagation")


@attr.s(auto_attribs=True)
class InformationPropagation:
    """Information propagation

    Attributes:
        generic_configurations (Union[Unset, InformationPropagationGenericConfigurations]): Generic configurations
            propagation configuration
        sbom (Union[Unset, InformationPropagationSbom]): SBOM propagation configurations
    """

    generic_configurations: Union[Unset, "InformationPropagationGenericConfigurations"] = UNSET
    sbom: Union[Unset, "InformationPropagationSbom"] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        generic_configurations: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.generic_configurations, Unset):
            generic_configurations = self.generic_configurations.to_dict()

        sbom: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.sbom, Unset):
            sbom = self.sbom.to_dict()

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if generic_configurations is not UNSET:
            field_dict["generic_configurations"] = generic_configurations
        if sbom is not UNSET:
            field_dict["sbom"] = sbom

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.information_propagation_generic_configurations import InformationPropagationGenericConfigurations
        from ..models.information_propagation_sbom import InformationPropagationSbom

        d = src_dict.copy()
        _generic_configurations = d.pop("generic_configurations", UNSET)
        generic_configurations: Union[Unset, InformationPropagationGenericConfigurations]
        if isinstance(_generic_configurations, Unset):
            generic_configurations = UNSET
        else:
            generic_configurations = InformationPropagationGenericConfigurations.from_dict(_generic_configurations)

        _sbom = d.pop("sbom", UNSET)
        sbom: Union[Unset, InformationPropagationSbom]
        if isinstance(_sbom, Unset):
            sbom = UNSET
        else:
            sbom = InformationPropagationSbom.from_dict(_sbom)

        information_propagation = cls(
            generic_configurations=generic_configurations,
            sbom=sbom,
        )

        information_propagation.additional_properties = d
        return information_propagation

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
