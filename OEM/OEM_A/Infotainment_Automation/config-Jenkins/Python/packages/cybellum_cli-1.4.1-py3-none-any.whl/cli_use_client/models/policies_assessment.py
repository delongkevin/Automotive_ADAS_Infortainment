import datetime
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Type, TypeVar, Union

import attr
from dateutil.parser import isoparse

from ..models.assessment_status import AssessmentStatus
from ..models.dt_user_permissions_item import DtUserPermissionsItem
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.digital_twin import DigitalTwin
    from ..models.policies_assessment_dependent_assessments_item import PoliciesAssessmentDependentAssessmentsItem
    from ..models.policies_assessment_version import PoliciesAssessmentVersion
    from ..models.policy_information import PolicyInformation


T = TypeVar("T", bound="PoliciesAssessment")


@attr.s(auto_attribs=True)
class PoliciesAssessment:
    """Policies assessment

    Attributes:
        dt_id (str): ID
        id (str): ID
        name (str): Assessment name
        policy_id (str): Policy id of the assessment
        created_by (Union[Unset, str]): Assessment creator username
        created_on (Union[Unset, datetime.datetime]): Assessment creation date
        default_assessment_version (Union[Unset, None, PoliciesAssessmentVersion]): Policies assessment version
        dependent_assessments (Union[Unset, List['PoliciesAssessmentDependentAssessmentsItem']]): Dependant assessments
            of the policies assessment
        description (Union[Unset, str]): Assessment description
        dt (Union[Unset, DigitalTwin]): Digital twin
        dt_version_assessment_version (Optional[PoliciesAssessmentVersion]): Policies assessment version
        end_date (Union[Unset, datetime.datetime]): Assessment end date
        last_modified_on (Union[Unset, str]): Last time assessment was modified
        policy (Union[Unset, PolicyInformation]): Policy information
        start_date (Union[Unset, datetime.datetime]): Assessment start date
        status (Union[Unset, AssessmentStatus]): Status of the assessment
        status_reason (Union[Unset, str]): Status reason of the assessment
        user_dt_permissions (Union[Unset, List[DtUserPermissionsItem]]): Digital twin permissions Example: ['dt_work'].
    """

    dt_id: str
    id: str
    name: str
    policy_id: str
    dt_version_assessment_version: Optional["PoliciesAssessmentVersion"]
    created_by: Union[Unset, str] = UNSET
    created_on: Union[Unset, datetime.datetime] = UNSET
    default_assessment_version: Union[Unset, None, "PoliciesAssessmentVersion"] = UNSET
    dependent_assessments: Union[Unset, List["PoliciesAssessmentDependentAssessmentsItem"]] = UNSET
    description: Union[Unset, str] = UNSET
    dt: Union[Unset, "DigitalTwin"] = UNSET
    end_date: Union[Unset, datetime.datetime] = UNSET
    last_modified_on: Union[Unset, str] = UNSET
    policy: Union[Unset, "PolicyInformation"] = UNSET
    start_date: Union[Unset, datetime.datetime] = UNSET
    status: Union[Unset, AssessmentStatus] = UNSET
    status_reason: Union[Unset, str] = UNSET
    user_dt_permissions: Union[Unset, List[DtUserPermissionsItem]] = UNSET
    additional_properties: Dict[str, Any] = attr.ib(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        dt_id = self.dt_id
        id = self.id
        name = self.name
        policy_id = self.policy_id
        created_by = self.created_by
        created_on: Union[Unset, str] = UNSET
        if not isinstance(self.created_on, Unset):
            created_on = self.created_on.isoformat()

        default_assessment_version: Union[Unset, None, Dict[str, Any]] = UNSET
        if not isinstance(self.default_assessment_version, Unset):
            default_assessment_version = (
                self.default_assessment_version.to_dict() if self.default_assessment_version else None
            )

        dependent_assessments: Union[Unset, List[Dict[str, Any]]] = UNSET
        if not isinstance(self.dependent_assessments, Unset):
            dependent_assessments = []
            for dependent_assessments_item_data in self.dependent_assessments:
                dependent_assessments_item = dependent_assessments_item_data.to_dict()

                dependent_assessments.append(dependent_assessments_item)

        description = self.description
        dt: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.dt, Unset):
            dt = self.dt.to_dict()

        dt_version_assessment_version = (
            self.dt_version_assessment_version.to_dict() if self.dt_version_assessment_version else None
        )

        end_date: Union[Unset, str] = UNSET
        if not isinstance(self.end_date, Unset):
            end_date = self.end_date.isoformat()

        last_modified_on = self.last_modified_on
        policy: Union[Unset, Dict[str, Any]] = UNSET
        if not isinstance(self.policy, Unset):
            policy = self.policy.to_dict()

        start_date: Union[Unset, str] = UNSET
        if not isinstance(self.start_date, Unset):
            start_date = self.start_date.isoformat()

        status: Union[Unset, str] = UNSET
        if not isinstance(self.status, Unset):
            status = AssessmentStatus.from_val(self.status).value

        status_reason = self.status_reason
        user_dt_permissions: Union[Unset, List[str]] = UNSET
        if not isinstance(self.user_dt_permissions, Unset):
            user_dt_permissions = []
            for componentsschemasdt_user_permissions_item_data in self.user_dt_permissions:
                componentsschemasdt_user_permissions_item = DtUserPermissionsItem.from_val(
                    componentsschemasdt_user_permissions_item_data
                ).value

                user_dt_permissions.append(componentsschemasdt_user_permissions_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "dt_id": dt_id,
                "id": id,
                "name": name,
                "policy_id": policy_id,
                "dt_version_assessment_version": dt_version_assessment_version,
            }
        )
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if created_on is not UNSET:
            field_dict["created_on"] = created_on
        if default_assessment_version is not UNSET:
            field_dict["default_assessment_version"] = default_assessment_version
        if dependent_assessments is not UNSET:
            field_dict["dependent_assessments"] = dependent_assessments
        if description is not UNSET:
            field_dict["description"] = description
        if dt is not UNSET:
            field_dict["dt"] = dt
        if end_date is not UNSET:
            field_dict["end_date"] = end_date
        if last_modified_on is not UNSET:
            field_dict["last_modified_on"] = last_modified_on
        if policy is not UNSET:
            field_dict["policy"] = policy
        if start_date is not UNSET:
            field_dict["start_date"] = start_date
        if status is not UNSET:
            field_dict["status"] = status
        if status_reason is not UNSET:
            field_dict["status_reason"] = status_reason
        if user_dt_permissions is not UNSET:
            field_dict["user_dt_permissions"] = user_dt_permissions

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.digital_twin import DigitalTwin
        from ..models.policies_assessment_dependent_assessments_item import PoliciesAssessmentDependentAssessmentsItem
        from ..models.policies_assessment_version import PoliciesAssessmentVersion
        from ..models.policy_information import PolicyInformation

        d = src_dict.copy()
        dt_id = d.pop("dt_id")

        id = d.pop("id")

        name = d.pop("name")

        policy_id = d.pop("policy_id")

        created_by = d.pop("created_by", UNSET)

        _created_on = d.pop("created_on", UNSET)
        created_on: Union[Unset, datetime.datetime]
        if isinstance(_created_on, Unset):
            created_on = UNSET
        else:
            created_on = isoparse(_created_on)

        _default_assessment_version = d.pop("default_assessment_version", UNSET)
        default_assessment_version: Union[Unset, None, PoliciesAssessmentVersion]
        if _default_assessment_version is None:
            default_assessment_version = None
        elif isinstance(_default_assessment_version, Unset):
            default_assessment_version = UNSET
        else:
            default_assessment_version = PoliciesAssessmentVersion.from_dict(_default_assessment_version)

        _dependent_assessments = d.pop("dependent_assessments", UNSET)
        if (_dependent_assessments) is UNSET:
            dependent_assessments = UNSET
        else:
            if _dependent_assessments:
                dependent_assessments = []
                for dependent_assessments_item_data in _dependent_assessments:
                    dependent_assessments_item = PoliciesAssessmentDependentAssessmentsItem.from_dict(
                        dependent_assessments_item_data
                    )

                    dependent_assessments.append(dependent_assessments_item)
            else:
                dependent_assessments = []

        description = d.pop("description", UNSET)

        _dt = d.pop("dt", UNSET)
        dt: Union[Unset, DigitalTwin]
        if isinstance(_dt, Unset):
            dt = UNSET
        else:
            dt = DigitalTwin.from_dict(_dt)

        _dt_version_assessment_version = d.pop("dt_version_assessment_version")
        dt_version_assessment_version: Optional[PoliciesAssessmentVersion]
        if _dt_version_assessment_version is None:
            dt_version_assessment_version = None
        else:
            dt_version_assessment_version = PoliciesAssessmentVersion.from_dict(_dt_version_assessment_version)

        _end_date = d.pop("end_date", UNSET)
        end_date: Union[Unset, datetime.datetime]
        if isinstance(_end_date, Unset):
            end_date = UNSET
        else:
            end_date = isoparse(_end_date)

        last_modified_on = d.pop("last_modified_on", UNSET)

        _policy = d.pop("policy", UNSET)
        policy: Union[Unset, PolicyInformation]
        if isinstance(_policy, Unset):
            policy = UNSET
        else:
            policy = PolicyInformation.from_dict(_policy)

        _start_date = d.pop("start_date", UNSET)
        start_date: Union[Unset, datetime.datetime]
        if isinstance(_start_date, Unset):
            start_date = UNSET
        else:
            start_date = isoparse(_start_date)

        _status = d.pop("status", UNSET)
        status: Union[Unset, AssessmentStatus]
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = AssessmentStatus.from_val(_status)

        status_reason = d.pop("status_reason", UNSET)

        _user_dt_permissions = d.pop("user_dt_permissions", UNSET)
        if (_user_dt_permissions) is UNSET:
            user_dt_permissions = UNSET
        else:
            if _user_dt_permissions:
                user_dt_permissions = []
                for componentsschemasdt_user_permissions_item_data in _user_dt_permissions:
                    componentsschemasdt_user_permissions_item = DtUserPermissionsItem.from_val(
                        componentsschemasdt_user_permissions_item_data
                    )

                    user_dt_permissions.append(componentsschemasdt_user_permissions_item)
            else:
                user_dt_permissions = []

        policies_assessment = cls(
            dt_id=dt_id,
            id=id,
            name=name,
            policy_id=policy_id,
            created_by=created_by,
            created_on=created_on,
            default_assessment_version=default_assessment_version,
            dependent_assessments=dependent_assessments,
            description=description,
            dt=dt,
            dt_version_assessment_version=dt_version_assessment_version,
            end_date=end_date,
            last_modified_on=last_modified_on,
            policy=policy,
            start_date=start_date,
            status=status,
            status_reason=status_reason,
            user_dt_permissions=user_dt_permissions,
        )

        policies_assessment.additional_properties = d
        return policies_assessment

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
